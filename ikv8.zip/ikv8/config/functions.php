<?php
/**
 * Helper functions for the HR Portal
 * Core authentication and authorization functions
 */

/**
 * Sanitize input data
 * 
 * @param string $data Input data to sanitize
 * @return string Sanitized data
 */
function sanitize($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

/**
 * Generate CSRF token
 * 
 * @return string CSRF token
 */
function generate_csrf_token() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify CSRF token
 * 
 * @param string $token Token to verify
 * @return bool True if token is valid
 */
function verify_csrf_token($token) {
    if (!isset($_SESSION['csrf_token']) || $token !== $_SESSION['csrf_token']) {
        return false;
    }
    return true;
}

/**
 * Redirect to a URL
 * 
 * @param string $url URL to redirect to
 * @return void
 */
function redirect($url) {
    header("Location: $url");
    exit;
}

/**
 * Flash messages
 * 
 * @param string $name Message name
 * @param string $message Message content
 * @param string $type Message type (success, info, warning, danger)
 * @return void
 */
function set_flash_message($name, $message, $type = 'info') {
    if (!isset($_SESSION['flash_messages'])) {
        $_SESSION['flash_messages'] = [];
    }
    $_SESSION['flash_messages'][$name] = [
        'message' => $message,
        'type' => $type
    ];
}

/**
 * Display flash message
 * 
 * @param string $name Message name
 * @return string HTML for the flash message
 */
function display_flash_message($name) {
    if (!isset($_SESSION['flash_messages'][$name])) {
        return '';
    }
    
    $flash = $_SESSION['flash_messages'][$name];
    unset($_SESSION['flash_messages'][$name]);
    
    $type = $flash['type'];
    $message = $flash['message'];
    
    return "<div class='alert alert-{$type} alert-dismissible fade show' role='alert'>
                {$message}
                <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
            </div>";
}

/**
 * Check if user is logged in
 * 
 * @return bool True if user is logged in
 */
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

/**
 * Check if user has a specific role
 * 
 * @param string|array $roles Role(s) to check
 * @return bool True if user has the role
 */
function has_role($roles) {
    if (!is_logged_in()) {
        return false;
    }
    
    if (!is_array($roles)) {
        $roles = [$roles];
    }
    
    return in_array($_SESSION['user_role'], $roles);
}

/**
 * Authenticate user
 * 
 * @param string $email User email
 * @param string $password User password
 * @return bool True if authentication successful
 */
function authenticate_user($email, $password) {
    global $db;
    
    try {
        $stmt = $db->prepare("SELECT id, email, password, role, is_active FROM users WHERE email = :email LIMIT 1");
        $stmt->execute(['email' => $email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$user) {
            return false; // User not found
        }
        
        if (!$user['is_active']) {
            return false; // User account is inactive
        }
        
        // Verify password
        if (password_verify($password, $user['password'])) {
            // Authentication successful, set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_role'] = $user['role'];
            
            // Update last login time
            $stmt = $db->prepare("UPDATE users SET last_login = NOW() WHERE id = :id");
            $stmt->execute(['id' => $user['id']]);
            
            return true;
        }
        
        return false; // Password incorrect
    } catch (PDOException $e) {
        error_log("Authentication error: " . $e->getMessage());
        return false;
    }
}

/**
 * Log out user
 * 
 * @return void
 */
function logout_user() {
    // Unset all session variables
    $_SESSION = [];
    
    // Destroy the session
    session_destroy();
}

/**
 * Require authentication to access a page
 * Redirects to login page if not logged in
 * 
 * @param string $redirect_url URL to redirect to if not logged in
 * @return void
 */
function require_auth($redirect_url = '/login.php') {
    if (!is_logged_in()) {
        set_flash_message('auth_error', 'Lütfen devam etmek için giriş yapın.', 'warning');
        redirect($redirect_url);
    }
}

/**
 * Require specific role to access a page
 * Redirects to error page if user doesn't have the required role
 * 
 * @param string|array $required_roles Role(s) required to access the page
 * @param string $redirect_url URL to redirect to if role check fails
 * @return void
 */
function require_role($required_roles, $redirect_url = '/unauthorized.php') {
    require_auth();
    
    if (!has_role($required_roles)) {
        set_flash_message('auth_error', 'Bu sayfaya erişim yetkiniz bulunmamaktadır.', 'danger');
        redirect($redirect_url);
    }
}

/**
 * Validate a date string
 * 
 * @param string $date Date string in Y-m-d format
 * @return bool True if date is valid, false otherwise
 */
function validate_date($date) {
    if (empty($date)) {
        return false;
    }
    
    $d = DateTime::createFromFormat('Y-m-d', $date);
    return $d && $d->format('Y-m-d') === $date;
}

// Eğer fonksiyon daha önce tanımlanmamışsa tanımla
if (!function_exists('require_role')) {
    function require_role($allowed_roles) {
        // Oturum kontrolü
        if (!isset($_SESSION['user_id'])) {
            header('Location: login.php');
            exit;
        }

        // Veritabanı bağlantısı
        $database = new Database();
        $db = $database->connect();

        // Kullanıcı rolünü kontrol et
        $stmt = $db->prepare("SELECT role FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();

        // Rol kontrolü
        if (!in_array($user['role'], $allowed_roles)) {
            header('Location: index.php');
            exit;
        }

        return true;
    }
}

// Diğer fonksiyonlar için de aynı kontrolü ekleyelim
if (!function_exists('set_flash_message')) {
    function set_flash_message($type, $message) {
        $_SESSION['flash_messages'][$type] = [
            'message' => $message,
            'type' => $type
        ];
    }
}

if (!function_exists('sanitize')) {
    function sanitize($data) {
        if (is_array($data)) {
            foreach ($data as $key => $value) {
                $data[$key] = sanitize($value);
            }
        } else {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
        }
        return $data;
    }
}

if (!function_exists('generate_csrf_token')) {
    function generate_csrf_token() {
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
}

if (!function_exists('verify_csrf_token')) {
    function verify_csrf_token($token) {
        if (!isset($_SESSION['csrf_token']) || empty($token)) {
            return false;
        }
        return hash_equals($_SESSION['csrf_token'], $token);
    }
}

if (!function_exists('format_money')) {
    function format_money($amount) {
        return number_format($amount, 2, ',', '.');
    }
}

if (!function_exists('get_user_info')) {
    function get_user_info($user_id) {
        $database = new Database();
        $db = $database->connect();
        
        $stmt = $db->prepare("
            SELECT u.*, e.first_name, e.last_name, e.id as employee_id 
            FROM users u 
            LEFT JOIN employees e ON u.id = e.user_id 
            WHERE u.id = ?
        ");
        $stmt->execute([$user_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}

if (!function_exists('send_notification')) {
    function send_notification($user_id, $type, $title, $message, $related_id = null) {
        try {
            global $db; // veya $database->connect() kullanın
            
            $stmt = $db->prepare("
                INSERT INTO notifications (
                    user_id, type, title, message, related_id
                ) VALUES (?, ?, ?, ?, ?)
            ");
            
            return $stmt->execute([
                $user_id,
                $type,
                $title,
                $message,
                $related_id
            ]);
        } catch (Exception $e) {
            error_log("Bildirim gönderme hatası: " . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('get_user_notifications')) {
    function get_user_notifications($user_id, $limit = 10, $unread_only = false) {
        try {
            global $db;
            
            $sql = "
                SELECT * FROM notifications 
                WHERE user_id = ?
            ";
            
            if ($unread_only) {
                $sql .= " AND is_read = 0";
            }
            
            $sql .= " ORDER BY created_at DESC LIMIT ?";
            
            $stmt = $db->prepare($sql);
            $stmt->execute([$user_id, $limit]);
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Bildirim getirme hatası: " . $e->getMessage());
            return [];
        }
    }
}

if (!function_exists('mark_notification_as_read')) {
    function mark_notification_as_read($notification_id, $user_id) {
        try {
            global $db;
            
            $stmt = $db->prepare("
                UPDATE notifications 
                SET is_read = 1 
                WHERE id = ? AND user_id = ?
            ");
            
            return $stmt->execute([$notification_id, $user_id]);
        } catch (Exception $e) {
            error_log("Bildirim güncelleme hatası: " . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('get_unread_notification_count')) {
    function get_unread_notification_count($user_id) {
        try {
            global $db;
            
            $stmt = $db->prepare("
                SELECT COUNT(*) 
                FROM notifications 
                WHERE user_id = ? AND is_read = 0
            ");
            
            $stmt->execute([$user_id]);
            return $stmt->fetchColumn();
        } catch (Exception $e) {
            error_log("Bildirim sayısı hatası: " . $e->getMessage());
            return 0;
        }
    }
}