<?php
// Application configuration

// Database configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'ikv8');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// Application paths
define('BASE_PATH', dirname(__DIR__));
define('APP_PATH', BASE_PATH . '/app');
define('PUBLIC_PATH', BASE_PATH . '/public');
define('UPLOAD_PATH', PUBLIC_PATH . '/uploads');
define('TEMPLATE_PATH', APP_PATH . '/views');

// URL configuration
define('BASE_URL', 'http://localhost/ikv8');
define('PUBLIC_URL', BASE_URL . '/public');
define('ASSETS_URL', PUBLIC_URL . '/assets');

// Session configuration
define('SESSION_NAME', 'hr_portal_session');
define('SESSION_LIFETIME', 86400); // 24 hours

// Security
define('CSRF_TOKEN_SECRET', 'hr_portal_csrf_secret');
define('PASSWORD_PEPPER', 'hr_portal_password_pepper');

// Timezone
define('DEFAULT_TIMEZONE', 'Europe/Moscow');

// Locale
define('DEFAULT_LOCALE', 'ru_RU');

// Pagination
define('ITEMS_PER_PAGE', 10);

// File upload limits
define('MAX_FILE_SIZE', 10 * 1024 * 1024); // 10MB
define('ALLOWED_FILE_TYPES', 'jpg,jpeg,png,gif,pdf,doc,docx,xls,xlsx,zip');

// Email configuration
define('MAIL_HOST', 'smtp.example.com');
define('MAIL_PORT', 587);
define('MAIL_USERNAME', 'noreply@example.com');
define('MAIL_PASSWORD', 'your_password');
define('MAIL_ENCRYPTION', 'tls');
define('MAIL_FROM_ADDRESS', 'noreply@example.com');
define('MAIL_FROM_NAME', 'HR Portal');

// Debug mode (set to false in production)
define('DEBUG_MODE', true);