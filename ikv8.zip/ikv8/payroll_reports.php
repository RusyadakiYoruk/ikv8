<?php
// Payroll Reports Page
session_start();

// Load configuration
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';

// Set timezone
date_default_timezone_set(DEFAULT_TIMEZONE);

// Connect to database
$database = new Database();
$db = $database->connect();

// Check if user is logged in and has admin or finance role
require_role(['admin', 'finance']);

// Get user information
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

// Initialize variables
$errors = [];
$success_message = '';
$report_type = isset($_GET['report_type']) ? sanitize($_GET['report_type']) : 'department';
$date_from = isset($_GET['date_from']) ? sanitize($_GET['date_from']) : date('Y-m-01'); // First day of current month
$date_to = isset($_GET['date_to']) ? sanitize($_GET['date_to']) : date('Y-m-t'); // Last day of current month
$department_id = isset($_GET['department_id']) ? (int)$_GET['department_id'] : 0;
$employee_id = isset($_GET['employee_id']) ? (int)$_GET['employee_id'] : 0;
$payment_type = isset($_GET['payment_type']) ? sanitize($_GET['payment_type']) : '';
$payment_status = isset($_GET['payment_status']) ? sanitize($_GET['payment_status']) : '';

// Get departments for filter
$stmt = $db->query("SELECT id, name FROM departments ORDER BY name");
$departments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get employees for filter
$stmt = $db->query("SELECT id, first_name, last_name FROM employees ORDER BY last_name, first_name");
$employees = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get payroll periods for reference
$stmt = $db->prepare("SELECT id, period_name, start_date, end_date FROM payroll_periods 
                     WHERE start_date <= :date_to AND end_date >= :date_from
                     ORDER BY start_date DESC");
$stmt->execute([
    'date_from' => $date_from,
    'date_to' => $date_to
]);
$periods = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Build report data based on report type
$report_data = [];
$chart_data = [];
$summary_data = [
    'total_employees' => 0,
    'total_gross' => 0,
    'total_net' => 0,
    'total_tax' => 0,
    'total_insurance' => 0,
    'total_allowances' => 0,
    'total_deductions' => 0
];

// Build SQL query based on filters
$sql_conditions = [];
$sql_params = [];

if (!empty($date_from)) {
    $sql_conditions[] = "pp.start_date >= :date_from";
    $sql_params['date_from'] = $date_from;
}

if (!empty($date_to)) {
    $sql_conditions[] = "pp.end_date <= :date_to";
    $sql_params['date_to'] = $date_to;
}

if ($department_id > 0) {
    $sql_conditions[] = "e.department_id = :department_id";
    $sql_params['department_id'] = $department_id;
}

if ($employee_id > 0) {
    $sql_conditions[] = "e.id = :employee_id";
    $sql_params['employee_id'] = $employee_id;
}

if (!empty($payment_type)) {
    $sql_conditions[] = "e.payment_type = :payment_type";
    $sql_params['payment_type'] = $payment_type;
}

if (!empty($payment_status)) {
    $sql_conditions[] = "p.payment_status = :payment_status";
    $sql_params['payment_status'] = $payment_status;
}

$where_clause = !empty($sql_conditions) ? "WHERE " . implode(" AND ", $sql_conditions) : "";

// Generate report based on type
switch ($report_type) {
    case 'department':
        // Department-wise payroll report
        $sql = "SELECT 
                d.name AS department_name,
                COUNT(DISTINCT e.id) AS employee_count,
                SUM(p.gross_salary) AS total_gross,
                SUM(p.net_salary) AS total_net,
                SUM(p.tax_amount) AS total_tax,
                SUM(p.insurance_amount) AS total_insurance,
                SUM(p.allowances) AS total_allowances,
                SUM(p.deductions) AS total_deductions
                FROM payrolls p
                JOIN employees e ON p.employee_id = e.id
                JOIN departments d ON e.department_id = d.id
                JOIN payroll_periods pp ON p.period_id = pp.id
                $where_clause
                GROUP BY d.id
                ORDER BY d.name";
        
        $stmt = $db->prepare($sql);
        $stmt->execute($sql_params);
        $report_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Prepare chart data
        foreach ($report_data as $row) {
            $chart_data[] = [
                'label' => $row['department_name'],
                'gross' => $row['total_gross'],
                'net' => $row['total_net']
            ];
            
            // Update summary
            $summary_data['total_employees'] += $row['employee_count'];
            $summary_data['total_gross'] += $row['total_gross'];
            $summary_data['total_net'] += $row['total_net'];
            $summary_data['total_tax'] += $row['total_tax'];
            $summary_data['total_insurance'] += $row['total_insurance'];
            $summary_data['total_allowances'] += $row['total_allowances'];
            $summary_data['total_deductions'] += $row['total_deductions'];
        }
        break;
        
    case 'employee':
        // Employee-wise payroll report
        $sql = "SELECT 
                e.id AS employee_id,
                e.first_name,
                e.last_name,
                e.payment_type,
                d.name AS department_name,
                COUNT(p.id) AS payroll_count,
                AVG(p.gross_salary) AS avg_gross,
                AVG(p.net_salary) AS avg_net,
                SUM(p.gross_salary) AS total_gross,
                SUM(p.net_salary) AS total_net,
                SUM(p.tax_amount) AS total_tax,
                SUM(p.insurance_amount) AS total_insurance,
                SUM(p.allowances) AS total_allowances,
                SUM(p.deductions) AS total_deductions
                FROM payrolls p
                JOIN employees e ON p.employee_id = e.id
                JOIN departments d ON e.department_id = d.id
                JOIN payroll_periods pp ON p.period_id = pp.id
                $where_clause
                GROUP BY e.id
                ORDER BY e.last_name, e.first_name";
        
        $stmt = $db->prepare($sql);
        $stmt->execute($sql_params);
        $report_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Prepare chart data - top 10 employees by total earnings
        $chart_data_temp = [];
        foreach ($report_data as $row) {
            $chart_data_temp[] = [
                'label' => $row['first_name'] . ' ' . $row['last_name'],
                'value' => $row['total_net']
            ];
            
            // Update summary
            $summary_data['total_employees']++;
            $summary_data['total_gross'] += $row['total_gross'];
            $summary_data['total_net'] += $row['total_net'];
            $summary_data['total_tax'] += $row['total_tax'];
            $summary_data['total_insurance'] += $row['total_insurance'];
            $summary_data['total_allowances'] += $row['total_allowances'];
            $summary_data['total_deductions'] += $row['total_deductions'];
        }
        
        // Sort by value and get top 10
        usort($chart_data_temp, function($a, $b) {
            return $b['value'] <=> $a['value'];
        });
        
        $chart_data = array_slice($chart_data_temp, 0, 10);
        break;
        
    case 'period':
        // Period-wise payroll report
        $sql = "SELECT 
                pp.period_name,
                pp.start_date,
                pp.end_date,
                COUNT(DISTINCT p.employee_id) AS employee_count,
                SUM(p.gross_salary) AS total_gross,
                SUM(p.net_salary) AS total_net,
                SUM(p.tax_amount) AS total_tax,
                SUM(p.insurance_amount) AS total_insurance,
                SUM(p.allowances) AS total_allowances,
                SUM(p.deductions) AS total_deductions
                FROM payrolls p
                JOIN employees e ON p.employee_id = e.id
                JOIN payroll_periods pp ON p.period_id = pp.id
                LEFT JOIN departments d ON e.department_id = d.id
                $where_clause
                GROUP BY pp.id
                ORDER BY pp.start_date DESC";
        
        $stmt = $db->prepare($sql);
        $stmt->execute($sql_params);
        $report_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Prepare chart data
        foreach ($report_data as $row) {
            $chart_data[] = [
                'label' => $row['period_name'],
                'gross' => $row['total_gross'],
                'net' => $row['total_net']
            ];
            
            // Update summary
            $summary_data['total_employees'] = max($summary_data['total_employees'], $row['employee_count']);
            $summary_data['total_gross'] += $row['total_gross'];
            $summary_data['total_net'] += $row['total_net'];
            $summary_data['total_tax'] += $row['total_tax'];
            $summary_data['total_insurance'] += $row['total_insurance'];
            $summary_data['total_allowances'] += $row['total_allowances'];
            $summary_data['total_deductions'] += $row['total_deductions'];
        }
        break;
        
    case 'payment_type':
        // Payment type-wise payroll report
        $sql = "SELECT 
                e.payment_type,
                COUNT(DISTINCT e.id) AS employee_count,
                SUM(p.gross_salary) AS total_gross,
                SUM(p.net_salary) AS total_net,
                SUM(p.tax_amount) AS total_tax,
                SUM(p.insurance_amount) AS total_insurance,
                SUM(p.allowances) AS total_allowances,
                SUM(p.deductions) AS total_deductions
                FROM payrolls p
                JOIN employees e ON p.employee_id = e.id
                JOIN payroll_periods pp ON p.period_id = pp.id
                LEFT JOIN departments d ON e.department_id = d.id
                $where_clause
                GROUP BY e.payment_type
                ORDER BY e.payment_type";
        
        $stmt = $db->prepare($sql);
        $stmt->execute($sql_params);
        $report_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Prepare chart data
        foreach ($report_data as $row) {
            $payment_type_label = $row['payment_type'] === 'hourly' ? 'Saatlik' : 'Aylık';
            $chart_data[] = [
                'label' => $payment_type_label,
                'gross' => $row['total_gross'],
                'net' => $row['total_net']
            ];
            
            // Update summary
            $summary_data['total_employees'] += $row['employee_count'];
            $summary_data['total_gross'] += $row['total_gross'];
            $summary_data['total_net'] += $row['total_net'];
            $summary_data['total_tax'] += $row['total_tax'];
            $summary_data['total_insurance'] += $row['total_insurance'];
            $summary_data['total_allowances'] += $row['total_allowances'];
            $summary_data['total_deductions'] += $row['total_deductions'];
        }
        break;
}

// Include header
include 'includes/header.php';
?>

<div class="flex h-screen bg-gray-100">
    <!-- Sidebar -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- Main Content -->
    <div class="flex-1 overflow-auto ml-0 lg:ml-64 pt-16">
        <div class="py-6 px-8">
            <!-- Page Header -->
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold text-gray-800">Bordro Raporları</h1>
                <nav class="flex" aria-label="Breadcrumb">
                    <ol class="inline-flex items-center space-x-1 md:space-x-3">
                        <li class="inline-flex items-center">
                            <a href="index.php" class="text-gray-700 hover:text-gray-900 inline-flex items-center">
                                <svg class="w-5 h-5 mr-2.5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"></path>
                                </svg>
                                Dashboard
                            </a>
                        </li>
                        <li>
                            <div class="flex items-center">
                                <svg class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span class="ml-1 text-gray-500 md:ml-2">Bordro Raporları</span>
                            </div>
                            </li>
                    </ol>
                </nav>
            </div>
            
            <!-- Filters Card -->
            <div class="bg-white shadow-md rounded-lg overflow-hidden mb-6">
                <div class="px-6 py-4 border-b border-gray-200 bg-gray-50">
                    <h3 class="text-lg font-semibold text-gray-800">Rapor Filtreleri</h3>
                </div>
                <div class="p-6">
                    <form method="GET" action="payroll_reports.php" class="space-y-4">
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label for="report_type" class="block text-sm font-medium text-gray-700">Rapor Tipi</label>
                                <select name="report_type" id="report_type" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                    <option value="department" <?php echo $report_type === 'department' ? 'selected' : ''; ?>>Departman Bazlı</option>
                                    <option value="employee" <?php echo $report_type === 'employee' ? 'selected' : ''; ?>>Çalışan Bazlı</option>
                                    <option value="period" <?php echo $report_type === 'period' ? 'selected' : ''; ?>>Dönem Bazlı</option>
                                    <option value="payment_type" <?php echo $report_type === 'payment_type' ? 'selected' : ''; ?>>Ödeme Tipi Bazlı</option>
                                </select>
                            </div>
                            
                            <div>
                                <label for="date_from" class="block text-sm font-medium text-gray-700">Başlangıç Tarihi</label>
                                <input type="date" name="date_from" id="date_from" value="<?php echo $date_from; ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                            </div>
                            
                            <div>
                                <label for="date_to" class="block text-sm font-medium text-gray-700">Bitiş Tarihi</label>
                                <input type="date" name="date_to" id="date_to" value="<?php echo $date_to; ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                            </div>
                        </div>
                        
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label for="department_id" class="block text-sm font-medium text-gray-700">Departman</label>
                                <select name="department_id" id="department_id" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                    <option value="0">Tüm Departmanlar</option>
                                    <?php foreach ($departments as $dept): ?>
                                        <option value="<?php echo $dept['id']; ?>" <?php echo $department_id === (int)$dept['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($dept['name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div>
                                <label for="employee_id" class="block text-sm font-medium text-gray-700">Çalışan</label>
                                <select name="employee_id" id="employee_id" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                    <option value="0">Tüm Çalışanlar</option>
                                    <?php foreach ($employees as $emp): ?>
                                        <option value="<?php echo $emp['id']; ?>" <?php echo $employee_id === (int)$emp['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div>
                                <label for="payment_type" class="block text-sm font-medium text-gray-700">Ödeme Tipi</label>
                                <select name="payment_type" id="payment_type" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                    <option value="">Tüm Tipler</option>
                                    <option value="hourly" <?php echo $payment_type === 'hourly' ? 'selected' : ''; ?>>Saatlik</option>
                                    <option value="monthly" <?php echo $payment_type === 'monthly' ? 'selected' : ''; ?>>Aylık</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label for="payment_status" class="block text-sm font-medium text-gray-700">Ödeme Durumu</label>
                                <select name="payment_status" id="payment_status" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                    <option value="">Tüm Durumlar</option>
                                    <option value="pending" <?php echo $payment_status === 'pending' ? 'selected' : ''; ?>>Beklemede</option>
                                    <option value="paid" <?php echo $payment_status === 'paid' ? 'selected' : ''; ?>>Ödendi</option>
                                    <option value="cancelled" <?php echo $payment_status === 'cancelled' ? 'selected' : ''; ?>>İptal Edildi</option>
                                </select>
                            </div>
                            
                            <div class="md:col-span-2 flex items-end">
                                <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"></path>
                                    </svg>
                                    Raporu Filtrele
                                </button>
                                
                                <a href="export_report.php?<?php echo http_build_query($_GET); ?>" class="ml-4 inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                                    </svg>
                                    Excel'e Aktar
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Summary Card -->
            <div class="bg-white shadow-md rounded-lg overflow-hidden mb-6">
                <div class="px-6 py-4 border-b border-gray-200 bg-gray-50">
                    <h3 class="text-lg font-semibold text-gray-800">Özet Bilgiler</h3>
                </div>
                <div class="p-6">
                    <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div class="bg-blue-50 p-4 rounded-lg">
                            <p class="text-sm text-blue-600 font-medium">Toplam Çalışan</p>
                            <p class="text-2xl font-bold text-blue-800"><?php echo $summary_data['total_employees']; ?></p>
                        </div>
                        <div class="bg-green-50 p-4 rounded-lg">
                            <p class="text-sm text-green-600 font-medium">Toplam Brüt</p>
                            <p class="text-2xl font-bold text-green-800"><?php echo number_format($summary_data['total_gross'], 2, ',', '.'); ?> ₺</p>
                        </div>
                        <div class="bg-indigo-50 p-4 rounded-lg">
                            <p class="text-sm text-indigo-600 font-medium">Toplam Net</p>
                            <p class="text-2xl font-bold text-indigo-800"><?php echo number_format($summary_data['total_net'], 2, ',', '.'); ?> ₺</p>
                        </div>
                        <div class="bg-red-50 p-4 rounded-lg">
                            <p class="text-sm text-red-600 font-medium">Toplam Kesintiler</p>
                            <p class="text-2xl font-bold text-red-800"><?php echo number_format($summary_data['total_tax'] + $summary_data['total_insurance'] + $summary_data['total_deductions'], 2, ',', '.'); ?> ₺</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Chart Card -->
            <?php if (!empty($chart_data)): ?>
            <div class="bg-white shadow-md rounded-lg overflow-hidden mb-6">
                <div class="px-6 py-4 border-b border-gray-200 bg-gray-50">
                    <h3 class="text-lg font-semibold text-gray-800">
                        <?php 
                        switch ($report_type) {
                            case 'department':
                                echo 'Departman Bazlı Maaş Dağılımı';
                                break;
                            case 'employee':
                                echo 'En Yüksek Maaş Alan 10 Çalışan';
                                break;
                            case 'period':
                                echo 'Dönem Bazlı Maaş Dağılımı';
                                break;
                            case 'payment_type':
                                echo 'Ödeme Tipi Bazlı Maaş Dağılımı';
                                break;
                        }
                        ?>
                    </h3>
                </div>
                <div class="p-6">
                    <div class="h-80">
                        <canvas id="reportChart"></canvas>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Report Data Table -->
            <div class="bg-white shadow-md rounded-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 bg-gray-50">
                    <h3 class="text-lg font-semibold text-gray-800">
                        <?php 
                        switch ($report_type) {
                            case 'department':
                                echo 'Departman Bazlı Rapor';
                                break;
                            case 'employee':
                                echo 'Çalışan Bazlı Rapor';
                                break;
                            case 'period':
                                echo 'Dönem Bazlı Rapor';
                                break;
                            case 'payment_type':
                                echo 'Ödeme Tipi Bazlı Rapor';
                                break;
                        }
                        ?>
                    </h3>
                </div>
                
                <?php if (!empty($report_data)): ?>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <?php if ($report_type === 'department'): ?>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Departman</th>
                                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Çalışan Sayısı</th>
                                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Toplam Brüt</th>
                                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Toplam Net</th>
                                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Toplam Vergi</th>
                                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Toplam SGK</th>
                                    <?php elseif ($report_type === 'employee'): ?>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Çalışan</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Departman</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ödeme Tipi</th>
                                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Bordro Sayısı</th>
                                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Ortalama Brüt</th>
                                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Ortalama Net</th>
                                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Toplam Net</th>
                                    <?php elseif ($report_type === 'period'): ?>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Dönem</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tarih Aralığı</th>
                                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Çalışan Sayısı</th>
                                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Toplam Brüt</th>
                                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Toplam Net</th>
                                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Toplam Kesintiler</th>
                                    <?php elseif ($report_type === 'payment_type'): ?>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ödeme Tipi</th>
                                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Çalışan Sayısı</th>
                                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Toplam Brüt</th>
                                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Toplam Net</th>
                                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Kişi Başı Ortalama</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php foreach ($report_data as $row): ?>
                                    <tr>
                                        <?php if ($report_type === 'department'): ?>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo htmlspecialchars($row['department_name']); ?></td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-right"><?php echo $row['employee_count']; ?></td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right"><?php echo number_format($row['total_gross'], 2, ',', '.'); ?> ₺</td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right"><?php echo number_format($row['total_net'], 2, ',', '.'); ?> ₺</td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right"><?php echo number_format($row['total_tax'], 2, ',', '.'); ?> ₺</td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right"><?php echo number_format($row['total_insurance'], 2, ',', '.'); ?> ₺</td>
                                        <?php elseif ($report_type === 'employee'): ?>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?></div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo htmlspecialchars($row['department_name']); ?></td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                                    <?php echo $row['payment_type'] === 'hourly' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'; ?>">
                                                    <?php echo $row['payment_type'] === 'hourly' ? 'Saatlik' : 'Aylık'; ?>
                                                </span>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-right"><?php echo $row['payroll_count']; ?></td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right"><?php echo number_format($row['avg_gross'], 2, ',', '.'); ?> ₺</td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right"><?php echo number_format($row['avg_net'], 2, ',', '.'); ?> ₺</td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right font-medium"><?php echo number_format($row['total_net'], 2, ',', '.'); ?> ₺</td>
                                        <?php elseif ($report_type === 'period'): ?>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo htmlspecialchars($row['period_name']); ?></td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                <?php echo date('d.m.Y', strtotime($row['start_date'])); ?> - 
                                                <?php echo date('d.m.Y', strtotime($row['end_date'])); ?>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-right"><?php echo $row['employee_count']; ?></td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right"><?php echo number_format($row['total_gross'], 2, ',', '.'); ?> ₺</td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right"><?php echo number_format($row['total_net'], 2, ',', '.'); ?> ₺</td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right"><?php echo number_format($row['total_tax'] + $row['total_insurance'] + $row['total_deductions'], 2, ',', '.'); ?> ₺</td>
                                        <?php elseif ($report_type === 'payment_type'): ?>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                                    <?php echo $row['payment_type'] === 'hourly' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'; ?>">
                                                    <?php echo $row['payment_type'] === 'hourly' ? 'Saatlik' : 'Aylık'; ?>
                                                </span>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-right"><?php echo $row['employee_count']; ?></td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right"><?php echo number_format($row['total_gross'], 2, ',', '.'); ?> ₺</td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right"><?php echo number_format($row['total_net'], 2, ',', '.'); ?> ₺</td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right">
                                                <?php echo number_format($row['total_net'] / $row['employee_count'], 2, ',', '.'); ?> ₺
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="p-6 text-center">
                        <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                        </svg>
                        <h3 class="mt-2 text-sm font-medium text-gray-900">Veri Bulunamadı</h3>
                        <p class="mt-1 text-sm text-gray-500">Seçilen kriterlere uygun rapor verisi bulunamadı.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Chart.js Library -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        <?php if (!empty($chart_data)): ?>
        // Chart configuration
        const ctx = document.getElementById('reportChart').getContext('2d');
        
        <?php if ($report_type === 'employee'): ?>
        // Bar chart for employee report
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: [<?php echo implode(', ', array_map(function($item) { return "'" . addslashes($item['label']) . "'"; }, $chart_data)); ?>],
                datasets: [{
                    label: 'Net Maaş',
                    data: [<?php echo implode(', ', array_map(function($item) { return $item['value']; }, $chart_data)); ?>],
                    backgroundColor: 'rgba(79, 70, 229, 0.6)',
                    borderColor: 'rgba(79, 70, 229, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return value.toLocaleString('tr-TR') + ' ₺';
                            }
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return context.dataset.label + ': ' + context.raw.toLocaleString('tr-TR') + ' ₺';
                            }
                        }
                    }
                }
            }
        });
        <?php else: ?>
        // Bar chart for other reports
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: [<?php echo implode(', ', array_map(function($item) { return "'" . addslashes($item['label']) . "'"; }, $chart_data)); ?>],
                datasets: [{
                    label: 'Brüt Maaş',
                    data: [<?php echo implode(', ', array_map(function($item) { return $item['gross']; }, $chart_data)); ?>],
                    backgroundColor: 'rgba(59, 130, 246, 0.6)',
                    borderColor: 'rgba(59, 130, 246, 1)',
                    borderWidth: 1
                }, {
                    label: 'Net Maaş',
                    data: [<?php echo implode(', ', array_map(function($item) { return $item['net']; }, $chart_data)); ?>],
                    backgroundColor: 'rgba(16, 185, 129, 0.6)',
                    borderColor: 'rgba(16, 185, 129, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return value.toLocaleString('tr-TR') + ' ₺';
                            }
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return context.dataset.label + ': ' + context.raw.toLocaleString('tr-TR') + ' ₺';
                            }
                        }
                    }
                }
            }
        });
        <?php endif; ?>
        <?php endif; ?>
        
        // Form handling
        const reportTypeSelect = document.getElementById('report_type');
        if (reportTypeSelect) {
            reportTypeSelect.addEventListener('change', function() {
                // Optionally auto-submit the form when report type changes
                // this.form.submit();
            });
        }
        
        // Date range validation
        const dateFromInput = document.getElementById('date_from');
        const dateToInput = document.getElementById('date_to');
        
        if (dateToInput && dateFromInput) {
            dateToInput.addEventListener('change', function() {
                if (dateFromInput.value && dateToInput.value) {
                    if (new Date(dateFromInput.value) > new Date(dateToInput.value)) {
                        alert('Bitiş tarihi, başlangıç tarihinden sonra olmalıdır.');
                        dateToInput.value = '';
                    }
                }
            });
            
            dateFromInput.addEventListener('change', function() {
                if (dateFromInput.value && dateToInput.value) {
                    if (new Date(dateFromInput.value) > new Date(dateToInput.value)) {
                        alert('Başlangıç tarihi, bitiş tarihinden önce olmalıdır.');
                        dateFromInput.value = '';
                    }
                }
            });
        }
    });
</script>

<?php include 'includes/footer.php'; ?>