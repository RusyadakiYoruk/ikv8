<?php
// Payroll Processing Page
session_start();

// Load configuration
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';

// Set timezone
date_default_timezone_set(DEFAULT_TIMEZONE);

// Connect to database
$database = new Database();
$db = $database->connect();

// Check if user is logged in and has admin or finance role
require_role(['admin', 'finance']);

// Get user information
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

// Initialize variables
$errors = [];
$success_message = '';
$period = null;
$employees = [];
$attendance_data = [];
$total_stats = [
    'total_employees' => 0,
    'total_gross' => 0,
    'total_net' => 0,
    'total_tax' => 0,
    'total_insurance' => 0
];

// Check if period ID is provided
if (!isset($_GET['period_id']) || !is_numeric($_GET['period_id'])) {
    set_flash_message('payroll_error', 'Geçersiz bordro dönemi ID\'si.', 'danger');
    redirect('payroll_periods.php');
    exit;
}

$period_id = (int)$_GET['period_id'];

// Get period details
$stmt = $db->prepare("SELECT * FROM payroll_periods WHERE id = :period_id");
$stmt->execute(['period_id' => $period_id]);
$period = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$period) {
    set_flash_message('payroll_error', 'Bordro dönemi bulunamadı.', 'danger');
    redirect('payroll_periods.php');
    exit;
}

// Process form submission for calculating payrolls
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
        $errors['general'] = 'Geçersiz form gönderimi. Lütfen tekrar deneyin.';
    } else {
        $action = $_POST['action'];
        
        // Calculate payrolls for all employees
        if ($action === 'calculate_all') {
            try {
                // Begin transaction
                $db->beginTransaction();
                
                // Get all active employees
                $stmt = $db->prepare("SELECT * FROM employees WHERE (termination_date IS NULL OR termination_date > :period_end) AND status = 'active'");
                $stmt->execute(['period_end' => $period['end_date']]);
                $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                $generated_count = 0;
                $updated_count = 0;
                
                // Get period dates
                $period_start = new DateTime($period['start_date']);
                $period_end = new DateTime($period['end_date']);
                $period_days = $period_start->diff($period_end)->days + 1;
                
                // Process each employee
                foreach ($employees as $employee) {
                    // Check if payroll already exists for this employee and period
                    $stmt = $db->prepare("SELECT id FROM payrolls WHERE employee_id = :employee_id AND period_id = :period_id");
                    $stmt->execute([
                        'employee_id' => $employee['id'],
                        'period_id' => $period_id
                    ]);
                    
                    $existing_payroll = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    // Get employee attendance data for the period
                    $attendance_data = get_employee_attendance($db, $employee['id'], $period['start_date'], $period['end_date']);
                    
                    // Calculate salary based on employment type
                    $base_salary = 0;
                    $work_days = 0;
                    $bonus_amount = 0;
                    $deductions = 0;
                    
                    if ($employee['payment_type'] === 'hourly') {
                        // Hourly employee calculation
                        $hourly_rate = $employee['salary_amount'];
                        $daily_hours = 10; // 10 hours per day
                        
                        // Calculate work cycle (14 days work, 1 day rest)
                        $total_work_days = calculate_work_cycle_days($period_start, $period_end, $employee['hire_date']);
                        $work_days = $total_work_days['work_days'];
                        $rest_days = $total_work_days['rest_days'];
                        
                        // Calculate base salary (work days * daily hours * hourly rate)
                        $base_salary = $work_days * $daily_hours * $hourly_rate;
                        
                        // Check for absences
                        $absences = $attendance_data['absences'] ?? 0;
                        
                        // Calculate bonus for rest days (if no unauthorized absences)
                        if ($absences == 0 && $rest_days > 0) {
                            $bonus_amount = $rest_days * $daily_hours * $hourly_rate;
                        }
                        
                        // Calculate deductions for absences
                        if ($absences > 0) {
                            $deductions = $absences * $daily_hours * $hourly_rate;
                        }
                    } else {
                        // Monthly employee calculation
                        $monthly_salary = $employee['salary_amount'];
                        
                        // Calculate work days excluding unpaid leave
                        $unpaid_leave = $attendance_data['unpaid_leave'] ?? 0;
                        $work_days = $period_days - $unpaid_leave;
                        
                        // Calculate base salary (prorated if unpaid leave exists)
                        if ($unpaid_leave > 0) {
                            $base_salary = ($work_days / $period_days) * $monthly_salary;
                        } else {
                            $base_salary = $monthly_salary;
                        }
                    }
                    
                    // Calculate tax and insurance deductions
                    $tax_rate = 0.15; // 15% tax rate (simplified)
                    $insurance_rate = 0.14; // 14% insurance rate (simplified)
                    
                    // Get additional earnings and deductions from payroll items
                    $additional_earnings = get_employee_payroll_items($db, $employee['id'], 'earning', $period['start_date']);
                    $additional_deductions = get_employee_payroll_items($db, $employee['id'], 'deduction', $period['start_date']);
                    
                    // Calculate gross salary
                    $gross_salary = $base_salary + $bonus_amount + $additional_earnings;
                    
                    // Calculate taxable amount
                    $taxable_amount = $gross_salary;
                    
                    // Calculate tax and insurance
                    $tax_amount = $taxable_amount * $tax_rate;
                    $insurance_amount = $taxable_amount * $insurance_rate;
                    
                    // Calculate net salary
                    $net_salary = $gross_salary - $tax_amount - $insurance_amount - $deductions - $additional_deductions;
                    
                    // Prepare payroll data
                    $payroll_data = [
                        'employee_id' => $employee['id'],
                        'period_id' => $period_id,
                        'base_salary' => $base_salary,
                        'gross_salary' => $gross_salary,
                        'net_salary' => $net_salary,
                        'tax_amount' => $tax_amount,
                        'insurance_amount' => $insurance_amount,
                        'allowances' => $bonus_amount + $additional_earnings,
                        'deductions' => $deductions + $additional_deductions,
                        'work_days' => $work_days,
                        'payment_status' => 'pending',
                        'notes' => "Hesaplama: " . date('Y-m-d H:i:s')
                    ];
                    
                    if ($existing_payroll) {
                        // Update existing payroll
                        $stmt = $db->prepare("UPDATE payrolls SET 
                            base_salary = :base_salary,
                            gross_salary = :gross_salary,
                            net_salary = :net_salary,
                            tax_amount = :tax_amount,
                            insurance_amount = :insurance_amount,
                            allowances = :allowances,
                            deductions = :deductions,
                            work_days = :work_days,
                            notes = :notes,
                            updated_by = :updated_by,
                            updated_at = NOW()
                        WHERE id = :payroll_id");
                        
                        $payroll_data['updated_by'] = $user_id;
                        $payroll_data['payroll_id'] = $existing_payroll['id'];
                        
                        $stmt->execute($payroll_data);
                        $updated_count++;
                    } else {
                        // Insert new payroll
                        $stmt = $db->prepare("INSERT INTO payrolls (
                            employee_id, period_id, base_salary, gross_salary, net_salary, 
                            tax_amount, insurance_amount, allowances, deductions, work_days, 
                            payment_status, notes, created_by, created_at
                        ) VALUES (
                            :employee_id, :period_id, :base_salary, :gross_salary, :net_salary,
                            :tax_amount, :insurance_amount, :allowances, :deductions, :work_days,
                            :payment_status, :notes, :created_by, NOW()
                        )");
                        
                        $payroll_data['created_by'] = $user_id;
                        
                        $stmt->execute($payroll_data);
                        $generated_count++;
                    }
                }
                
                // Update period status
                $stmt = $db->prepare("UPDATE payroll_periods SET status = 'processing', updated_by = :user_id, updated_at = NOW() WHERE id = :period_id");
                $stmt->execute([
                    'user_id' => $user_id,
                    'period_id' => $period_id
                ]);
                
                // Log the action
                $stmt = $db->prepare("INSERT INTO activity_logs (user_id, activity_type, description, ip_address) VALUES (:user_id, 'payroll_calculate', :description, :ip_address)");
                $stmt->execute([
                    'user_id' => $user_id,
                    'description' => "Bordro hesaplandı: {$period['period_name']} - {$generated_count} yeni, {$updated_count} güncellendi",
                    'ip_address' => $_SERVER['REMOTE_ADDR']
                ]);
                
                // Commit transaction
                $db->commit();
                
                $success_message = "{$generated_count} yeni bordro hesaplandı, {$updated_count} bordro güncellendi.";
                set_flash_message('payroll_success', $success_message, 'success');
                redirect("payroll_process.php?period_id={$period_id}");
                exit;
                
            } catch (Exception $e) {
                // Rollback transaction on error
                $db->rollBack();
                $errors['general'] = 'Bordro hesaplanırken bir hata oluştu: ' . $e->getMessage();
                error_log('Bordro hesaplama hatası: ' . $e->getMessage());
            }
        }
        // Finalize payrolls
        elseif ($action === 'finalize') {
            try {
                // Begin transaction
                $db->beginTransaction();
                
                // Update all payrolls for this period to 'paid' status
                $stmt = $db->prepare("UPDATE payrolls SET 
                    payment_status = 'paid',
                    payment_date = :payment_date,
                    updated_by = :user_id,
                    updated_at = NOW()
                WHERE period_id = :period_id");
                
                $stmt->execute([
                    'payment_date' => $period['payment_date'],
                    'user_id' => $user_id,
                    'period_id' => $period_id
                ]);
                
                // Update period status to 'completed'
                $stmt = $db->prepare("UPDATE payroll_periods SET 
                    status = 'completed',
                    updated_by = :user_id,
                    updated_at = NOW()
                WHERE id = :period_id");
                
                $stmt->execute([
                    'user_id' => $user_id,
                    'period_id' => $period_id
                ]);
                
                // Log the action
                $stmt = $db->prepare("INSERT INTO activity_logs (user_id, activity_type, description, ip_address) VALUES (:user_id, 'payroll_finalize', :description, :ip_address)");
                $stmt->execute([
                    'user_id' => $user_id,
                    'description' => "Bordro dönemi tamamlandı: {$period['period_name']}",
                    'ip_address' => $_SERVER['REMOTE_ADDR']
                ]);
                
                // Commit transaction
                $db->commit();
                
                $success_message = "Bordro dönemi başarıyla tamamlandı ve ödemeler işaretlendi.";
                set_flash_message('payroll_success', $success_message, 'success');
                redirect("payroll_process.php?period_id={$period_id}");
                exit;
                
            } catch (Exception $e) {
                // Rollback transaction on error
                $db->rollBack();
                $errors['general'] = 'Bordro dönemi tamamlanırken bir hata oluştu: ' . $e->getMessage();
                error_log('Bordro dönemi tamamlama hatası: ' . $e->getMessage());
            }
        }
    }
}

// Get all employees with their payroll data for this period
$sql = "SELECT e.*, 
        d.name AS department_name,
        jt.title AS job_title,
        pr.id AS payroll_id,
        pr.base_salary,
        pr.gross_salary,
        pr.net_salary,
        pr.tax_amount,
        pr.insurance_amount,
        pr.allowances,
        pr.deductions,
        pr.work_days,
        pr.payment_status,
        pr.payment_date,
        pr.notes
        FROM employees e
        LEFT JOIN departments d ON e.department_id = d.id
        LEFT JOIN job_titles jt ON e.job_title_id = jt.id
        LEFT JOIN payrolls pr ON e.id = pr.employee_id AND pr.period_id = :period_id
        WHERE (e.termination_date IS NULL OR e.termination_date > :period_start) AND e.status = 'active'
        ORDER BY e.last_name, e.first_name";

$stmt = $db->prepare($sql);
$stmt->execute([
    'period_id' => $period_id,
    'period_start' => $period['start_date']
]);
$employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
// Calculate total statistics
foreach ($employees as $employee) {
    if ($employee['payroll_id']) {
        $total_stats['total_employees']++;
        $total_stats['total_gross'] += $employee['gross_salary'];
        $total_stats['total_net'] += $employee['net_salary'];
        $total_stats['total_tax'] += $employee['tax_amount'];
        $total_stats['total_insurance'] += $employee['insurance_amount'];
    }
}

// Helper functions for payroll calculations
function calculate_work_cycle_days($period_start, $period_end, $hire_date) {
    // Convert hire date to DateTime
    $hire_date = new DateTime($hire_date);
    
    // Ensure period_start and period_end are DateTime objects
    if (!($period_start instanceof DateTime)) {
        $period_start = new DateTime($period_start);
    }
    if (!($period_end instanceof DateTime)) {
        $period_end = new DateTime($period_end);
    }
    
    // Adjust start date if hire date is after period start
    $start_date = $period_start;
    if ($hire_date > $period_start) {
        $start_date = $hire_date;
    }
    
    // Calculate days in period
    $interval = $start_date->diff($period_end);
    $total_days = $interval->days + 1; // Include both start and end days
    
    // Calculate work and rest days based on 14-day work cycle (14 work, 1 rest)
    $cycle_length = 15; // 14 work days + 1 rest day
    $full_cycles = floor($total_days / $cycle_length);
    $remaining_days = $total_days % $cycle_length;
    
    $work_days = $full_cycles * 14;
    $rest_days = $full_cycles;
    
    // Add remaining days
    if ($remaining_days > 0) {
        $work_days += min($remaining_days, 14);
        $rest_days += ($remaining_days > 14) ? 1 : 0;
    }
    
    return [
        'work_days' => $work_days,
        'rest_days' => $rest_days,
        'total_days' => $total_days
    ];
}

function get_employee_attendance($db, $employee_id, $start_date, $end_date) {
    // Get attendance data for the employee within the period
    $stmt = $db->prepare("SELECT 
        COUNT(CASE WHEN status = 'absent' AND is_authorized = 0 THEN 1 END) as absences,
        COUNT(CASE WHEN status = 'absent' AND is_authorized = 1 AND is_paid = 0 THEN 1 END) as unpaid_leave
        FROM attendance
        WHERE employee_id = :employee_id 
        AND date BETWEEN :start_date AND :end_date");
    
    $stmt->execute([
        'employee_id' => $employee_id,
        'start_date' => $start_date,
        'end_date' => $end_date
    ]);
    
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    return $result ? $result : ['absences' => 0, 'unpaid_leave' => 0];
}

function get_employee_payroll_items($db, $employee_id, $type, $date) {
    // Get sum of payroll items for the employee
    $stmt = $db->prepare("SELECT SUM(piv.amount) as total
        FROM payroll_item_values piv
        JOIN payroll_items pi ON piv.item_id = pi.id
        WHERE piv.employee_id = :employee_id 
        AND pi.type = :type
        AND piv.effective_date <= :date
        AND (piv.end_date IS NULL OR piv.end_date >= :date)");
    
    $stmt->execute([
        'employee_id' => $employee_id,
        'type' => $type,
        'date' => $date
    ]);
    
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    return $result && $result['total'] ? $result['total'] : 0;
}

// Include header
include 'includes/header.php';
?>

<div class="flex h-screen bg-gray-100">
    <!-- Sidebar -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- Main Content -->
    <div class="flex-1 overflow-auto ml-0 lg:ml-64 pt-16">
        <div class="py-6 px-8">
            <!-- Page Header -->
            <div class="flex justify-between items-center mb-6">
                <div>
                    <h1 class="text-2xl font-bold text-gray-800">Maaş Hesaplama</h1>
                    <p class="text-sm text-gray-600">
                        Dönem: <?php echo htmlspecialchars($period['period_name']); ?> (<?php echo date('d.m.Y', strtotime($period['start_date'])); ?> - <?php echo date('d.m.Y', strtotime($period['end_date'])); ?>)
                    </p>
                </div>
                <nav class="flex" aria-label="Breadcrumb">
                    <ol class="inline-flex items-center space-x-1 md:space-x-3">
                        <li class="inline-flex items-center">
                            <a href="index.php" class="text-gray-700 hover:text-gray-900 inline-flex items-center">
                                <svg class="w-5 h-5 mr-2.5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"></path>
                                </svg>
                                Dashboard
                            </a>
                        </li>
                        <li>
                            <div class="flex items-center">
                                <svg class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <a href="payroll_periods.php" class="ml-1 text-gray-700 hover:text-gray-900 md:ml-2">Bordro Dönemleri</a>
                            </div>
                        </li>
                        <li>
                            <div class="flex items-center">
                                <svg class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span class="ml-1 text-gray-500 md:ml-2">Maaş Hesaplama</span>
                            </div>
                        </li>
                    </ol>
                </nav>
            </div>
            
            <!-- Flash Messages -->
            <?php if (isset($_SESSION['flash_messages']['payroll_success'])): ?>
                <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6" role="alert">
                    <p><?php echo $_SESSION['flash_messages']['payroll_success']['message']; ?></p>
                </div>
                <?php unset($_SESSION['flash_messages']['payroll_success']); ?>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['flash_messages']['payroll_error'])): ?>
                <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                    <p><?php echo $_SESSION['flash_messages']['payroll_error']['message']; ?></p>
                </div>
                <?php unset($_SESSION['flash_messages']['payroll_error']); ?>
            <?php endif; ?>
            
            <?php if (isset($errors['general'])): ?>
                <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                    <p><?php echo $errors['general']; ?></p>
                </div>
            <?php endif; ?>
            
            <!-- Period Status Card -->
            <div class="bg-white shadow-md rounded-lg overflow-hidden mb-6">
                <div class="px-6 py-4 border-b border-gray-200 bg-gray-50 flex justify-between items-center">
                    <div>
                        <h3 class="text-lg font-semibold text-gray-800">Dönem Durumu</h3>
                        <p class="text-sm text-gray-600">Ödeme Tarihi: <?php echo date('d.m.Y', strtotime($period['payment_date'])); ?></p>
                    </div>
                    <div>
                        <span class="px-3 py-1 inline-flex text-sm leading-5 font-semibold rounded-full 
                            <?php 
                            switch ($period['status']) {
                                case 'pending':
                                    echo 'bg-yellow-100 text-yellow-800';
                                    break;
                                case 'processing':
                                    echo 'bg-blue-100 text-blue-800';
                                    break;
                                case 'completed':
                                    echo 'bg-green-100 text-green-800';
                                    break;
                                case 'cancelled':
                                    echo 'bg-red-100 text-red-800';
                                    break;
                                default:
                                    echo 'bg-gray-100 text-gray-800';
                            }
                            ?>">
                            <?php 
                            switch ($period['status']) {
                                case 'pending':
                                    echo 'Beklemede';
                                    break;
                                case 'processing':
                                    echo 'İşleniyor';
                                    break;
                                case 'completed':
                                    echo 'Tamamlandı';
                                    break;
                                case 'cancelled':
                                    echo 'İptal Edildi';
                                    break;
                                default:
                                    echo $period['status'];
                            }
                            ?>
                        </span>
                    </div>
                </div>
                <div class="p-6">
                    <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div class="bg-blue-50 p-4 rounded-lg">
                            <p class="text-sm text-blue-600 font-medium">Toplam Çalışan</p>
                            <p class="text-2xl font-bold text-blue-800"><?php echo $total_stats['total_employees']; ?></p>
                        </div>
                        <div class="bg-green-50 p-4 rounded-lg">
                            <p class="text-sm text-green-600 font-medium">Toplam Brüt</p>
                            <p class="text-2xl font-bold text-green-800"><?php echo number_format($total_stats['total_gross'], 2, ',', '.'); ?> ₺</p>
                        </div>
                        <div class="bg-indigo-50 p-4 rounded-lg">
                            <p class="text-sm text-indigo-600 font-medium">Toplam Net</p>
                            <p class="text-2xl font-bold text-indigo-800"><?php echo number_format($total_stats['total_net'], 2, ',', '.'); ?> ₺</p>
                        </div>
                        <div class="bg-red-50 p-4 rounded-lg">
                            <p class="text-sm text-red-600 font-medium">Toplam Kesintiler</p>
                            <p class="text-2xl font-bold text-red-800"><?php echo number_format($total_stats['total_tax'] + $total_stats['total_insurance'], 2, ',', '.'); ?> ₺</p>
                        </div>
                    </div>
                    
                    <div class="mt-6 flex space-x-4">
                        <?php if ($period['status'] !== 'completed'): ?>
                            <form method="POST" action="payroll_process.php?period_id=<?php echo $period_id; ?>">
                                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                <input type="hidden" name="action" value="calculate_all">
                                <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"></path>
                                    </svg>
                                    Maaşları Hesapla
                                </button>
                            </form>
                            
                            <?php if ($total_stats['total_employees'] > 0 && $period['status'] === 'processing'): ?>
                                <form method="POST" action="payroll_process.php?period_id=<?php echo $period_id; ?>" onsubmit="return confirm('Bordro dönemini tamamlamak istediğinizden emin misiniz? Bu işlem geri alınamaz.');">
                                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                    <input type="hidden" name="action" value="finalize">
                                    <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                                        </svg>
                                        Dönemi Tamamla
                                    </button>
                                </form>
                            <?php endif; ?>
                        <?php endif; ?>
                        
                        <a href="export_payroll.php?period_id=<?php echo $period_id; ?>" class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                            </svg>
                            Excel'e Aktar
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Calculation Info Card -->
            <div class="bg-white shadow-md rounded-lg overflow-hidden mb-6">
                <div class="px-6 py-4 border-b border-gray-200 bg-gray-50">
                    <h3 class="text-lg font-semibold text-gray-800">Hesaplama Bilgileri</h3>
                </div>
                <div class="p-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <h4 class="text-base font-medium text-gray-700 mb-3">Saatlik Çalışanlar</h4>
                            <ul class="list-disc pl-5 space-y-2 text-sm text-gray-600">
                                <li>Günde 10 saat çalışma</li>
                                <li>14 gün çalışma, 1 gün dinlenme döngüsü</li>
                                <li>Sebepsiz devamsızlık yapmayanlar için dinlenme günlerinde 10 saatlik bonus ücret</li>
                                <li>Devamsızlık durumunda günlük 10 saat üzerinden kesinti</li>
                            </ul>
                        </div>
                        <div>
                            <h4 class="text-base font-medium text-gray-700 mb-3">Aylık Çalışanlar</h4>
                            <ul class="list-disc pl-5 space-y-2 text-sm text-gray-600">
                                <li>Tam aylık maaş</li>
                                <li>Ücretsiz izin günleri için orantılı kesinti</li>
                                <li>Vergi oranı: %15</li>
                                <li>SGK kesintisi: %14</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Employees Payroll Table -->
            <div class="bg-white shadow-md rounded-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h3 class="text-lg font-semibold text-gray-800">Çalışan Bordroları</h3>
                </div>
                
                <?php if (count($employees) > 0): ?>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Çalışan
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Departman
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Ödeme Tipi
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Çalışma Günü
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Temel Maaş
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Ek Ödemeler
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Kesintiler
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Net Maaş
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Durum
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        İşlemler
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php foreach ($employees as $employee): ?>
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="flex items-center">
                                                <div class="flex-shrink-0 h-10 w-10 bg-gray-200 rounded-full flex items-center justify-center">
                                                    <span class="text-gray-500 font-medium"><?php echo substr($employee['first_name'], 0, 1) . substr($employee['last_name'], 0, 1); ?></span>
                                                </div>
                                                <div class="ml-4">
                                                    <div class="text-sm font-medium text-gray-900">
                                                        <?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?>
                                                    </div>
                                                    <div class="text-sm text-gray-500">
                                                        <?php echo htmlspecialchars($employee['job_title'] ?? ''); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm text-gray-900"><?php echo htmlspecialchars($employee['department_name'] ?? '-'); ?></div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                                <?php echo $employee['payment_type'] === 'hourly' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'; ?>">
                                                <?php echo $employee['payment_type'] === 'hourly' ? 'Saatlik' : 'Aylık'; ?>
                                            </span>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-500">
                                            <?php echo $employee['work_days'] ?? '-'; ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-900">
                                            <?php echo isset($employee['base_salary']) ? number_format($employee['base_salary'], 2, ',', '.') . ' ₺' : '-'; ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-900">
                                            <?php echo isset($employee['allowances']) ? number_format($employee['allowances'], 2, ',', '.') . ' ₺' : '-'; ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-900">
                                            <?php 
                                            if (isset($employee['tax_amount']) && isset($employee['insurance_amount']) && isset($employee['deductions'])) {
                                                $total_deductions = $employee['tax_amount'] + $employee['insurance_amount'] + $employee['deductions'];
                                                echo number_format($total_deductions, 2, ',', '.') . ' ₺';
                                            } else {
                                                echo '-';
                                            }
                                            ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-900 font-medium">
                                            <?php echo isset($employee['net_salary']) ? number_format($employee['net_salary'], 2, ',', '.') . ' ₺' : '-'; ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-center">
                                            <?php if (isset($employee['payment_status'])): ?>
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                                    <?php 
                                                    switch ($employee['payment_status']) {
                                                        case 'pending':
                                                            echo 'bg-yellow-100 text-yellow-800';
                                                            break;
                                                        case 'paid':
                                                            echo 'bg-green-100 text-green-800';
                                                            break;
                                                        case 'cancelled':
                                                            echo 'bg-red-100 text-red-800';
                                                            break;
                                                        default:
                                                            echo 'bg-gray-100 text-gray-800';
                                                    }
                                                    ?>">
                                                    <?php 
                                                    switch ($employee['payment_status']) {
                                                        case 'pending':
                                                            echo 'Beklemede';
                                                            break;
                                                        case 'paid':
                                                            echo 'Ödendi';
                                                            break;
                                                        case 'cancelled':
                                                            echo 'İptal Edildi';
                                                            break;
                                                        default:
                                                            echo $employee['payment_status'];
                                                    }
                                                    ?>
                                                </span>
                                            <?php else: ?>
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                                                    Hesaplanmadı
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                            <?php if (isset($employee['payroll_id'])): ?>
                                                <a href="view_payslip.php?id=<?php echo $employee['payroll_id']; ?>" class="text-blue-600 hover:text-blue-900">
                                                    <svg class="w-5 h-5 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>
                                                    </svg>
                                                    Görüntüle
                                                </a>
                                            <?php else: ?>
                                                <span class="text-gray-400">Hesaplanmadı</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="p-6 text-center">
                        <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path>
                        </svg>
                        <h3 class="mt-2 text-sm font-medium text-gray-900">Çalışan Bulunamadı</h3>
                        <p class="mt-1 text-sm text-gray-500">Bu dönemde aktif çalışan bulunmamaktadır.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Add any JavaScript functionality here if needed
        
        // Example: Highlight rows on hover
        const tableRows = document.querySelectorAll('tbody tr');
        tableRows.forEach(row => {
            row.addEventListener('mouseenter', function() {
                this.classList.add('bg-gray-50');
            });
            row.addEventListener('mouseleave', function() {
                this.classList.remove('bg-gray-50');
            });
        });
    });
</script>

<?php include 'includes/footer.php'; ?>