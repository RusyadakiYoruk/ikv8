<?php
// Login page
session_start();

// Load configuration
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';

// Set timezone
date_default_timezone_set(DEFAULT_TIMEZONE);

// Connect to database
$database = new Database();
$db = $database->connect();

// Check if user is already logged in
if (is_logged_in()) {
    redirect('index.php');
}

// Check for remember me cookie
if (!is_logged_in() && isset($_COOKIE['remember_me_token'])) {
    $token = $_COOKIE['remember_me_token'];
    $stmt = $db->prepare("SELECT user_id, expiry FROM remember_me_tokens WHERE token = :token AND expiry > NOW() LIMIT 1");
    $stmt->execute(['token' => $token]);
    $token_data = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($token_data) {
        // Token is valid, get user data
        $stmt = $db->prepare("SELECT id, email, role FROM users WHERE id = :id AND is_active = 1 LIMIT 1");
        $stmt->execute(['id' => $token_data['user_id']]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            // Set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_role'] = $user['role'];
            
            // Update last login time
            $stmt = $db->prepare("UPDATE users SET last_login = NOW() WHERE id = :id");
            $stmt->execute(['id' => $user['id']]);
            
            // Redirect to dashboard
            redirect('index.php');
        }
    }
}

// Process login form
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
        $error = 'Geçersiz form gönderimi. Lütfen tekrar deneyin.';
    } else {
        // Get and sanitize input
        $email = sanitize($_POST['email']);
        $password = $_POST['password']; // Don't sanitize password
        $remember = isset($_POST['remember']) ? true : false;
        
        // Validate input
        if (empty($email) || empty($password)) {
            $error = 'Lütfen email ve şifrenizi girin.';
        } else {
            // Attempt to authenticate user
            if (authenticate_user($email, $password)) {
                // Set remember me cookie if requested
                if ($remember) {
                    // Generate a unique token
                    $token = bin2hex(random_bytes(32));
                    
                    // Set expiry time to 12 hours from now
                    $expiry = date('Y-m-d H:i:s', time() + (12 * 60 * 60));
                    
                    // Store token in database
                    $stmt = $db->prepare("INSERT INTO remember_me_tokens (user_id, token, expiry) VALUES (:user_id, :token, :expiry)");
                    $stmt->execute([
                        'user_id' => $_SESSION['user_id'],
                        'token' => $token,
                        'expiry' => $expiry
                    ]);
                    
                    // Set cookie with 12 hour expiry
                    setcookie('remember_me_token', $token, time() + (12 * 60 * 60), '/', '', false, true);
                }
                
                // Redirect to dashboard
                redirect('index.php');
            } else {
                $error = 'Geçersiz email veya şifre.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Giriş - İK Yönetim Portalı</title>
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex items-center justify-center">
        <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
            <div class="text-center mb-8">
                <h1 class="text-2xl font-bold text-gray-800">İK Yönetim Portalı</h1>
                <p class="text-gray-600">Devam etmek için giriş yapın</p>
            </div>
            
            <?php if (!empty($error)): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                    <span class="block sm:inline"><?php echo $error; ?></span>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                
                <div class="mb-4">
                    <label for="email" class="block text-gray-700 text-sm font-bold mb-2">Email</label>
                    <input type="email" id="email" name="email" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                </div>
                
                <div class="mb-6">
                    <label for="password" class="block text-gray-700 text-sm font-bold mb-2">Şifre</label>
                    <input type="password" id="password" name="password" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                </div>
                
                <div class="flex items-center justify-between mb-6">
                    <div class="flex items-center">
                        <input type="checkbox" id="remember" name="remember" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                        <label for="remember" class="ml-2 block text-sm text-gray-900">Beni hatırla (12 saat)</label>
                    </div>
                    <a href="forgot-password.php" class="text-sm text-blue-600 hover:text-blue-800">Şifremi unuttum</a>
                </div>
                
                <div class="mb-6">
                    <button type="submit" class="w-full bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                        Giriş Yap
                    </button>
                </div>
            </form>
            
            <div class="text-center text-gray-500 text-xs">
                &copy; <?php echo date('Y'); ?> İK Yönetim Portalı. Tüm hakları saklıdır.
            </div>
        </div>
    </div>
</body>
</html>