<?php
// Add Employee Page
session_start();

// Load configuration
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';

// Set timezone
date_default_timezone_set(DEFAULT_TIMEZONE);

// Connect to database
$database = new Database();
$db = $database->connect();

// Check if user is logged in and has admin or manager role
require_role(['admin', 'manager']);

// Get user information
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

// Get departments for dropdown
$stmt = $db->query("SELECT * FROM departments ORDER BY name");
$departments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get branches for dropdown
$stmt = $db->query("SELECT * FROM branches ORDER BY name");
$branches = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get job titles for dropdown
$stmt = $db->query("SELECT * FROM job_titles ORDER BY title");
$job_titles = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get managers for dropdown - Fixed query to not rely on is_manager column
// Yönetici listesini al
$managers_query = "
    SELECT 
        e.id,
        e.first_name,
        e.last_name,
        jt.title as job_title,
        d.name as department_name
    FROM employees e
    INNER JOIN job_titles jt ON e.job_title_id = jt.id
    INNER JOIN departments d ON e.department_id = d.id
    WHERE e.termination_date IS NULL
    ORDER BY d.name, e.first_name, e.last_name
";

$stmt = $db->query($managers_query);
$managers = $stmt->fetchAll(PDO::FETCH_ASSOC);


// Initialize variables
$employee = [
    'first_name' => '',
    'last_name' => '',
    'middle_name' => '',
    'birth_date' => '',
    'gender' => '',
    'nationality' => '',
    'passport_number' => '',
    'passport_expiry' => '',
    'address' => '',
    'phone' => '',
    'emergency_contact_name' => '',
    'emergency_contact_phone' => '',
    'hire_date' => date('Y-m-d'),
    'termination_date' => '',
    'department_id' => '',
    'branch_id' => '',
    'job_title_id' => '',
    'manager_id' => '',
    'employment_type' => 'full-time',
    'salary_type' => 'monthly',
    'salary_amount' => '',
    'salary_currency' => 'TRY', // Default currency
    'bank_account' => '',
    'tax_id' => '',
    'social_security_number' => '',
    'notes' => ''
];

$errors = [];

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
        $errors['general'] = 'Geçersiz form gönderimi. Lütfen tekrar deneyin.';
    } else {
        // Sanitize and validate input
        $employee['first_name'] = sanitize($_POST['first_name'] ?? '');
        $employee['last_name'] = sanitize($_POST['last_name'] ?? '');
        $employee['middle_name'] = sanitize($_POST['middle_name'] ?? '');
        $employee['birth_date'] = sanitize($_POST['birth_date'] ?? '');
        $employee['gender'] = sanitize($_POST['gender'] ?? '');
        $employee['nationality'] = sanitize($_POST['nationality'] ?? '');
        $employee['passport_number'] = sanitize($_POST['passport_number'] ?? '');
        $employee['passport_expiry'] = sanitize($_POST['passport_expiry'] ?? '');
        $employee['address'] = sanitize($_POST['address'] ?? '');
        $employee['phone'] = sanitize($_POST['phone'] ?? '');
        $employee['emergency_contact_name'] = sanitize($_POST['emergency_contact_name'] ?? '');
        $employee['emergency_contact_phone'] = sanitize($_POST['emergency_contact_phone'] ?? '');
        $employee['hire_date'] = sanitize($_POST['hire_date'] ?? '');
        $employee['termination_date'] = sanitize($_POST['termination_date'] ?? '');
        $employee['department_id'] = (int)($_POST['department_id'] ?? 0);
        $employee['branch_id'] = (int)($_POST['branch_id'] ?? 0);
        $employee['job_title_id'] = (int)($_POST['job_title_id'] ?? 0);
        $employee['manager_id'] = (int)($_POST['manager_id'] ?? 0);
        $employee['employment_type'] = sanitize($_POST['employment_type'] ?? 'full-time');
        $employee['salary_type'] = sanitize($_POST['salary_type'] ?? 'monthly');
        $employee['salary_amount'] = sanitize($_POST['salary_amount'] ?? '');
        $employee['salary_currency'] = sanitize($_POST['salary_currency'] ?? 'TRY');
        $employee['bank_account'] = sanitize($_POST['bank_account'] ?? '');
        $employee['tax_id'] = sanitize($_POST['tax_id'] ?? '');
        $employee['social_security_number'] = sanitize($_POST['social_security_number'] ?? '');
        $employee['notes'] = sanitize($_POST['notes'] ?? '');
        
        // Validate required fields
        if (empty($employee['first_name'])) {
            $errors['first_name'] = 'Ad alanı zorunludur.';
        }
        
        if (empty($employee['last_name'])) {
            $errors['last_name'] = 'Soyad alanı zorunludur.';
        }
        
        if (empty($employee['hire_date'])) {
            $errors['hire_date'] = 'İşe alım tarihi zorunludur.';
        } elseif (!validate_date($employee['hire_date'])) {
            $errors['hire_date'] = 'Geçerli bir tarih giriniz.';
        }
        
        if (!empty($employee['birth_date']) && !validate_date($employee['birth_date'])) {
            $errors['birth_date'] = 'Geçerli bir tarih giriniz.';
        }
        
        if (!empty($employee['passport_expiry']) && !validate_date($employee['passport_expiry'])) {
            $errors['passport_expiry'] = 'Geçerli bir tarih giriniz.';
        }
        
        if (!empty($employee['termination_date']) && !validate_date($employee['termination_date'])) {
            $errors['termination_date'] = 'Geçerli bir tarih giriniz.';
        }
        
        if (empty($employee['department_id'])) {
            $errors['department_id'] = 'Departman seçimi zorunludur.';
        }
        
        if (empty($employee['job_title_id'])) {
            $errors['job_title_id'] = 'İş unvanı seçimi zorunludur.';
        }
        
        // Validate salary amount if provided
        if (!empty($employee['salary_amount']) && !is_numeric(str_replace(['.',','], '', $employee['salary_amount']))) {
            $errors['salary_amount'] = 'Geçerli bir maaş tutarı giriniz.';
        }
        
        // If no errors, insert employee
        if (empty($errors)) {
            try {
                // Begin transaction
                $db->beginTransaction();
                
                // Format salary amount (remove currency formatting)
                if (!empty($employee['salary_amount'])) {
                    $employee['salary_amount'] = str_replace(['.', ','], ['', '.'], $employee['salary_amount']);
                } else {
                    $employee['salary_amount'] = null;
                }
                
                // Insert employee
                $sql = "INSERT INTO employees (
                            first_name, last_name, middle_name, birth_date, gender, nationality,
                            passport_number, passport_expiry, address, phone, emergency_contact_name,
                            emergency_contact_phone, hire_date, termination_date, department_id,
                            branch_id, job_title_id, manager_id, employment_type, salary_type,
                            salary_amount, bank_account, tax_id, social_security_number, notes
                        ) VALUES (
                            :first_name, :last_name, :middle_name, :birth_date, :gender, :nationality,
                            :passport_number, :passport_expiry, :address, :phone, :emergency_contact_name,
                            :emergency_contact_phone, :hire_date, :termination_date, :department_id,
                            :branch_id, :job_title_id, :manager_id, :employment_type, :salary_type,
                            :salary_amount, :bank_account, :tax_id, :social_security_number, :notes
                        )";
                
                $stmt = $db->prepare($sql);
                $stmt->execute([
                    'first_name' => $employee['first_name'],
                    'last_name' => $employee['last_name'],
                    'middle_name' => $employee['middle_name'] ?: null,
                    'birth_date' => $employee['birth_date'] ?: null,
                    'gender' => $employee['gender'] ?: null,
                    'nationality' => $employee['nationality'] ?: null,
                    'passport_number' => $employee['passport_number'] ?: null,
                    'passport_expiry' => $employee['passport_expiry'] ?: null,
                    'address' => $employee['address'] ?: null,
                    'phone' => $employee['phone'] ?: null,
                    'emergency_contact_name' => $employee['emergency_contact_name'] ?: null,
                    'emergency_contact_phone' => $employee['emergency_contact_phone'] ?: null,
                    'hire_date' => $employee['hire_date'],
                    'termination_date' => $employee['termination_date'] ?: null,
                    'department_id' => $employee['department_id'] ?: null,
                    'branch_id' => $employee['branch_id'] ?: null,
                    'job_title_id' => $employee['job_title_id'] ?: null,
                    'manager_id' => $employee['manager_id'] ?: null,
                    'employment_type' => $employee['employment_type'],
                    'salary_type' => $employee['salary_type'],
                    'salary_amount' => $employee['salary_amount'],
                    'bank_account' => $employee['bank_account'] ?: null,
                    'tax_id' => $employee['tax_id'] ?: null,
                    'social_security_number' => $employee['social_security_number'] ?: null,
                    'notes' => $employee['notes'] ?: null
                ]);
                
                $employee_id = $db->lastInsertId();
                
                // Save salary currency in employee_meta table if it's not the default
                if ($employee['salary_currency'] !== 'TRY' && !empty($employee['salary_amount'])) {
                    $stmt = $db->prepare("INSERT INTO employee_meta (employee_id, meta_key, meta_value) VALUES (:employee_id, 'salary_currency', :currency)");
                    $stmt->execute([
                        'employee_id' => $employee_id,
                        'currency' => $employee['salary_currency']
                    ]);
                }
                
                // Log the action
                $stmt = $db->prepare("INSERT INTO activity_logs (user_id, activity_type, description, ip_address) VALUES (:user_id, 'employee_add', :description, :ip_address)");
                $stmt->execute([
                    'user_id' => $user_id,
                    'description' => "Yeni çalışan eklendi: {$employee['first_name']} {$employee['last_name']} (ID: {$employee_id})",
                    'ip_address' => $_SERVER['REMOTE_ADDR']
                ]);
                
                // Commit transaction
                $db->commit();
                
                // Set success message and redirect
                set_flash_message('employee_success', "Çalışan başarıyla eklendi: {$employee['first_name']} {$employee['last_name']}", 'success');
                redirect('employees.php');
                exit;
                
            } catch (Exception $e) {
                // Rollback transaction on error
                $db->rollBack();
                $errors['general'] = 'Çalışan eklenirken bir hata oluştu: ' . $e->getMessage();
                error_log('Çalışan ekleme hatası: ' . $e->getMessage());
            }
        }
    }
}

// Include header
include 'includes/header.php';
?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const departmentSelect = document.getElementById('department_id');
    const managerSelect = document.getElementById('manager_id');
    
    // Departman değiştiğinde yönetici listesini filtrele
    departmentSelect.addEventListener('change', function() {
        const selectedDepartment = this.options[this.selectedIndex].text;
        const managerOptions = managerSelect.options;
        
        // "Seçiniz" seçeneğini her zaman göster
        managerSelect.value = '';
        
        // Tüm seçenekleri gözden geçir
        for (let i = 1; i < managerOptions.length; i++) {
            const option = managerOptions[i];
            const managerDepartment = option.getAttribute('data-department');
            
            // Seçili departmana ait yöneticileri göster, diğerlerini gizle
            if (selectedDepartment === managerDepartment || selectedDepartment === '') {
                option.style.display = '';
            } else {
                option.style.display = 'none';
            }
        }
    });
});
</script>
<div class="flex h-screen bg-gray-100">
    <!-- Sidebar -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- Main Content -->
    <div class="flex-1 overflow-auto ml-0 lg:ml-64 pt-16">
        <div class="py-6 px-8">
            <!-- Page Header -->
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold text-gray-800">Yeni Çalışan Ekle</h1>
                <nav class="flex" aria-label="Breadcrumb">
                    <ol class="inline-flex items-center space-x-1 md:space-x-3">
                        <li class="inline-flex items-center">
                            <a href="index.php" class="text-gray-700 hover:text-gray-900 inline-flex items-center">
                                <svg class="w-5 h-5 mr-2.5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"></path>
                                </svg>
                                Dashboard
                            </a>
                        </li>
                        <li>
                            <div class="flex items-center">
                            <svg class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <a href="employees.php" class="ml-1 text-gray-700 hover:text-gray-900 md:ml-2">Çalışanlar</a>
                            </div>
                        </li>
                        <li aria-current="page">
                            <div class="flex items-center">
                                <svg class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span class="ml-1 text-gray-500 md:ml-2">Yeni Çalışan Ekle</span>
                            </div>
                        </li>
                    </ol>
                </nav>
            </div>
            
            <!-- Error Messages -->
            <?php if (isset($errors['general'])): ?>
                <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                    <p><?php echo $errors['general']; ?></p>
                </div>
            <?php endif; ?>
            
            <!-- Employee Form -->
            <div class="bg-white rounded-lg shadow">
                <div class="border-b px-4 py-3">
                    <h3 class="text-lg font-semibold text-gray-700">Çalışan Bilgileri</h3>
                </div>
                <div class="p-6">
                    <form method="POST" action="add_employee.php">
                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                        
                        <!-- Personal Information Section -->
                        <div class="mb-8">
                            <h4 class="text-md font-medium text-gray-700 mb-4 pb-2 border-b">Kişisel Bilgiler</h4>
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <!-- First Name -->
                                <div>
                                    <label for="first_name" class="block text-sm font-medium text-gray-700">Ad <span class="text-red-500">*</span></label>
                                    <input type="text" name="first_name" id="first_name" value="<?php echo htmlspecialchars($employee['first_name']); ?>" required class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md <?php echo isset($errors['first_name']) ? 'border-red-500' : ''; ?>">
                                    <?php if (isset($errors['first_name'])): ?>
                                        <p class="mt-1 text-sm text-red-500"><?php echo $errors['first_name']; ?></p>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- Middle Name -->
                                <div>
                                    <label for="middle_name" class="block text-sm font-medium text-gray-700">İkinci Ad</label>
                                    <input type="text" name="middle_name" id="middle_name" value="<?php echo htmlspecialchars($employee['middle_name']); ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                
                                <!-- Last Name -->
                                <div>
                                    <label for="last_name" class="block text-sm font-medium text-gray-700">Soyad <span class="text-red-500">*</span></label>
                                    <input type="text" name="last_name" id="last_name" value="<?php echo htmlspecialchars($employee['last_name']); ?>" required class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md <?php echo isset($errors['last_name']) ? 'border-red-500' : ''; ?>">
                                    <?php if (isset($errors['last_name'])): ?>
                                        <p class="mt-1 text-sm text-red-500"><?php echo $errors['last_name']; ?></p>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- Birth Date -->
                                <div>
                                    <label for="birth_date" class="block text-sm font-medium text-gray-700">Doğum Tarihi</label>
                                    <input type="date" name="birth_date" id="birth_date" value="<?php echo htmlspecialchars($employee['birth_date']); ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md <?php echo isset($errors['birth_date']) ? 'border-red-500' : ''; ?>">
                                    <?php if (isset($errors['birth_date'])): ?>
                                        <p class="mt-1 text-sm text-red-500"><?php echo $errors['birth_date']; ?></p>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- Gender -->
                                <div>
                                    <label for="gender" class="block text-sm font-medium text-gray-700">Cinsiyet</label>
                                    <select name="gender" id="gender" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                        <option value="" <?php echo $employee['gender'] === '' ? 'selected' : ''; ?>>Seçiniz</option>
                                        <option value="male" <?php echo $employee['gender'] === 'male' ? 'selected' : ''; ?>>Erkek</option>
                                        <option value="female" <?php echo $employee['gender'] === 'female' ? 'selected' : ''; ?>>Kadın</option>
                                        <option value="other" <?php echo $employee['gender'] === 'other' ? 'selected' : ''; ?>>Diğer</option>
                                    </select>
                                </div>
                                
                                <!-- Nationality -->
                                <div>
                                    <label for="nationality" class="block text-sm font-medium text-gray-700">Uyruk</label>
                                    <select name="gender" id="gender" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                        <option value="Rusya">Rusya</option>
                                        <option value="Türkiye">Türkiye</option>
                                    </select>
                                </div>
                                
                                <!-- Passport Number -->
                                <div>
                                    <label for="passport_number" class="block text-sm font-medium text-gray-700">Pasaport Numarası</label>
                                    <input type="text" name="passport_number" id="passport_number" value="<?php echo htmlspecialchars($employee['passport_number']); ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                
                                <!-- Passport Expiry -->
                                <div>
                                    <label for="passport_expiry" class="block text-sm font-medium text-gray-700">Pasaport Geçerlilik Tarihi</label>
                                    <input type="date" name="passport_expiry" id="passport_expiry" value="<?php echo htmlspecialchars($employee['passport_expiry']); ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md <?php echo isset($errors['passport_expiry']) ? 'border-red-500' : ''; ?>">
                                    <?php if (isset($errors['passport_expiry'])): ?>
                                        <p class="mt-1 text-sm text-red-500"><?php echo $errors['passport_expiry']; ?></p>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- Address -->
                                <div class="md:col-span-3">
                                    <label for="address" class="block text-sm font-medium text-gray-700">Adres</label>
                                    <textarea name="address" id="address" rows="3" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"><?php echo htmlspecialchars($employee['address']); ?></textarea>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Contact Information Section -->
                        <div class="mb-8">
                            <h4 class="text-md font-medium text-gray-700 mb-4 pb-2 border-b">İletişim Bilgileri</h4>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <!-- Phone -->
                                <div>
                                    <label for="phone" class="block text-sm font-medium text-gray-700">Telefon</label>
                                    <input type="tel" name="phone" id="phone" value="<?php echo htmlspecialchars($employee['phone']); ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                
                                <!-- Emergency Contact Name -->
                                <div>
                                    <label for="emergency_contact_name" class="block text-sm font-medium text-gray-700">Acil Durumda Aranacak Kişi</label>
                                    <input type="text" name="emergency_contact_name" id="emergency_contact_name" value="<?php echo htmlspecialchars($employee['emergency_contact_name']); ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                
                                <!-- Emergency Contact Phone -->
                                <div>
                                    <label for="emergency_contact_phone" class="block text-sm font-medium text-gray-700">Acil Durumda Aranacak Telefon</label>
                                    <input type="tel" name="emergency_contact_phone" id="emergency_contact_phone" value="<?php echo htmlspecialchars($employee['emergency_contact_phone']); ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                            </div>
                        </div>
                        
                        <!-- Employment Information Section -->
                        <div class="mb-8">
                            <h4 class="text-md font-medium text-gray-700 mb-4 pb-2 border-b">İş Bilgileri</h4>
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <!-- Hire Date -->
                                <div>
                                    <label for="hire_date" class="block text-sm font-medium text-gray-700">İşe Giriş Tarihi <span class="text-red-500">*</span></label>
                                    <input type="date" name="hire_date" id="hire_date" value="<?php echo htmlspecialchars($employee['hire_date']); ?>" required class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md <?php echo isset($errors['hire_date']) ? 'border-red-500' : ''; ?>">
                                    <?php if (isset($errors['hire_date'])): ?>
                                        <p class="mt-1 text-sm text-red-500"><?php echo $errors['hire_date']; ?></p>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- Termination Date -->
                                <div>
                                    <label for="termination_date" class="block text-sm font-medium text-gray-700">İşten Çıkış Tarihi</label>
                                    <input type="date" name="termination_date" id="termination_date" value="<?php echo htmlspecialchars($employee['termination_date']); ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md <?php echo isset($errors['termination_date']) ? 'border-red-500' : ''; ?>">
                                    <?php if (isset($errors['termination_date'])): ?>
                                        <p class="mt-1 text-sm text-red-500"><?php echo $errors['termination_date']; ?></p>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- Department -->
                                <div>
                                    <label for="department_id" class="block text-sm font-medium text-gray-700">Departman <span class="text-red-500">*</span></label>
                                    <select name="department_id" id="department_id" required class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm <?php echo isset($errors['department_id']) ? 'border-red-500' : ''; ?>">
                                        <option value="">Seçiniz</option>
                                        <?php foreach ($departments as $department): ?>
                                            <option value="<?php echo $department['id']; ?>" <?php echo $employee['department_id'] == $department['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($department['name']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <?php if (isset($errors['department_id'])): ?>
                                        <p class="mt-1 text-sm text-red-500"><?php echo $errors['department_id']; ?></p>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- Branch -->
                                <div>
                                    <label for="branch_id" class="block text-sm font-medium text-gray-700">Şube</label>
                                    <select name="branch_id" id="branch_id" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                        <option value="">Seçiniz</option>
                                        <?php foreach ($branches as $branch): ?>
                                            <option value="<?php echo $branch['id']; ?>" <?php echo $employee['branch_id'] == $branch['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($branch['name']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <!-- Job Title -->
                                <div>
                                    <label for="job_title_id" class="block text-sm font-medium text-gray-700">İş Unvanı <span class="text-red-500">*</span></label>
                                    <select name="job_title_id" id="job_title_id" required class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm <?php echo isset($errors['job_title_id']) ? 'border-red-500' : ''; ?>">
                                        <option value="">Seçiniz</option>
                                        <?php
                                        // Tüm iş unvanlarını veritabanından çek
                                        try {
                                            $job_titles_query = $db->query("SELECT id, title FROM job_titles ORDER BY title ASC");
                                            $job_titles = $job_titles_query->fetchAll(PDO::FETCH_ASSOC);
                                            
                                            foreach ($job_titles as $job_title): 
                                        ?>
                                            <option value="<?php echo $job_title['id']; ?>" <?php echo (isset($employee['job_title_id']) && $employee['job_title_id'] == $job_title['id']) ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($job_title['title']); ?>
                                            </option>
                                        <?php 
                                            endforeach;
                                        } catch (Exception $e) {
                                            echo '<option value="">İş unvanları yüklenemedi</option>';
                                            error_log('İş unvanları çekilirken hata: ' . $e->getMessage());
                                        }
                                        ?>
                                    </select>
                                    <?php if (isset($errors['job_title_id'])): ?>
                                        <p class="mt-1 text-sm text-red-500"><?php echo $errors['job_title_id']; ?></p>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- Manager -->
                                <div class="form-group">
                                    <label for="manager_id" class="block text-sm font-medium text-gray-700">Yönetici</label>
                                    <select name="manager_id" id="manager_id" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                        <option value="">Yönetici Seçiniz</option>
                                        <?php foreach ($managers as $manager): ?>
                                            <option value="<?php echo $manager['id']; ?>" 
                                                    data-department="<?php echo htmlspecialchars($manager['department_name']); ?>">
                                                <?php echo htmlspecialchars($manager['first_name'] . ' ' . $manager['last_name'] . 
                                                    ' (' . $manager['job_title'] . ' - ' . $manager['department_name'] . ')'); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <!-- Employment Type -->
                                <div>
                                    <label for="employment_type" class="block text-sm font-medium text-gray-700">İstihdam Türü</label>
                                    <select name="employment_type" id="employment_type" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                        <option value="full-time" <?php echo $employee['employment_type'] === 'full-time' ? 'selected' : ''; ?>>Tam Zamanlı</option>
                                        <option value="part-time" <?php echo $employee['employment_type'] === 'part-time' ? 'selected' : ''; ?>>Yarı Zamanlı</option>
                                        <option value="contract" <?php echo $employee['employment_type'] === 'contract' ? 'selected' : ''; ?>>Sözleşmeli</option>
                                        <option value="temporary" <?php echo $employee['employment_type'] === 'temporary' ? 'selected' : ''; ?>>Geçici</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Salary Information Section -->
                        <div class="mb-8">
                            <h4 class="text-md font-medium text-gray-700 mb-4 pb-2 border-b">Maaş Bilgileri</h4>
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <!-- Salary Type -->
                                <div>
                                    <label for="salary_type" class="block text-sm font-medium text-gray-700">Maaş Türü</label>
                                    <select name="salary_type" id="salary_type" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                        <option value="monthly" <?php echo $employee['salary_type'] === 'monthly' ? 'selected' : ''; ?>>Aylık</option>
                                        <option value="hourly" <?php echo $employee['salary_type'] === 'hourly' ? 'selected' : ''; ?>>Saatlik</option>
                                    </select>
                                </div>
                                
                                <!-- Salary Amount -->
                                <div>
                                    <label for="salary_amount" class="block text-sm font-medium text-gray-700">Maaş Tutarı</label>
                                    <input type="text" name="salary_amount" id="salary_amount" value="<?php echo htmlspecialchars($employee['salary_amount']); ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md <?php echo isset($errors['salary_amount']) ? 'border-red-500' : ''; ?>">
                                    <?php if (isset($errors['salary_amount'])): ?>
                                        <p class="mt-1 text-sm text-red-500"><?php echo $errors['salary_amount']; ?></p>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- Salary Currency -->
                                <div>
                                    <label for="salary_currency" class="block text-sm font-medium text-gray-700">Para Birimi</label>
                                    <select name="salary_currency" id="salary_currency" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                        <option value="TRY" <?php echo $employee['salary_currency'] === 'TRY' ? 'selected' : ''; ?>>Türk Lirası (₺)</option>
                                        <option value="USD" <?php echo $employee['salary_currency'] === 'USD' ? 'selected' : ''; ?>>Amerikan Doları ($)</option>
                                        <option value="EUR" <?php echo $employee['salary_currency'] === 'EUR' ? 'selected' : ''; ?>>Euro (€)</option>
                                        <option value="GBP" <?php echo $employee['salary_currency'] === 'GBP' ? 'selected' : ''; ?>>İngiliz Sterlini (£)</option>
                                        <option value="RUB" <?php echo $employee['salary_currency'] === 'RUB' ? 'selected' : ''; ?>>Rus Rublesi (₽)</option>
                                    </select>
                                </div>
                                
                                <!-- Bank Account -->
                                <div>
                                    <label for="bank_account" class="block text-sm font-medium text-gray-700">Banka Hesap Numarası</label>
                                    <input type="text" name="bank_account" id="bank_account" value="<?php echo htmlspecialchars($employee['bank_account']); ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                
                                <!-- Tax ID -->
                                <div>
                                    <label for="tax_id" class="block text-sm font-medium text-gray-700">Vergi Numarası</label>
                                    <input type="text" name="tax_id" id="tax_id" value="<?php echo htmlspecialchars($employee['tax_id']); ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                
                                <!-- Social Security Number -->
                                <div>
                                    <label for="social_security_number" class="block text-sm font-medium text-gray-700">Sosyal Güvenlik Numarası</label>
                                    <input type="text" name="social_security_number" id="social_security_number" value="<?php echo htmlspecialchars($employee['social_security_number']); ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                            </div>
                        </div>
                        
                        <!-- Additional Information Section -->
                        <div class="mb-8">
                            <h4 class="text-md font-medium text-gray-700 mb-4 pb-2 border-b">Ek Bilgiler</h4>
                            <div class="grid grid-cols-1 gap-6">
                                <!-- Notes -->
                                <div>
                                    <label for="notes" class="block text-sm font-medium text-gray-700">Notlar</label>
                                    <textarea name="notes" id="notes" rows="4" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"><?php echo htmlspecialchars($employee['notes']); ?></textarea>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Form Actions -->
                        <div class="flex justify-end space-x-3">
                            <a href="employees.php" class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                İptal
                            </a>
                            <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                <svg class="mr-2 -ml-1 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                                </svg>
                                Çalışanı Ekle
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
include 'includes/footer.php';
?>