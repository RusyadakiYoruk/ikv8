<?php
// Job Titles List Page
session_start();

// Load configuration
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';

// Set timezone
date_default_timezone_set(DEFAULT_TIMEZONE);

// Connect to database
$database = new Database();
$db = $database->connect();

// Check if user is logged in and has admin role
require_role(['admin']);

// Get user information
$user_id = $_SESSION['user_id'];

// Process job title actions (add, edit, delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
        set_flash_message('job_title_error', 'Geçersiz form gönderimi. Lütfen tekrar deneyin.', 'danger');
    } else {
        try {
            // Begin transaction
            $db->beginTransaction();
            
            // Add Job Title
            if (isset($_POST['action']) && $_POST['action'] === 'add') {
                $stmt = $db->prepare("INSERT INTO job_titles (title, description, base_salary) VALUES (?, ?, ?)");
                $stmt->execute([
                    sanitize($_POST['title']),
                    !empty($_POST['description']) ? sanitize($_POST['description']) : null,
                    !empty($_POST['base_salary']) ? str_replace(['.', ','], ['', '.'], $_POST['base_salary']) : null
                ]);
                
                $job_title_id = $db->lastInsertId();
                
                // Log activity
                $stmt = $db->prepare("INSERT INTO activity_logs (user_id, activity_type, description, ip_address) VALUES (?, ?, ?, ?)");
                $stmt->execute([
                    $user_id,
                    'job_title_add',
                    "Yeni unvan eklendi: {$_POST['title']} (ID: {$job_title_id})",
                    $_SERVER['REMOTE_ADDR']
                ]);
                
                set_flash_message('job_title_success', "Unvan başarıyla eklendi: {$_POST['title']}", 'success');
            }
            
            // Edit Job Title
            elseif (isset($_POST['action']) && $_POST['action'] === 'edit') {
                $stmt = $db->prepare("UPDATE job_titles SET title = ?, description = ?, base_salary = ? WHERE id = ?");
                $stmt->execute([
                    sanitize($_POST['title']),
                    !empty($_POST['description']) ? sanitize($_POST['description']) : null,
                    !empty($_POST['base_salary']) ? str_replace(['.', ','], ['', '.'], $_POST['base_salary']) : null,
                    (int)$_POST['job_title_id']
                ]);
                
                // Log activity
                $stmt = $db->prepare("INSERT INTO activity_logs (user_id, activity_type, description, ip_address) VALUES (?, ?, ?, ?)");
                $stmt->execute([
                    $user_id,
                    'job_title_edit',
                    "Unvan güncellendi: {$_POST['title']} (ID: {$_POST['job_title_id']})",
                    $_SERVER['REMOTE_ADDR']
                ]);
                
                set_flash_message('job_title_success', "Unvan başarıyla güncellendi: {$_POST['title']}", 'success');
            }
            
            // Delete Job Title
            elseif (isset($_POST['action']) && $_POST['action'] === 'delete') {
                // Check if job title has employees
                $stmt = $db->prepare("SELECT COUNT(*) FROM employees WHERE job_title_id = ?");
                $stmt->execute([(int)$_POST['job_title_id']]);
                $employee_count = $stmt->fetchColumn();
                
                if ($employee_count > 0) {
                    throw new Exception('Bu unvana sahip çalışanlar bulunduğu için silinemez.');
                }
                
                // Get job title name for logging
                $stmt = $db->prepare("SELECT title FROM job_titles WHERE id = ?");
                $stmt->execute([(int)$_POST['job_title_id']]);
                $job_title_name = $stmt->fetchColumn();
                
                // Delete job title
                $stmt = $db->prepare("DELETE FROM job_titles WHERE id = ?");
                $stmt->execute([(int)$_POST['job_title_id']]);
                
                // Log activity
                $stmt = $db->prepare("INSERT INTO activity_logs (user_id, activity_type, description, ip_address) VALUES (?, ?, ?, ?)");
                $stmt->execute([
                    $user_id,
                    'job_title_delete',
                    "Unvan silindi: {$job_title_name} (ID: {$_POST['job_title_id']})",
                    $_SERVER['REMOTE_ADDR']
                ]);
                
                set_flash_message('job_title_success', "Unvan başarıyla silindi: {$job_title_name}", 'success');
            }
            
            // Commit transaction
            $db->commit();
            
        } catch (Exception $e) {
            // Rollback transaction on error
            $db->rollBack();
            set_flash_message('job_title_error', $e->getMessage(), 'danger');
        }
    }
    
    // Redirect to prevent form resubmission
    redirect('job_titles.php');
    exit;
}

// Get job titles with employee counts
$sql = "SELECT jt.*,
               (SELECT COUNT(*) FROM employees WHERE job_title_id = jt.id) as employee_count
        FROM job_titles jt
        ORDER BY jt.title";

$stmt = $db->query($sql);
$job_titles = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Include header
include 'includes/header.php';
?>

<div class="flex h-screen bg-gray-100">
    <!-- Sidebar -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- Main Content -->
    <div class="flex-1 overflow-auto ml-0 lg:ml-64 pt-16">
        <div class="py-6 px-8">
            <!-- Page Header -->
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold text-gray-800">Unvanlar</h1>
                <button type="button" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500" onclick="showAddJobTitleModal()">
                    <svg class="mr-2 -ml-1 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                    </svg>
                    Yeni Unvan Ekle
                </button>
            </div>
            
            <!-- Flash Messages -->
            <?php if (isset($_SESSION['flash_messages']['job_title_success'])): ?>
                <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6" role="alert">
                    <p><?php echo $_SESSION['flash_messages']['job_title_success']['message']; ?></p>
                </div>
                <?php unset($_SESSION['flash_messages']['job_title_success']); ?>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['flash_messages']['job_title_error'])): ?>
                <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                    <p><?php echo $_SESSION['flash_messages']['job_title_error']['message']; ?></p>
                </div>
                <?php unset($_SESSION['flash_messages']['job_title_error']); ?>
            <?php endif; ?>
            
            <!-- Job Titles Table -->
<div class="bg-white rounded-lg shadow overflow-hidden">
    <div class="p-6">
        <table id="jobTitlesTable" class="display responsive nowrap" style="width:100%">
            <thead>
                <tr>
                    <th>Unvan</th>
                    <th>Açıklama</th>
                    <th>Baz Maaş</th>
                    <th>Çalışan Sayısı</th>
                    <th>İşlemler</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($job_titles as $title): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($title['title']); ?></td>
                        <td><?php echo htmlspecialchars($title['description'] ?? ''); ?></td>
                        <td>
                            <?php 
                            if (!empty($title['base_salary'])) {
                                echo number_format($title['base_salary'], 2, ',', '.') . ' ₺';
                            } else {
                                echo '-';
                            }
                            ?>
                        </td>
                        <td><?php echo $title['employee_count']; ?></td>
                        <td>
                            <div class="flex space-x-3">
                                <button type="button" class="text-indigo-600 hover:text-indigo-900" 
                                        onclick='showEditJobTitleModal(<?php echo json_encode($title); ?>)'>
                                    <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                    </svg>
                                </button>
                                <?php if ($title['employee_count'] == 0): ?>
                                    <button type="button" class="text-red-600 hover:text-red-900" 
                                            onclick="showDeleteJobTitleModal(<?php echo $title['id']; ?>, '<?php echo htmlspecialchars($title['title']); ?>')">
                                        <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                        </svg>
                                    </button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Sayfanın en altına JavaScript kodu -->
<script>
$(document).ready(function() {
    $('#jobTitlesTable').DataTable({
        responsive: true,
        language: {
            url: '//cdn.datatables.net/plug-ins/1.13.7/i18n/tr.json'
        },
        dom: 'Bfrtip',
        lengthMenu: [
            [ 10, 25, 50, -1 ],
            [ '10 Kayıt', '25 Kayıt', '50 Kayıt', 'Tümü' ]
        ],
        buttons: [
            {
                extend: 'collection',
                text: 'Dışa Aktar',
                buttons: [
                    {
                        extend: 'copy',
                        text: 'Kopyala',
                        exportOptions: {
                            columns: [0,1,2,3]
                        }
                    },
                    {
                        extend: 'excel',
                        text: 'Excel',
                        exportOptions: {
                            columns: [0,1,2,3]
                        }
                    },
                    {
                        extend: 'pdf',
                        text: 'PDF',
                        exportOptions: {
                            columns: [0,1,2,3]
                        }
                    },
                    {
                        extend: 'print',
                        text: 'Yazdır',
                        exportOptions: {
                            columns: [0,1,2,3]
                        }
                    }
                ]
            },
            {
                extend: 'pageLength',
                text: 'Kayıt Sayısı'
            }
        ],
        order: [[0, 'asc']],
        columnDefs: [
            {
                targets: -1,
                orderable: false,
                searchable: false
            }
        ],
        pageLength: 10
    });

    // DataTables stil düzenlemeleri
    $('.dataTables_wrapper .dt-buttons')
        .addClass('mb-4')
        .find('button')
        .addClass('bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mr-2');
});
</script>

<!-- Özel CSS Stilleri -->
<style>
.dataTables_wrapper .dataTables_filter input {
    border: 1px solid #d1d5db;
    border-radius: 0.375rem;
    padding: 0.5rem;
    margin-left: 0.5rem;
}

.dataTables_wrapper .dataTables_length select {
    border: 1px solid #d1d5db;
    border-radius: 0.375rem;
    padding: 0.5rem;
    margin: 0 0.5rem;
}

.dataTables_wrapper .dataTables_paginate .paginate_button {
    padding: 0.5rem 1rem;
    margin: 0 0.25rem;
    border: 1px solid #d1d5db;
    border-radius: 0.375rem;
}

.dataTables_wrapper .dataTables_paginate .paginate_button.current {
    background: #3b82f6 !important;
    color: white !important;
    border: 1px solid #3b82f6;
}

.dt-button-collection {
    padding: 0.5rem;
    border: 1px solid #d1d5db;
    border-radius: 0.375rem;
    background-color: white;
}

.dt-button-collection .dt-button {
    display: block;
    padding: 0.5rem 1rem;
    margin: 0.25rem 0;
    width: 100%;
    text-align: left;
}
</style>
        </div>
    </div>
</div>

<!-- Add Job Title Modal -->
<div id="addJobTitleModal" class="fixed inset-0 z-50 overflow-y-auto hidden" aria-labelledby="modal-title" role="dialog" aria-modal="true">
    <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" aria-hidden="true"></div>
        <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
        <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
            <form method="POST" action="job_titles.php">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="add">
                
                <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                    <div class="sm:flex sm:items-start">
                        <div class="mt-3 text-center sm:mt-0 sm:text-left w-full">
                            <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                                Yeni Unvan Ekle
                            </h3>
                            <div class="mt-4 space-y-4">
                                <div>
                                    <label for="title" class="block text-sm font-medium text-gray-700">Unvan Adı <span class="text-red-500">*</span></label>
                                    <input type="text" name="title" id="title" required class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                <div>
                                    <label for="description" class="block text-sm font-medium text-gray-700">Açıklama</label>
                                    <textarea name="description" id="description" rows="3" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"></textarea>
                                </div>
                                <div>
                                    <label for="base_salary" class="block text-sm font-medium text-gray-700">Baz Maaş</label>
                                    <input type="text" name="base_salary" id="base_salary" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                    <button type="submit" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm">
                        Ekle
                    </button>
                    <button type="button" class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm close-modal">
                        İptal
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Job Title Modal -->
<div id="editJobTitleModal" class="fixed inset-0 z-50 overflow-y-auto hidden" aria-labelledby="modal-title" role="dialog" aria-modal="true">
    <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" aria-hidden="true"></div>
        <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
        <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
            <form method="POST" action="job_titles.php">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="job_title_id" id="edit_job_title_id">
                
                <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                    <div class="sm:flex sm:items-start">
                        <div class="mt-3 text-center sm:mt-0 sm:text-left w-full">
                            <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                                Unvan Düzenle
                            </h3>
                            <div class="mt-4 space-y-4">
                                <div>
                                    <label for="edit_title" class="block text-sm font-medium text-gray-700">Unvan Adı <span class="text-red-500">*</span></label>
                                    <input type="text" name="title" id="edit_title" required class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                <div>
                                    <label for="edit_description" class="block text-sm font-medium text-gray-700">Açıklama</label>
                                    <textarea name="description" id="edit_description" rows="3" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"></textarea>
                                </div>
                                <div>
                                    <label for="edit_base_salary" class="block text-sm font-medium text-gray-700">Baz Maaş</label>
                                    <input type="text" name="base_salary" id="edit_base_salary" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                    <button type="submit" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm">
                        Güncelle
                    </button>
                    <button type="button" class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm close-modal">
                        İptal
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Job Title Modal -->
<div id="deleteJobTitleModal" class="fixed inset-0 z-50 overflow-y-auto hidden" aria-labelledby="modal-title" role="dialog" aria-modal="true">
    <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" aria-hidden="true"></div>
        <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
        <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
            <form method="POST" action="job_titles.php">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="job_title_id" id="delete_job_title_id">
                
                <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                    <div class="sm:flex sm:items-start">
                        <div class="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-red-100 sm:mx-0 sm:h-10 sm:w-10">
                            <svg class="h-6 w-6 text-red-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                            </svg>
                        </div>
                        <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                            <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                                Unvanı Sil
                            </h3>
                            <div class="mt-2">
                                <p class="text-sm text-gray-500">
                                    <span id="delete_job_title_name"></span> unvanını silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                    <button type="submit" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-red-600 text-base font-medium text-white hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 sm:ml-3 sm:w-auto sm:text-sm">
                        Sil
                    </button>
                    <button type="button" class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm close-modal">
                        İptal
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- JavaScript for modals and form handling -->
<script>
    // Format salary inputs with thousand separators
    function formatSalary(input) {
        let value = input.value.replace(/[^\d,]/g, '').replace(',', '.');
        if (value) {
            value = parseFloat(value).toLocaleString('tr-TR', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
            input.value = value;
        }
    }
    
    // Add event listeners to salary inputs
    document.getElementById('base_salary').addEventListener('input', function(e) {
        formatSalary(this);
    });
    
    document.getElementById('edit_base_salary').addEventListener('input', function(e) {
        formatSalary(this);
    });
    
    // Show Add Job Title Modal
    function showAddJobTitleModal() {
        document.getElementById('addJobTitleModal').classList.remove('hidden');
    }
    
    // Show Edit Job Title Modal
    function showEditJobTitleModal(jobTitle) {
        document.getElementById('edit_job_title_id').value = jobTitle.id;
        document.getElementById('edit_title').value = jobTitle.title;
        document.getElementById('edit_description').value = jobTitle.description || '';
        
        // Format base salary
        if (jobTitle.base_salary) {
            document.getElementById('edit_base_salary').value = parseFloat(jobTitle.base_salary).toLocaleString('tr-TR', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        } else {
            document.getElementById('edit_base_salary').value = '';
        }
        
        document.getElementById('editJobTitleModal').classList.remove('hidden');
    }
    
    // Show Delete Job Title Modal
    function showDeleteJobTitleModal(id, title) {
        document.getElementById('delete_job_title_id').value = id;
        document.getElementById('delete_job_title_name').textContent = title;
        
        document.getElementById('deleteJobTitleModal').classList.remove('hidden');
    }
    
    // Close Modals
    document.querySelectorAll('.close-modal').forEach(button => {
        button.addEventListener('click', function() {
            document.getElementById('addJobTitleModal').classList.add('hidden');
            document.getElementById('editJobTitleModal').classList.add('hidden');
            document.getElementById('deleteJobTitleModal').classList.add('hidden');
        });
    });
    
    // Close modals when clicking outside
    window.addEventListener('click', function(event) {
        if (event.target.classList.contains('fixed')) {
            event.target.classList.add('hidden');
        }
    });
    
    // Form validation
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', function(e) {
            let titleInput = this.querySelector('input[name="title"]');
            if (!titleInput.value.trim()) {
                e.preventDefault();
                alert('Unvan adı zorunludur.');
            }
        });
    });
</script>

<?php
// Include footer
include 'includes/footer.php';
?>