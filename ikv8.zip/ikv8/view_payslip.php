<?php
// View Payslip Page
session_start();

// Load configuration
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';

// Set timezone
date_default_timezone_set(DEFAULT_TIMEZONE);

// Connect to database
$database = new Database();
$db = $database->connect();

// Check if user is logged in and has admin, finance or manager role
require_role(['admin', 'finance', 'manager']);

// Get user information
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

// Check if payroll ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    set_flash_message('payroll_error', 'Geçersiz bordro ID\'si.', 'danger');
    redirect('payroll_periods.php');
    exit;
}

$payroll_id = (int)$_GET['id'];

// Get payroll details with employee and period information
$sql = "SELECT p.*, 
        e.first_name, e.last_name, e.hire_date,
        e.bank_account, e.tax_id, e.social_security_number,
        d.name AS department_name, jt.title AS job_title,
        pp.period_name, pp.start_date, pp.end_date, pp.payment_date
        FROM payrolls p
        JOIN employees e ON p.employee_id = e.id
        JOIN payroll_periods pp ON p.period_id = pp.id
        LEFT JOIN departments d ON e.department_id = d.id
        LEFT JOIN job_titles jt ON e.job_title_id = jt.id
        WHERE p.id = :payroll_id";

$stmt = $db->prepare($sql);
$stmt->execute(['payroll_id' => $payroll_id]);
$payslip = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$payslip) {
    set_flash_message('payroll_error', 'Bordro bulunamadı.', 'danger');
    redirect('payroll_periods.php');
    exit;
}

// Check if the user has permission to view this payslip
// Managers can only view payslips of their department employees
if ($user_role === 'manager') {
    // Get manager's department
    $stmt = $db->prepare("SELECT department_id FROM employees WHERE user_id = :user_id");
    $stmt->execute(['user_id' => $user_id]);
    $manager_dept = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Check if employee belongs to manager's department
    $stmt = $db->prepare("SELECT COUNT(*) FROM employees WHERE id = :employee_id AND department_id = :department_id");
    $stmt->execute([
        'employee_id' => $payslip['employee_id'],
        'department_id' => $manager_dept['department_id']
    ]);
    
    if ($stmt->fetchColumn() == 0) {
        set_flash_message('payroll_error', 'Bu bordroyu görüntüleme yetkiniz bulunmamaktadır.', 'danger');
        redirect('payroll_periods.php');
        exit;
    }
}

// Calculate additional statistics
$total_deductions = $payslip['tax_amount'] + $payslip['insurance_amount'] + $payslip['deductions'];
$total_earnings = $payslip['base_salary'] + $payslip['allowances'];

// Format currency values
function format_currency($amount) {
    return number_format($amount, 2, ',', '.') . ' ₺';
}

// Include header
include 'includes/header.php';
?>

<div class="flex h-screen bg-gray-100">
    <!-- Sidebar -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- Main Content -->
    <div class="flex-1 overflow-auto ml-0 lg:ml-64 pt-16">
        <div class="py-6 px-8">
            <!-- Page Header -->
            <div class="flex justify-between items-center mb-6">
                <div>
                    <h1 class="text-2xl font-bold text-gray-800">Bordro Detayı</h1>
                    <p class="text-sm text-gray-600">
                        <?php echo htmlspecialchars($payslip['first_name'] . ' ' . $payslip['last_name']); ?> - 
                        <?php echo htmlspecialchars($payslip['period_name']); ?>
                    </p>
                </div>
                <div class="flex space-x-3">
                    <a href="print_payslip.php?id=<?php echo $payroll_id; ?>" target="_blank" class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"></path>
                        </svg>
                        Yazdır
                    </a>
                    <a href="generate_payroll.php?period_id=<?php echo $payslip['period_id']; ?>" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                        </svg>
                        Döneme Geri Dön
                    </a>
                </div>
            </div>
            
            <!-- Payslip Card -->
            <div class="bg-white shadow-md rounded-lg overflow-hidden mb-6">
                <div class="px-6 py-4 border-b border-gray-200 bg-gray-50 flex justify-between items-center">
                    <div>
                        <h3 class="text-lg font-semibold text-gray-800">Bordro Bilgileri</h3>
                        <p class="text-sm text-gray-600">
                            Dönem: <?php echo date('d.m.Y', strtotime($payslip['start_date'])); ?> - 
                            <?php echo date('d.m.Y', strtotime($payslip['end_date'])); ?>
                        </p>
                    </div>
                    <div>
                        <span class="px-3 py-1 inline-flex text-sm leading-5 font-semibold rounded-full 
                            <?php 
                            switch ($payslip['payment_status']) {
                                case 'pending':
                                    echo 'bg-yellow-100 text-yellow-800';
                                    break;
                                case 'paid':
                                    echo 'bg-green-100 text-green-800';
                                    break;
                                case 'cancelled':
                                    echo 'bg-red-100 text-red-800';
                                    break;
                                default:
                                    echo 'bg-gray-100 text-gray-800';
                            }
                            ?>">
                            <?php 
                            switch ($payslip['payment_status']) {
                                case 'pending':
                                    echo 'Beklemede';
                                    break;
                                case 'paid':
                                    echo 'Ödendi';
                                    break;
                                case 'cancelled':
                                    echo 'İptal Edildi';
                                    break;
                                default:
                                    echo $payslip['payment_status'];
                            }
                            ?>
                        </span>
                    </div>
                </div>
                
                <div class="p-6">
                    <!-- Employee Information -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                        <div>
                            <h4 class="text-sm font-medium text-gray-500 mb-3">Çalışan Bilgileri</h4>
                            <div class="space-y-2">
                                <div class="flex justify-between">
                                    <span class="text-sm text-gray-600">Ad Soyad:</span>
                                    <span class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($payslip['first_name'] . ' ' . $payslip['last_name']); ?></span>
                                </div>
                                <div class="flex justify-between">
                                    <span class="text-sm text-gray-600">Sicil No:</span>
                                    <span class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($payslip['employee_number'] ?? '-'); ?></span>
                                </div>
                                <div class="flex justify-between">
                                    <span class="text-sm text-gray-600">Departman:</span>
                                    <span class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($payslip['department_name'] ?? '-'); ?></span>
                                </div>
                                <div class="flex justify-between">
                                    <span class="text-sm text-gray-600">Pozisyon:</span>
                                    <span class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($payslip['job_title'] ?? '-'); ?></span>
                                </div>
                                <div class="flex justify-between">
                                    <span class="text-sm text-gray-600">İşe Başlama Tarihi:</span>
                                    <span class="text-sm font-medium text-gray-900"><?php echo date('d.m.Y', strtotime($payslip['hire_date'])); ?></span>
                                </div>
                            </div>
                        </div>
                        
                        <div>
                            <h4 class="text-sm font-medium text-gray-500 mb-3">Ödeme Bilgileri</h4>
                            <div class="space-y-2">
                                <div class="flex justify-between">
                                    <span class="text-sm text-gray-600">Ödeme Tarihi:</span>
                                    <span class="text-sm font-medium text-gray-900"><?php echo date('d.m.Y', strtotime($payslip['payment_date'])); ?></span>
                                </div>
                                <div class="flex justify-between">
                                    <span class="text-sm text-gray-600">Banka Hesabı:</span>
                                    <span class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($payslip['bank_account'] ?? '-'); ?></span>
                                </div>
                                <div class="flex justify-between">
                                    <span class="text-sm text-gray-600">Vergi No:</span>
                                    <span class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($payslip['tax_id'] ?? '-'); ?></span>
                                </div>
                                <div class="flex justify-between">
                                    <span class="text-sm text-gray-600">SGK No:</span>
                                    <span class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($payslip['social_security_number'] ?? '-'); ?></span>
                                </div>
                                <div class="flex justify-between">
                                    <span class="text-sm text-gray-600">Çalışma Günü:</span>
                                    <span class="text-sm font-medium text-gray-900"><?php echo $payslip['work_days'] ?? '-'; ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Salary Details -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <h4 class="text-sm font-medium text-gray-500 mb-3">Kazançlar</h4>
                            <div class="bg-gray-50 p-4 rounded-lg">
                                <div class="space-y-2">
                                    <div class="flex justify-between">
                                        <span class="text-sm text-gray-600">Temel Maaş:</span>
                                        <span class="text-sm font-medium text-gray-900"><?php echo format_currency($payslip['base_salary']); ?></span>
                                    </div>
                                    <div class="flex justify-between">
                                        <span class="text-sm text-gray-600">Ek Ödemeler:</span>
                                        <span class="text-sm font-medium text-gray-900"><?php echo format_currency($payslip['allowances'] ?? 0); ?></span>
                                    </div>
                                    <div class="flex justify-between border-t pt-2 mt-2">
                                        <span class="text-sm font-medium text-gray-600">Toplam Kazanç:</span>
                                        <span class="text-sm font-bold text-gray-900"><?php echo format_currency($total_earnings); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div>
                            <h4 class="text-sm font-medium text-gray-500 mb-3">Kesintiler</h4>
                            <div class="bg-gray-50 p-4 rounded-lg">
                                <div class="space-y-2">
                                    <div class="flex justify-between">
                                        <span class="text-sm text-gray-600">Gelir Vergisi:</span>
                                        <span class="text-sm font-medium text-gray-900"><?php echo format_currency($payslip['tax_amount']); ?></span>
                                    </div>
                                    <div class="flex justify-between">
                                        <span class="text-sm text-gray-600">SGK Kesintisi:</span>
                                        <span class="text-sm font-medium text-gray-900"><?php echo format_currency($payslip['insurance_amount']); ?></span>
                                    </div>
                                    <div class="flex justify-between">
                                        <span class="text-sm text-gray-600">Diğer Kesintiler:</span>
                                        <span class="text-sm font-medium text-gray-900"><?php echo format_currency($payslip['deductions'] ?? 0); ?></span>
                                    </div>
                                    <div class="flex justify-between border-t pt-2 mt-2">
                                        <span class="text-sm font-medium text-gray-600">Toplam Kesinti:</span>
                                        <span class="text-sm font-bold text-gray-900"><?php echo format_currency($total_deductions); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Net Salary -->
                    <div class="mt-6 bg-blue-50 p-4 rounded-lg">
                        <div class="flex justify-between items-center">
                            <span class="text-base font-medium text-blue-700">Net Ödeme:</span>
                            <span class="text-xl font-bold text-blue-900"><?php echo format_currency($payslip['net_salary']); ?></span>
                        </div>
                    </div>
                    
                    <!-- Notes -->
                    <?php if (!empty($payslip['notes'])): ?>
                    <div class="mt-6">
                        <h4 class="text-sm font-medium text-gray-500 mb-2">Notlar</h4>
                        <div class="bg-gray-50 p-4 rounded-lg">
                            <p class="text-sm text-gray-700"><?php echo nl2br(htmlspecialchars($payslip['notes'])); ?></p>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Legal Information -->
            <div class="bg-white shadow-md rounded-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 bg-gray-50">
                    <h3 class="text-lg font-semibold text-gray-800">Yasal Bilgiler</h3>
                </div>
                <div class="p-6">
                    <p class="text-sm text-gray-600 mb-4">
                        Bu bordro, <?php echo htmlspecialchars($payslip['period_name']); ?> dönemi için 
                        <?php echo htmlspecialchars($payslip['first_name'] . ' ' . $payslip['last_name']); ?> adına düzenlenmiştir.
                    </p>
                    <p class="text-sm text-gray-600 mb-4">
                        Bordro ile ilgili sorularınız için lütfen İnsan Kaynakları departmanı ile iletişime geçiniz.
                    </p>
                    <p class="text-sm text-gray-600">
                        Bordro oluşturulma tarihi: <?php echo date('d.m.Y H:i', strtotime($payslip['created_at'])); ?>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>