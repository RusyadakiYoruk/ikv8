<?php
// Employees List Page
session_start(); // Oturum başlatma eklendi

// Load configuration
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';

// Set timezone
date_default_timezone_set(DEFAULT_TIMEZONE);

// Connect to database
$database = new Database();
$db = $database->connect();

// Check if user is logged in and has admin or manager role
require_role(['admin', 'manager']);

// Get user information
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

// Get employee information if available
$employee = null;
$stmt = $db->prepare("SELECT * FROM employees WHERE user_id = :user_id LIMIT 1");
$stmt->execute(['user_id' => $user_id]);
$employee = $stmt->fetch(PDO::FETCH_ASSOC);

// Process employee actions (delete, activate, deactivate)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
        set_flash_message('employee_error', 'Geçersiz form gönderimi. Lütfen tekrar deneyin.', 'danger');
    } else {
        try {
            // Begin transaction
            $db->beginTransaction();
            
            // Delete employee
            if (isset($_POST['action']) && $_POST['action'] === 'delete') {
                $employee_id = (int)$_POST['employee_id'];
                
                // Get employee details for logging
                $stmt = $db->prepare("SELECT first_name, last_name FROM employees WHERE id = :employee_id");
                $stmt->execute(['employee_id' => $employee_id]);
                $emp_details = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$emp_details) {
                    throw new Exception('Çalışan bulunamadı.');
                }
                
                // Delete employee
                $stmt = $db->prepare("DELETE FROM employees WHERE id = :employee_id");
                $stmt->execute(['employee_id' => $employee_id]);
                
                // Log activity
                $stmt = $db->prepare("INSERT INTO activity_logs (user_id, activity_type, description, ip_address) VALUES (:user_id, 'employee_delete', :description, :ip_address)");
                $stmt->execute([
                    'user_id' => $user_id,
                    'description' => "Çalışan silindi: {$emp_details['first_name']} {$emp_details['last_name']} (ID: {$employee_id})",
                    'ip_address' => $_SERVER['REMOTE_ADDR']
                ]);
                
                set_flash_message('employee_success', "Çalışan başarıyla silindi: {$emp_details['first_name']} {$emp_details['last_name']}", 'success');
            }
            
            // Terminate employee
            elseif (isset($_POST['action']) && $_POST['action'] === 'terminate') {
                $employee_id = (int)$_POST['employee_id'];
                $termination_date = sanitize($_POST['termination_date']);
                
                // Validate termination date
                if (empty($termination_date)) {
                    throw new Exception('İşten çıkış tarihi zorunludur.');
                }
                
                // Get employee details for logging
                $stmt = $db->prepare("SELECT first_name, last_name FROM employees WHERE id = :employee_id");
                $stmt->execute(['employee_id' => $employee_id]);
                $emp_details = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$emp_details) {
                    throw new Exception('Çalışan bulunamadı.');
                }
                
                // Update employee termination date
                $stmt = $db->prepare("UPDATE employees SET termination_date = :termination_date WHERE id = :employee_id");
                $stmt->execute([
                    'termination_date' => $termination_date,
                    'employee_id' => $employee_id
                ]);
                
                // Log activity
                $stmt = $db->prepare("INSERT INTO activity_logs (user_id, activity_type, description, ip_address) VALUES (:user_id, 'employee_terminate', :description, :ip_address)");
                $stmt->execute([
                    'user_id' => $user_id,
                    'description' => "Çalışan işten çıkarıldı: {$emp_details['first_name']} {$emp_details['last_name']} (ID: {$employee_id}) - Tarih: {$termination_date}",
                    'ip_address' => $_SERVER['REMOTE_ADDR']
                ]);
                
                set_flash_message('employee_success', "Çalışan işten çıkarıldı: {$emp_details['first_name']} {$emp_details['last_name']} - Tarih: {$termination_date}", 'success');
            }
            
            // Commit transaction
            $db->commit();
        } catch (Exception $e) {
            // Rollback transaction on error
            $db->rollBack();
            set_flash_message('employee_error', $e->getMessage(), 'danger');
        }
    }
    
    // Redirect to prevent form resubmission
    redirect('employees.php');
    exit; // Yönlendirme sonrası çıkış eklendi
}

// Get employees with pagination and filtering
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 10;
$offset = ($page - 1) * $per_page;

// Filters
$department_filter = isset($_GET['department']) ? (int)$_GET['department'] : 0;
$status_filter = isset($_GET['status']) ? sanitize($_GET['status']) : 'all';
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';

// Build query conditions
$conditions = [];
$params = [];

if ($department_filter > 0) {
    $conditions[] = "e.department_id = :department";
    $params['department'] = $department_filter;
}

if ($status_filter === 'active') {
    $conditions[] = "(e.termination_date IS NULL OR e.termination_date > CURDATE())";
} elseif ($status_filter === 'terminated') {
    $conditions[] = "e.termination_date IS NOT NULL AND e.termination_date <= CURDATE()";
}

if (!empty($search)) {
    $conditions[] = "(e.first_name LIKE :search OR e.last_name LIKE :search OR e.phone LIKE :search)";
    $params['search'] = "%{$search}%";
}

$where_clause = !empty($conditions) ? "WHERE " . implode(" AND ", $conditions) : "";

// Get total employees count
$count_sql = "SELECT COUNT(*) FROM employees e {$where_clause}";
$stmt = $db->prepare($count_sql);
if (!empty($params)) {
    $stmt->execute($params);
} else {
    $stmt->execute();
}
$total_employees = $stmt->fetchColumn();
$total_pages = ceil($total_employees / $per_page);

// Get employees for current page - Fix the branch_id issue
$sql = "SELECT e.*, d.name as department_name, jt.title as job_title 
        FROM employees e 
        LEFT JOIN departments d ON e.department_id = d.id 
        LEFT JOIN job_titles jt ON e.job_title_id = jt.id 
        {$where_clause} 
        ORDER BY e.id DESC 
        LIMIT :offset, :per_page";
$stmt = $db->prepare($sql);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->bindValue(':per_page', $per_page, PDO::PARAM_INT);
foreach ($params as $key => $value) {
    $stmt->bindValue(':' . $key, $value);
}
$stmt->execute();
$employees_list = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get departments for filter
$stmt = $db->query("SELECT * FROM departments ORDER BY name");
$departments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Include header
include 'includes/header.php';
?>

<div class="flex h-screen bg-gray-100">
    <!-- Sidebar -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- Main Content -->
    <div class="flex-1 overflow-auto ml-0 lg:ml-64 pt-16">
        <div class="py-6 px-8">
            <!-- Page Header -->
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold text-gray-800">Çalışanlar</h1>
                <div class="flex space-x-2">
                    <a href="add_employee.php" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                        <svg class="mr-2 -ml-1 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                        </svg>
                        Yeni Çalışan Ekle
                    </a>
                    <a href="export_employees.php?<?php echo http_build_query($_GET); ?>" class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
    <svg class="mr-2 -ml-1 h-5 w-5 text-gray-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
    </svg>
    Excel'e Aktar
</a>
                </div>
            </div>
            
            <!-- Flash Messages -->
            <?php if (isset($_SESSION['flash_messages']['employee_success'])): ?>
                <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6" role="alert">
                    <p><?php echo $_SESSION['flash_messages']['employee_success']['message']; ?></p>
                </div>
                <?php unset($_SESSION['flash_messages']['employee_success']); ?>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['flash_messages']['employee_error'])): ?>
                <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                    <p><?php echo $_SESSION['flash_messages']['employee_error']['message']; ?></p>
                </div>
                <?php unset($_SESSION['flash_messages']['employee_error']); ?>
            <?php endif; ?>
            
            <!-- Filters -->
            <div class="bg-white rounded-lg shadow mb-6">
                <div class="px-4 py-3 border-b">
                    <h3 class="text-lg font-semibold text-gray-700">Filtreler</h3>
                </div>
                <div class="p-4">
                    <form method="GET" action="employees.php" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <!-- Department Filter -->
                        <div>
                            <label for="department" class="block text-sm font-medium text-gray-700">Departman</label>
                            <select name="department" id="department" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                <option value="0">Tümü</option>
                                <?php foreach ($departments as $dept): ?>
                                    <option value="<?php echo $dept['id']; ?>" <?php echo $department_filter === (int)$dept['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($dept['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <!-- Status Filter -->
                        <div>
                            <label for="status" class="block text-sm font-medium text-gray-700">Durum</label>
                            <select name="status" id="status" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                <option value="all" <?php echo $status_filter === 'all' ? 'selected' : ''; ?>>Tümü</option>
                                <option value="active" <?php echo $status_filter === 'active' ? 'selected' : ''; ?>>Aktif</option>
                                <option value="terminated" <?php echo $status_filter === 'terminated' ? 'selected' : ''; ?>>İşten Çıkmış</option>
                            </select>
                        </div>
                        
                        <!-- Search -->
                        <div>
                            <label for="search" class="block text-sm font-medium text-gray-700">Ara</label>
                            <input type="text" name="search" id="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Ad, soyad veya telefon" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                        </div>
                        
                        <!-- Submit Button -->
                        <div class="flex items-end">
                            <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                            <svg class="mr-2 -ml-1 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
                                </svg>
                                Filtrele
                            </button>
                            <a href="employees.php" class="ml-2 inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                Sıfırla
                            </a>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Employees Table -->
            <div class="bg-white rounded-lg shadow overflow-hidden">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Çalışan</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Departman</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Unvan</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">İletişim</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Durum</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">İşlemler</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php if (empty($employees_list)): ?>
                            <tr>
                                <td colspan="6" class="px-6 py-4 text-center text-sm text-gray-500">
                                    Çalışan bulunamadı.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($employees_list as $emp): ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="flex items-center">
                                            <div class="flex-shrink-0 h-10 w-10">
                                                <div class="h-10 w-10 rounded-full bg-blue-500 flex items-center justify-center text-white font-bold">
                                                    <?php echo substr($emp['first_name'], 0, 1) . substr($emp['last_name'], 0, 1); ?>
                                                </div>
                                            </div>
                                            <div class="ml-4">
                                                <div class="text-sm font-medium text-gray-900">
                                                    <a href="view_employee.php?id=<?php echo $emp['id']; ?>" class="hover:underline">
                                                        <?php echo htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name']); ?>
                                                    </a>
                                                </div>
                                                <div class="text-sm text-gray-500">
                                                    <?php echo 'İşe Başlama: ' . date('d.m.Y', strtotime($emp['hire_date'])); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-900"><?php echo htmlspecialchars($emp['department_name'] ?? 'Belirtilmemiş'); ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-900"><?php echo htmlspecialchars($emp['job_title'] ?? 'Belirtilmemiş'); ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php if (!empty($emp['phone'])): ?>
                                            <div class="text-sm text-gray-900"><?php echo htmlspecialchars($emp['phone']); ?></div>
                                        <?php endif; ?>
                                        <?php if (!empty($emp['email'])): ?>
                                            <div class="text-sm text-gray-500"><?php echo htmlspecialchars($emp['email']); ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php if (empty($emp['termination_date']) || strtotime($emp['termination_date']) > time()): ?>
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                                Aktif
                                            </span>
                                        <?php else: ?>
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                                                İşten Çıkmış
                                            </span>
                                            <div class="text-xs text-gray-500 mt-1">
                                                <?php echo date('d.m.Y', strtotime($emp['termination_date'])); ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <a href="view_employee.php?id=<?php echo $emp['id']; ?>" class="text-blue-600 hover:text-blue-900 mr-3">Görüntüle</a>
                                        <a href="edit_employee.php?id=<?php echo $emp['id']; ?>" class="text-indigo-600 hover:text-indigo-900 mr-3">Düzenle</a>
                                        
                                        <?php if (empty($emp['termination_date']) || strtotime($emp['termination_date']) > time()): ?>
                                            <button type="button" onclick="showTerminateModal(<?php echo $emp['id']; ?>, '<?php echo htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name']); ?>')" class="text-yellow-600 hover:text-yellow-900 mr-3">İşten Çıkar</button>
                                        <?php endif; ?>
                                        
                                        <button type="button" onclick="confirmDelete(<?php echo $emp['id']; ?>, '<?php echo htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name']); ?>')" class="text-red-600 hover:text-red-900">Sil</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
                <div class="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200 sm:px-6 mt-4 rounded-lg shadow">
                    <div class="flex-1 flex justify-between sm:hidden">
                        <?php if ($page > 1): ?>
                            <a href="?page=<?php echo $page - 1; ?>&department=<?php echo $department_filter; ?>&status=<?php echo $status_filter; ?>&search=<?php echo urlencode($search); ?>" class="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                                Önceki
                            </a>
                        <?php endif; ?>
                        
                        <?php if ($page < $total_pages): ?>
                            <a href="?page=<?php echo $page + 1; ?>&department=<?php echo $department_filter; ?>&status=<?php echo $status_filter; ?>&search=<?php echo urlencode($search); ?>" class="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                                Sonraki
                            </a>
                        <?php endif; ?>
                    </div>
                    <div class="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
                        <div>
                            <p class="text-sm text-gray-700">
                                <span class="font-medium"><?php echo $total_employees; ?></span> çalışandan 
                                <span class="font-medium"><?php echo ($page - 1) * $per_page + 1; ?></span> - 
                                <span class="font-medium"><?php echo min($page * $per_page, $total_employees); ?></span> arası gösteriliyor
                            </p>
                        </div>
                        <div>
                            <nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                                <?php if ($page > 1): ?>
                                    <a href="?page=<?php echo $page - 1; ?>&department=<?php echo $department_filter; ?>&status=<?php echo $status_filter; ?>&search=<?php echo urlencode($search); ?>" class="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                                        <span class="sr-only">Önceki</span>
                                        <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                            <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />
                                        </svg>
                                    </a>
                                <?php endif; ?>
                                
                                <?php
                                $start_page = max(1, $page - 2);
                                $end_page = min($total_pages, $page + 2);
                                
                                if ($start_page > 1) {
                                    echo '<span class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700">...</span>';
                                }
                                
                                for ($i = $start_page; $i <= $end_page; $i++) {
                                    $active_class = $i === $page ? 'z-10 bg-blue-50 border-blue-500 text-blue-600' : 'bg-white border-gray-300 text-gray-500 hover:bg-gray-50';
                                    echo '<a href="?page=' . $i . '&department=' . $department_filter . '&status=' . $status_filter . '&search=' . urlencode($search) . '" class="relative inline-flex items-center px-4 py-2 border ' . $active_class . ' text-sm font-medium">' . $i . '</a>';
                                }
                                
                                if ($end_page < $total_pages) {
                                    echo '<span class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700">...</span>';
                                }
                                ?>
                                
                                <?php if ($page < $total_pages): ?>
                                    <a href="?page=<?php echo $page + 1; ?>&department=<?php echo $department_filter; ?>&status=<?php echo $status_filter; ?>&search=<?php echo urlencode($search); ?>" class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                                        <span class="sr-only">Sonraki</span>
                                        <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                            <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" />
                                        </svg>
                                    </a>
                                <?php endif; ?>
                            </nav>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div id="deleteModal" class="fixed z-10 inset-0 overflow-y-auto hidden">
    <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div class="fixed inset-0 transition-opacity" aria-hidden="true">
            <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
        </div>
        <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
        <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
            <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <div class="sm:flex sm:items-start">
                <div class="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-red-100 sm:mx-0 sm:h-10 sm:w-10">
                        <svg class="h-6 w-6 text-red-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                        </svg>
                    </div>
                    <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                        <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                            Çalışanı Sil
                        </h3>
                        <div class="mt-2">
                            <p class="text-sm text-gray-500" id="delete-message">
                                Bu çalışanı silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <form id="deleteForm" method="POST" action="employees.php">
                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="employee_id" id="delete_employee_id">
                    <button type="submit" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-red-600 text-base font-medium text-white hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 sm:ml-3 sm:w-auto sm:text-sm">
                        Sil
                    </button>
                </form>
                <button type="button" onclick="closeDeleteModal()" class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">
                    İptal
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Terminate Employee Modal -->
<div id="terminateModal" class="fixed z-10 inset-0 overflow-y-auto hidden">
    <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div class="fixed inset-0 transition-opacity" aria-hidden="true">
            <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
        </div>
        <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
        <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
            <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <div class="sm:flex sm:items-start">
                    <div class="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-yellow-100 sm:mx-0 sm:h-10 sm:w-10">
                        <svg class="h-6 w-6 text-yellow-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                        </svg>
                    </div>
                    <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                        <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                            Çalışanı İşten Çıkar
                        </h3>
                        <div class="mt-2">
                            <p class="text-sm text-gray-500" id="terminate-message">
                                Bu çalışanı işten çıkarmak istediğinizden emin misiniz?
                            </p>
                            <div class="mt-4">
                                <label for="termination_date" class="block text-sm font-medium text-gray-700">İşten Çıkış Tarihi</label>
                                <input type="date" name="termination_date" id="termination_date" required class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md" value="<?php echo date('Y-m-d'); ?>">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <form id="terminateForm" method="POST" action="employees.php">
                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                    <input type="hidden" name="action" value="terminate">
                    <input type="hidden" name="employee_id" id="terminate_employee_id">
                    <button type="submit" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-yellow-600 text-base font-medium text-white hover:bg-yellow-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-yellow-500 sm:ml-3 sm:w-auto sm:text-sm">
                        İşten Çıkar
                    </button>
                </form>
                <button type="button" onclick="closeTerminateModal()" class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">
                    İptal
                </button>
            </div>
        </div>
    </div>
</div>

<script>
    // Delete Modal Functions
    function confirmDelete(employeeId, employeeName) {
        document.getElementById('delete_employee_id').value = employeeId;
        document.getElementById('delete-message').textContent = employeeName + ' adlı çalışanı silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.';
        document.getElementById('deleteModal').classList.remove('hidden');
    }
    
    function closeDeleteModal() {
        document.getElementById('deleteModal').classList.add('hidden');
    }
    
    // Terminate Modal Functions
    function showTerminateModal(employeeId, employeeName) {
        document.getElementById('terminate_employee_id').value = employeeId;
        document.getElementById('terminate-message').textContent = employeeName + ' adlı çalışanı işten çıkarmak istediğinizden emin misiniz?';
        document.getElementById('terminateModal').classList.remove('hidden');
    }
    
    function closeTerminateModal() {
        document.getElementById('terminateModal').classList.add('hidden');
    }
    
    // Form Validation
    document.getElementById('terminateForm').addEventListener('submit', function(e) {
        const terminationDate = document.getElementById('termination_date').value;
        if (!terminationDate) {
            e.preventDefault();
            alert('Lütfen işten çıkış tarihini belirtin.');
        }
    });
</script>

<?php include 'includes/footer.php'; ?>