<?php
// User Management Page
session_start();

// Load configuration
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';

// Set timezone
date_default_timezone_set(DEFAULT_TIMEZONE);

// Connect to database
$database = new Database();
$db = $database->connect();

// Check if user is logged in and has admin role
require_role('admin');

// Get user information
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

// Get employee information if available
$employee = null;
$stmt = $db->prepare("SELECT * FROM employees WHERE user_id = :user_id LIMIT 1");
$stmt->execute(['user_id' => $user_id]);
$employee = $stmt->fetch(PDO::FETCH_ASSOC);

// Process user actions (add, edit, delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
        set_flash_message('user_error', 'Geçersiz form gönderimi. Lütfen tekrar deneyin.', 'danger');
    } else {
        try {
            // Begin transaction
            $db->beginTransaction();
            
            // Add new user
            if (isset($_POST['action']) && $_POST['action'] === 'add') {
                $email = sanitize($_POST['email']);
                $password = $_POST['password'];
                $role = sanitize($_POST['role']);
                $is_active = isset($_POST['is_active']) ? 1 : 0;
                
                // Validate email
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    throw new Exception('Geçerli bir e-posta adresi giriniz.');
                }
                
                // Check if email already exists
                $stmt = $db->prepare("SELECT COUNT(*) FROM users WHERE email = :email");
                $stmt->execute(['email' => $email]);
                if ($stmt->fetchColumn() > 0) {
                    throw new Exception('Bu e-posta adresi zaten kullanılıyor.');
                }
                
                // Validate password
                if (strlen($password) < 8) {
                    throw new Exception('Şifre en az 8 karakter olmalıdır.');
                }
                
                // Hash password
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                
                // Insert user
                $stmt = $db->prepare("INSERT INTO users (email, password, role, is_active, created_at) VALUES (:email, :password, :role, :is_active, NOW())");
                $stmt->execute([
                    'email' => $email,
                    'password' => $hashed_password,
                    'role' => $role,
                    'is_active' => $is_active
                ]);
                
                $new_user_id = $db->lastInsertId();
                
                // Log activity
                $stmt = $db->prepare("INSERT INTO activity_logs (user_id, activity_type, description, ip_address) VALUES (:user_id, 'user_add', :description, :ip_address)");
                $stmt->execute([
                    'user_id' => $user_id,
                    'description' => 'Yeni kullanıcı eklendi: ' . $email,
                    'ip_address' => $_SERVER['REMOTE_ADDR']
                ]);
                
                set_flash_message('user_success', 'Kullanıcı başarıyla eklendi.', 'success');
            }
            
            // Edit user
            elseif (isset($_POST['action']) && $_POST['action'] === 'edit') {
                $edit_user_id = (int)$_POST['user_id'];
                $email = sanitize($_POST['email']);
                $role = sanitize($_POST['role']);
                $is_active = isset($_POST['is_active']) ? 1 : 0;
                
                // Validate email
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    throw new Exception('Geçerli bir e-posta adresi giriniz.');
                }
                
                // Check if email already exists for other users
                $stmt = $db->prepare("SELECT COUNT(*) FROM users WHERE email = :email AND id != :user_id");
                $stmt->execute([
                    'email' => $email,
                    'user_id' => $edit_user_id
                ]);
                if ($stmt->fetchColumn() > 0) {
                    throw new Exception('Bu e-posta adresi zaten başka bir kullanıcı tarafından kullanılıyor.');
                }
                
                // Update user
                $stmt = $db->prepare("UPDATE users SET email = :email, role = :role, is_active = :is_active, updated_at = NOW() WHERE id = :user_id");
                $stmt->execute([
                    'email' => $email,
                    'role' => $role,
                    'is_active' => $is_active,
                    'user_id' => $edit_user_id
                ]);
                
                // Update password if provided
                if (!empty($_POST['password'])) {
                    $password = $_POST['password'];
                    
                    // Validate password
                    if (strlen($password) < 8) {
                        throw new Exception('Şifre en az 8 karakter olmalıdır.');
                    }
                    
                    // Hash password
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    
                    // Update password
                    $stmt = $db->prepare("UPDATE users SET password = :password WHERE id = :user_id");
                    $stmt->execute([
                        'password' => $hashed_password,
                        'user_id' => $edit_user_id
                    ]);
                }
                
                // Log activity
                $stmt = $db->prepare("INSERT INTO activity_logs (user_id, activity_type, description, ip_address) VALUES (:user_id, 'user_edit', :description, :ip_address)");
                $stmt->execute([
                    'user_id' => $user_id,
                    'description' => 'Kullanıcı düzenlendi: ' . $email,
                    'ip_address' => $_SERVER['REMOTE_ADDR']
                ]);
                
                set_flash_message('user_success', 'Kullanıcı başarıyla güncellendi.', 'success');
            }
            
            // Delete user
            elseif (isset($_POST['action']) && $_POST['action'] === 'delete') {
                $delete_user_id = (int)$_POST['user_id'];
                
                // Check if user exists
                $stmt = $db->prepare("SELECT email FROM users WHERE id = :user_id");
                $stmt->execute(['user_id' => $delete_user_id]);
                $user_email = $stmt->fetchColumn();
                
                if (!$user_email) {
                    throw new Exception('Kullanıcı bulunamadı.');
                }
                
                // Prevent deleting own account
                if ($delete_user_id === $user_id) {
                    throw new Exception('Kendi hesabınızı silemezsiniz.');
                }
                
                // Delete user
                $stmt = $db->prepare("DELETE FROM users WHERE id = :user_id");
                $stmt->execute(['user_id' => $delete_user_id]);
                
                // Log activity
                $stmt = $db->prepare("INSERT INTO activity_logs (user_id, activity_type, description, ip_address) VALUES (:user_id, 'user_delete', :description, :ip_address)");
                $stmt->execute([
                    'user_id' => $user_id,
                    'description' => 'Kullanıcı silindi: ' . $user_email,
                    'ip_address' => $_SERVER['REMOTE_ADDR']
                ]);
                
                set_flash_message('user_success', 'Kullanıcı başarıyla silindi.', 'success');
            }
            
            // Commit transaction
            $db->commit();
        } catch (Exception $e) {
            // Rollback transaction on error
            $db->rollBack();
            set_flash_message('user_error', $e->getMessage(), 'danger');
        }
    }
    
    // Redirect to prevent form resubmission
    redirect('user_management.php');
}

// Get users with pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 10;
$offset = ($page - 1) * $per_page;

// Search functionality
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$search_condition = '';
$search_params = [];

if (!empty($search)) {
    $search_condition = "WHERE email LIKE :search";
    $search_params['search'] = "%{$search}%";
}

// Get total users count
$count_sql = "SELECT COUNT(*) FROM users {$search_condition}";
$stmt = $db->prepare($count_sql);
if (!empty($search_params)) {
    $stmt->execute($search_params);
} else {
    $stmt->execute();
}
$total_users = $stmt->fetchColumn();
$total_pages = ceil($total_users / $per_page);

// Get users for current page
$sql = "SELECT * FROM users {$search_condition} ORDER BY created_at DESC LIMIT :offset, :per_page";
$stmt = $db->prepare($sql);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->bindValue(':per_page', $per_page, PDO::PARAM_INT);
if (!empty($search_params)) {
    $stmt->bindValue(':search', $search_params['search'], PDO::PARAM_STR);
}
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Include header
include 'includes/header.php';
?>

<div class="flex h-screen bg-gray-100">
    <!-- Sidebar -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- Main Content -->
    <div class="flex-1 overflow-auto ml-0 lg:ml-64 pt-16">
        <div class="py-6 px-8">
            <!-- Page Header -->
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold text-gray-800">Kullanıcı Yönetimi</h1>
                <nav class="flex" aria-label="Breadcrumb">
                    <ol class="inline-flex items-center space-x-1 md:space-x-3">
                        <li class="inline-flex items-center">
                            <a href="index.php" class="text-gray-700 hover:text-gray-900 inline-flex items-center">
                                <svg class="w-5 h-5 mr-2.5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"></path>
                                </svg>
                                Dashboard
                            </a>
                        </li>
                        <li>
                            <div class="flex items-center">
                                <svg class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <a href="user_management.php" class="ml-1 text-gray-700 hover:text-gray-900 md:ml-2">Kullanıcı Yönetimi</a>
                            </div>
                        </li>
                    </ol>
                </nav>
            </div>
            
            <!-- Flash Messages -->
            <?php if (isset($_SESSION['flash_messages']['user_success'])): ?>
                <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6" role="alert">
                    <p><?php echo $_SESSION['flash_messages']['user_success']['message']; ?></p>
                </div>
                <?php unset($_SESSION['flash_messages']['user_success']); ?>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['flash_messages']['user_error'])): ?>
                <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                    <p><?php echo $_SESSION['flash_messages']['user_error']['message']; ?></p>
                </div>
                <?php unset($_SESSION['flash_messages']['user_error']); ?>
            <?php endif; ?>
            
            <!-- User Management Section -->
            <div class="grid grid-cols-1 gap-6">
                <!-- Add User Card -->
                <div class="bg-white rounded-lg shadow">
                    <div class="border-b px-4 py-3 flex justify-between items-center">
                        <h3 class="text-lg font-semibold text-gray-700">Yeni Kullanıcı Ekle</h3>
                        <button type="button" id="toggleAddUserForm" class="text-blue-600 hover:text-blue-800">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                            </svg>
                        </button>
                    </div>
                    <div id="addUserForm" class="p-6 hidden">
                        <form method="POST" action="user_management.php">
                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                            <input type="hidden" name="action" value="add">
                            
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <!-- Email -->
                                <div class="col-span-1">
                                    <label for="email" class="block text-sm font-medium text-gray-700">E-posta Adresi</label>
                                    <input type="email" name="email" id="email" required class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                
                                <!-- Password -->
                                <div class="col-span-1">
                                    <label for="password" class="block text-sm font-medium text-gray-700">Şifre</label>
                                    <input type="password" name="password" id="password" required class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                
                                <!-- Role -->
                                <div class="col-span-1">
                                    <label for="role" class="block text-sm font-medium text-gray-700">Rol</label>
                                    <select name="role" id="role" required class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                        <option value="admin">Admin</option>
                                        <option value="manager">Yönetici</option>
                                        <option value="employee" selected>Çalışan</option>
                                    </select>
                                </div>
                                
                                <!-- Active Status -->
                                <div class="col-span-1">
                                    <div class="flex items-center h-full mt-6">
                                        <input type="checkbox" name="is_active" id="is_active" checked class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                                        <label for="is_active" class="ml-2 block text-sm text-gray-700">Aktif Kullanıcı</label>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mt-6 flex justify-end">
                                <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                    <svg class="mr-2 -ml-1 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                                    </svg>
                                    Kullanıcı Ekle
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Users List Card -->
                <div class="bg-white rounded-lg shadow">
                    <div class="border-b px-4 py-3">
                        <h3 class="text-lg font-semibold text-gray-700">Kullanıcılar</h3>
                    </div>
                    <div class="p-6">
                        <!-- Search and Filter -->
                        <div class="mb-6">
                            <form method="GET" action="user_management.php" class="flex items-center">
                                <div class="relative w-full">
                                    <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                                        <svg class="w-5 h-5 text-gray-500" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clip-rule="evenodd"></path>
                                        </svg>
                                    </div>
                                    <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 p-2.5" placeholder="E-posta ile ara...">
                                </div>
                                <button type="submit" class="p-2.5 ml-2 text-sm font-medium text-white bg-blue-600 rounded-lg border border-blue-600 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                                    </svg>
                                    <span class="sr-only">Ara</span>
                                </button>
                                <?php if (!empty($search)): ?>
                                    <a href="user_management.php" class="p-2.5 ml-2 text-sm font-medium text-gray-700 bg-gray-200 rounded-lg border border-gray-300 hover:bg-gray-300 focus:ring-4 focus:outline-none focus:ring-gray-100">
                                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                                        </svg>
                                        <span class="sr-only">Temizle</span>
                                    </a>
                                <?php endif; ?>
                            </form>
                        </div>
                        
                        <!-- Users Table -->
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">E-posta</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rol</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Durum</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Oluşturulma Tarihi</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">İşlemler</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    <?php if (empty($users)): ?>
                                        <tr>
                                            <td colspan="6" class="px-6 py-4 text-center text-sm text-gray-500">Kullanıcı bulunamadı.</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($users as $user_item): ?>
                                            <tr>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo $user_item['id']; ?></td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo htmlspecialchars($user_item['email']); ?></td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                    <?php
                                                    switch ($user_item['role']) {
                                                        case 'admin':
                                                            echo '<span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-purple-100 text-purple-800">Admin</span>';
                                                            break;
                                                        case 'manager':
                                                            echo '<span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">Yönetici</span>';
                                                            break;
                                                        case 'employee':
                                                            echo '<span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">Çalışan</span>';
                                                            break;
                                                        default:
                                                            echo $user_item['role'];
                                                    }
                                                    ?>
                                                </td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                    <?php if ($user_item['is_active']): ?>
                                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">Aktif</span>
                                                    <?php else: ?>
                                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">Pasif</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo date('d.m.Y H:i', strtotime($user_item['created_at'])); ?></td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                    <div class="flex space-x-2">
                                                        <button type="button" class="text-blue-600 hover:text-blue-900 edit-user" data-id="<?php echo $user_item['id']; ?>" data-email="<?php echo htmlspecialchars($user_item['email']); ?>" data-role="<?php echo $user_item['role']; ?>" data-active="<?php echo $user_item['is_active']; ?>">
                                                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path>
                                                            </svg>
                                                        </button>
                                                        <?php if ($user_item['id'] !== $user_id): ?>
                                                            <button type="button" class="text-red-600 hover:text-red-900 delete-user" data-id="<?php echo $user_item['id']; ?>" data-email="<?php echo htmlspecialchars($user_item['email']); ?>">
                                                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                                                </svg>
                                                            </button>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <!-- Pagination -->
                        <?php if ($total_pages > 1): ?>
                            <div class="mt-6 flex justify-center">
                                <nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                                    <?php if ($page > 1): ?>
                                        <a href="user_management.php?page=<?php echo $page - 1; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>" class="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                                            <span class="sr-only">Önceki</span>
                                            <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                                <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />
                                            </svg>
                                        </a>
                                    <?php endif; ?>
                                    
                                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                        <a href="user_management.php?page=<?php echo $i; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>" class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium <?php echo $i === $page ? 'text-blue-600 bg-blue-50' : 'text-gray-700 hover:bg-gray-50'; ?>">
                                            <?php echo $i; ?>
                                        </a>
                                    <?php endfor; ?>
                                    
                                    <?php if ($page < $total_pages): ?>
                                        <a href="user_management.php?page=<?php echo $page + 1; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>" class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                                            <span class="sr-only">Sonraki</span>
                                            <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                                <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" />
                                            </svg>
                                        </a>
                                    <?php endif; ?>
                                </nav>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Edit User Modal -->
<div id="editUserModal" class="fixed inset-0 z-50 overflow-y-auto hidden" aria-labelledby="modal-title" role="dialog" aria-modal="true">
    <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" aria-hidden="true"></div>
        <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
        <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
            <form method="POST" action="user_management.php">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="user_id" id="edit_user_id">
                
                <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                    <div class="sm:flex sm:items-start">
                        <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                            <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                                Kullanıcı Düzenle
                            </h3>
                            <div class="mt-4 space-y-4">
                                <!-- Email -->
                                <div>
                                    <label for="edit_email" class="block text-sm font-medium text-gray-700">E-posta Adresi</label>
                                    <input type="email" name="email" id="edit_email" required class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                
                                <!-- Password -->
                                <div>
                                    <label for="edit_password" class="block text-sm font-medium text-gray-700">Şifre (Değiştirmek istemiyorsanız boş bırakın)</label>
                                    <input type="password" name="password" id="edit_password" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                
                                <!-- Role -->
                                <div>
                                    <label for="edit_role" class="block text-sm font-medium text-gray-700">Rol</label>
                                    <select name="role" id="edit_role" required class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                        <option value="admin">Admin</option>
                                        <option value="manager">Yönetici</option>
                                        <option value="employee">Çalışan</option>
                                    </select>
                                </div>
                                
                                <!-- Active Status -->
                                <div class="flex items-center">
                                    <input type="checkbox" name="is_active" id="edit_is_active" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                                    <label for="edit_is_active" class="ml-2 block text-sm text-gray-700">Aktif Kullanıcı</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                    <button type="submit" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm">
                        Kaydet
                    </button>
                    <button type="button" class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm close-modal">
                        İptal
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete User Modal -->
<div id="deleteUserModal" class="fixed inset-0 z-50 overflow-y-auto hidden" aria-labelledby="modal-title" role="dialog" aria-modal="true">
    <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" aria-hidden="true"></div>
        <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
        <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
            <form method="POST" action="user_management.php">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="user_id" id="delete_user_id">
                
                <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                    <div class="sm:flex sm:items-start">
                        <div class="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-red-100 sm:mx-0 sm:h-10 sm:w-10">
                            <svg class="h-6 w-6 text-red-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                            </svg>
                        </div>
                        <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                            <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                                Kullanıcıyı Sil
                            </h3>
                            <div class="mt-2">
                                <p class="text-sm text-gray-500">
                                    <span id="delete_user_email"></span> kullanıcısını silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                    <button type="submit" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-red-600 text-base font-medium text-white hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 sm:ml-3 sm:w-auto sm:text-sm">
                        Sil
                    </button>
                    <button type="button" class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm close-modal">
                        İptal
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- JavaScript for modals and form toggle -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Toggle Add User Form
        const toggleAddUserFormButton = document.getElementById('toggleAddUserForm');
        const addUserForm = document.getElementById('addUserForm');
        
        toggleAddUserFormButton.addEventListener('click', function() {
            addUserForm.classList.toggle('hidden');
            
            // Toggle icon
            const icon = this.querySelector('svg');
            if (addUserForm.classList.contains('hidden')) {
                icon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>';
            } else {
                icon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 15l7-7 7 7"></path>';
            }
        });
        
        // Edit User Modal
        const editUserButtons = document.querySelectorAll('.edit-user');
        const editUserModal = document.getElementById('editUserModal');
        
        editUserButtons.forEach(button => {
            button.addEventListener('click', function() {
                const userId = this.getAttribute('data-id');
                const userEmail = this.getAttribute('data-email');
                const userRole = this.getAttribute('data-role');
                const userActive = this.getAttribute('data-active') === '1';
                
                document.getElementById('edit_user_id').value = userId;
                document.getElementById('edit_email').value = userEmail;
                document.getElementById('edit_password').value = '';
                
                const roleSelect = document.getElementById('edit_role');
                for (let i = 0; i < roleSelect.options.length; i++) {
                    if (roleSelect.options[i].value === userRole) {
                        roleSelect.options[i].selected = true;
                        break;
                    }
                }
                
                document.getElementById('edit_is_active').checked = userActive;
                
                editUserModal.classList.remove('hidden');
            });
        });
        
        // Delete User Modal
        const deleteUserButtons = document.querySelectorAll('.delete-user');
        const deleteUserModal = document.getElementById('deleteUserModal');
        
        deleteUserButtons.forEach(button => {
            button.addEventListener('click', function() {
                const userId = this.getAttribute('data-id');
                const userEmail = this.getAttribute('data-email');
                
                document.getElementById('delete_user_id').value = userId;
                document.getElementById('delete_user_email').textContent = userEmail;
                
                deleteUserModal.classList.remove('hidden');
            });
        });
        
        // Close Modals
        const closeModalButtons = document.querySelectorAll('.close-modal');
        
        closeModalButtons.forEach(button => {
            button.addEventListener('click', function() {
                editUserModal.classList.add('hidden');
                deleteUserModal.classList.add('hidden');
            });
        });
        
        // Close modals when clicking outside
        window.addEventListener('click', function(event) {
            if (event.target === editUserModal || event.target === deleteUserModal) {
                editUserModal.classList.add('hidden');
                deleteUserModal.classList.add('hidden');
            }
        });
    });
</script>

<?php
// Include footer
include 'includes/footer.php';
?>