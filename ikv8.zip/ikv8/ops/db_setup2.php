<?php
// setup_settings.php - Script to initialize settings in the database
require_once '../config/config.php';
require_once '../config/database.php';

// Connect to database
$database = new Database();
$db = $database->connect();

try {
    // Begin transaction
    $db->beginTransaction();
    
    // Define default settings
    $default_settings = [
        // General Settings
        ['default_language', 'tr', 'general', 'Varsayılan Dil'],
        ['default_timezone', 'Europe/Moscow', 'general', 'Varsayılan Zaman Dilimi'],
        ['date_format', 'd.m.Y', 'general', 'Tarih Formatı'],
        ['time_format', 'H:i', 'general', 'Saat Formatı'],
        ['currency', 'RUB', 'general', 'Para Birimi'],
        ['currency_symbol', '₽', 'general', 'Para Birimi Sembolü'],
        ['decimal_separator', ',', 'general', 'Ondalık Ayırıcı'],
        ['thousand_separator', '.', 'general', 'Binlik Ayırıcı'],
        ['week_start', 'Monday', 'general', 'Hafta Başlangıç Günü'],
        ['enable_registration', '0', 'general', 'Kullanıcı Kaydını Etkinleştir'],
        ['enable_password_reset', '1', 'general', 'Şifre Sıfırlamayı Etkinleştir'],
        ['session_timeout', '720', 'general', 'Oturum Zaman Aşımı (dakika)'],
        
        // Attendance Settings
        ['work_start_time', '09:00', 'attendance', 'Mesai Başlangıç Saati'],
        ['work_end_time', '18:00', 'attendance', 'Mesai Bitiş Saati'],
        ['lunch_start_time', '13:00', 'attendance', 'Öğle Molası Başlangıç Saati'],
        ['lunch_end_time', '14:00', 'attendance', 'Öğle Molası Bitiş Saati'],
        ['work_days', 'Monday,Tuesday,Wednesday,Thursday,Friday', 'attendance', 'Çalışma Günleri'],
        ['late_threshold', '15', 'attendance', 'Geç Kalma Eşiği (dakika)'],
        ['enable_overtime', '1', 'attendance', 'Fazla Mesaiyi Etkinleştir'],
        ['overtime_multiplier', '1.5', 'attendance', 'Fazla Mesai Çarpanı'],
        
        // Leave Settings
        ['default_annual_leave', '14', 'leave', 'Varsayılan Yıllık İzin (gün)'],
        ['default_sick_leave', '7', 'leave', 'Varsayılan Hastalık İzni (gün)'],
        ['default_casual_leave', '7', 'leave', 'Varsayılan Mazeret İzni (gün)'],
        ['leave_approval_required', '1', 'leave', 'İzin Onayı Gerekli'],
        ['leave_prior_notice', '3', 'leave', 'İzin Öncesi Bildirim (gün)'],
        ['enable_leave_carryover', '1', 'leave', 'İzin Devrini Etkinleştir'],
        ['max_leave_carryover', '5', 'leave', 'Maksimum İzin Devri (gün)'],
        
        // Expense Settings
        ['expense_approval_required', '1', 'expense', 'Harcama Onayı Gerekli'],
        ['expense_approval_threshold', '1000', 'expense', 'Harcama Onay Eşiği'],
        ['enable_expense_attachment', '1', 'expense', 'Harcama Eki Etkinleştir'],
        ['expense_attachment_types', 'jpg,jpeg,png,pdf', 'expense', 'İzin Verilen Harcama Eki Türleri'],
        ['expense_attachment_max_size', '5', 'expense', 'Maksimum Harcama Eki Boyutu (MB)'],
        
        // Performance Settings
        ['performance_review_frequency', 'quarterly', 'performance', 'Performans Değerlendirme Sıklığı'],
        ['performance_rating_scale', '5', 'performance', 'Performans Değerlendirme Ölçeği'],
        ['enable_self_assessment', '1', 'performance', 'Öz Değerlendirmeyi Etkinleştir'],
        ['enable_peer_review', '1', 'performance', 'Akran Değerlendirmesini Etkinleştir'],
        ['enable_manager_review', '1', 'performance', 'Yönetici Değerlendirmesini Etkinleştir'],
        
        // Notification Settings
        ['enable_email_notifications', '1', 'notification', 'E-posta Bildirimlerini Etkinleştir'],
        ['enable_sms_notifications', '0', 'notification', 'SMS Bildirimlerini Etkinleştir'],
        ['enable_browser_notifications', '1', 'notification', 'Tarayıcı Bildirimlerini Etkinleştir'],
        ['notify_leave_request', '1', 'notification', 'İzin Talebi Bildirimi'],
        ['notify_leave_approval', '1', 'notification', 'İzin Onayı Bildirimi'],
        ['notify_expense_request', '1', 'notification', 'Harcama Talebi Bildirimi'],
        ['notify_expense_approval', '1', 'notification', 'Harcama Onayı Bildirimi'],
        ['notify_payroll_generated', '1', 'notification', 'Bordro Oluşturma Bildirimi'],
        
        // Security Settings
        ['min_password_length', '8', 'security', 'Minimum Şifre Uzunluğu'],
        ['password_complexity', '1', 'security', 'Şifre Karmaşıklığı Gerekli'],
        ['password_expiry_days', '90', 'security', 'Şifre Sona Erme Süresi (gün)'],
        ['max_login_attempts', '5', 'security', 'Maksimum Giriş Denemesi'],
        ['lockout_time', '30', 'security', 'Hesap Kilitleme Süresi (dakika)'],
        ['enable_two_factor', '0', 'security', 'İki Faktörlü Kimlik Doğrulamayı Etkinleştir'],
        ['enable_ip_restriction', '0', 'security', 'IP Kısıtlamasını Etkinleştir'],
        ['allowed_ips', '', 'security', 'İzin Verilen IP Adresleri (virgülle ayrılmış)']
    ];
    
    // Check if settings table exists
    $stmt = $db->query("SHOW TABLES LIKE 'settings'");
    $table_exists = $stmt->rowCount() > 0;
    
    if (!$table_exists) {
        // Create settings table
        $db->exec("CREATE TABLE settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            setting_key VARCHAR(100) NOT NULL UNIQUE,
            setting_value TEXT,
            setting_group VARCHAR(100) NOT NULL,
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )");
        
        echo "Settings table created successfully.<br>";
    }
    
    // Insert default settings
    $stmt = $db->prepare("INSERT IGNORE INTO settings (setting_key, setting_value, setting_group, description) VALUES (?, ?, ?, ?)");
    
    foreach ($default_settings as $setting) {
        $stmt->execute($setting);
    }
    
    // Commit transaction
    $db->commit();
    
    echo "Default settings inserted successfully!";
    
} catch (PDOException $e) {
    // Rollback transaction on error
    $db->rollBack();
    echo "Error: " . $e->getMessage();
}
?>