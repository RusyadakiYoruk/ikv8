<?php
// database_setup.php

require_once '../config/config.php';
require_once '../config/database.php';

class DatabaseSetup {
    private $db;
    private $tables = [
        'notifications',
        'employee_leave_balances',
        'leave_requests',
        'leave_types',
        'employees',
        'job_titles',
        'departments',
        'users'
    ];

    public function __construct() {
        $database = new Database();
        $this->db = $database->connect();
    }

    public function setup() {
        try {
            // Foreign key kontrolünü geçici olarak kapat
            $this->db->exec('SET FOREIGN_KEY_CHECKS = 0');

            // Tabloları kontrol et ve yeniden oluştur
            foreach ($this->tables as $table) {
                $this->recreateTable($table);
            }

            // Foreign key kontrolünü tekrar aç
            $this->db->exec('SET FOREIGN_KEY_CHECKS = 1');

            // Temel verileri ekle
            $this->insertBaseData();

            echo "Veritabanı başarıyla kuruldu!\n";
            return true;

        } catch (Exception $e) {
            echo "Hata: " . $e->getMessage() . "\n";
            // Foreign key kontrolünü tekrar aç
            $this->db->exec('SET FOREIGN_KEY_CHECKS = 1');
            return false;
        }
    }

    private function tableExists($table) {
        try {
            $result = $this->db->query("SHOW TABLES LIKE '{$table}'");
            return $result->rowCount() > 0;
        } catch (Exception $e) {
            return false;
        }
    }

    private function recreateTable($table) {
        if ($this->tableExists($table)) {
            echo "{$table} tablosu siliniyor...\n";
            $this->db->exec("DROP TABLE IF EXISTS {$table}");
        }

        echo "{$table} tablosu oluşturuluyor...\n";
        
        switch ($table) {
            case 'users':
                $sql = "CREATE TABLE users (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    email VARCHAR(255) NOT NULL UNIQUE,
                    password VARCHAR(255) NOT NULL,
                    role ENUM('admin', 'manager', 'employee') NOT NULL DEFAULT 'employee',
                    is_active BOOLEAN NOT NULL DEFAULT TRUE,
                    last_login DATETIME,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                break;

            case 'departments':
                $sql = "CREATE TABLE departments (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    description TEXT,
                    manager_id INT NULL,
                    parent_department_id INT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    FOREIGN KEY (parent_department_id) REFERENCES departments(id) ON DELETE SET NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                break;

            case 'job_titles':
                $sql = "CREATE TABLE job_titles (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    title VARCHAR(100) NOT NULL,
                    description TEXT,
                    base_salary DECIMAL(15, 2),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                break;

            case 'employees':
                $sql = "CREATE TABLE employees (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id INT UNIQUE,
                    first_name VARCHAR(100) NOT NULL,
                    last_name VARCHAR(100) NOT NULL,
                    department_id INT,
                    job_title_id INT,
                    manager_id INT,
                    hire_date DATE NOT NULL,
                    termination_date DATE NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
                    FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
                    FOREIGN KEY (job_title_id) REFERENCES job_titles(id) ON DELETE SET NULL,
                    FOREIGN KEY (manager_id) REFERENCES employees(id) ON DELETE SET NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                break;

            case 'leave_types':
                $sql = "CREATE TABLE leave_types (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    description TEXT,
                    default_days INT DEFAULT 0,
                    is_paid BOOLEAN DEFAULT TRUE,
                    requires_approval BOOLEAN DEFAULT TRUE,
                    is_active BOOLEAN DEFAULT TRUE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                break;

            case 'leave_requests':
                $sql = "CREATE TABLE leave_requests (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    employee_id INT NOT NULL,
                    leave_type_id INT NOT NULL,
                    start_date DATE NOT NULL,
                    end_date DATE NOT NULL,
                    total_days DECIMAL(5,1) NOT NULL,
                    reason TEXT,
                    contact_info VARCHAR(255),
                    status ENUM('pending', 'approved', 'rejected', 'cancelled') DEFAULT 'pending',
                    approver_id INT,
                    approver_type ENUM('chief', 'admin', 'manager', 'none') DEFAULT 'none',
                    approved_by INT,
                    approval_date DATETIME,
                    rejection_reason TEXT,
                    comments TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
                    FOREIGN KEY (leave_type_id) REFERENCES leave_types(id) ON DELETE CASCADE,
                    FOREIGN KEY (approver_id) REFERENCES users(id) ON DELETE SET NULL,
                    FOREIGN KEY (approved_by) REFERENCES employees(id) ON DELETE SET NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                break;

            case 'employee_leave_balances':
                $sql = "CREATE TABLE employee_leave_balances (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    employee_id INT NOT NULL,
                    leave_type_id INT NOT NULL,
                    year INT NOT NULL,
                    total_days DECIMAL(5,1) NOT NULL,
                    used_days DECIMAL(5,1) DEFAULT 0,
                    remaining_days DECIMAL(5,1) GENERATED ALWAYS AS (total_days - used_days) STORED,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    UNIQUE KEY (employee_id, leave_type_id, year),
                    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
                    FOREIGN KEY (leave_type_id) REFERENCES leave_types(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                break;

            case 'notifications':
                $sql = "CREATE TABLE notifications (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id INT NOT NULL,
                    type VARCHAR(50) NOT NULL,
                    title VARCHAR(255) NOT NULL,
                    message TEXT NOT NULL,
                    related_id INT NULL,
                    is_read TINYINT(1) DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                break;
        }

        $this->db->exec($sql);
        echo "{$table} tablosu başarıyla oluşturuldu.\n";
    }

    private function insertBaseData() {
        try {
            $this->db->beginTransaction();
    
            // Varsayılan admin kullanıcısı ekle
            $adminPassword = password_hash('Aliveli123', PASSWORD_DEFAULT);
            $stmt = $this->db->prepare("
                INSERT INTO users (email, password, role) 
                VALUES ('levent.gunay@hotmail.com', ?, 'admin')
            ");
            $stmt->execute([$adminPassword]);
            $adminUserId = $this->db->lastInsertId();
            echo "Varsayılan admin kullanıcısı eklendi.\n";
    
            // Örnek departman ekle
            $stmt = $this->db->prepare("
                INSERT INTO departments (name, description) 
                VALUES ('Yönetim', 'Yönetim Departmanı')
            ");
            $stmt->execute();
            $managementDeptId = $this->db->lastInsertId();
            echo "Yönetim departmanı eklendi.\n";
    
            // Örnek iş unvanı ekle
            $stmt = $this->db->prepare("
                INSERT INTO job_titles (title, description) 
                VALUES ('Genel Müdür', 'Şirket Genel Müdürü')
            ");
            $stmt->execute();
            $managerTitleId = $this->db->lastInsertId();
            echo "Genel Müdür unvanı eklendi.\n";
    
            // Admin için çalışan kaydı oluştur
            $stmt = $this->db->prepare("
                INSERT INTO employees (
                    user_id, 
                    first_name, 
                    last_name, 
                    department_id, 
                    job_title_id, 
                    hire_date
                ) VALUES (?, 'Levent', 'Günay', ?, ?, CURRENT_DATE)
            ");
            $stmt->execute([$adminUserId, $managementDeptId, $managerTitleId]);
            echo "Admin için çalışan kaydı oluşturuldu.\n";
    
            // Temel izin türlerini ekle
            $leaveTypes = [
                ['Yıllık İzin', 'Çalışanın yıllık ücretli izni', 14, 1, 1],
                ['Hastalık İzni', 'Sağlık nedeniyle alınan izin', 10, 1, 1],
                ['Mazeret İzni', 'Özel durumlarda alınan kısa süreli izin', 3, 1, 1],
                ['Ücretsiz İzin', 'Maaş ödemesi yapılmayan izin', 0, 0, 1],
                ['Doğum İzni', 'Doğum yapan kadın çalışanlar için izin', 112, 1, 1],
                ['Babalık İzni', 'Çocuğu olan erkek çalışanlar için izin', 5, 1, 1],
                ['Evlilik İzni', 'Evlenen çalışanlar için izin', 3, 1, 1],
                ['Ölüm İzni', 'Yakını vefat eden çalışanlar için izin', 3, 1, 1]
            ];
    
            $stmt = $this->db->prepare("
                INSERT INTO leave_types (name, description, default_days, is_paid, requires_approval) 
                VALUES (?, ?, ?, ?, ?)
            ");
    
            foreach ($leaveTypes as $type) {
                $stmt->execute($type);
            }
            echo "Temel izin türleri eklendi.\n";
    
            $this->db->commit();
            echo "Tüm temel veriler başarıyla eklendi.\n";
    
        } catch (Exception $e) {
            $this->db->rollBack();
            echo "Hata: " . $e->getMessage() . "\n";
            throw $e;
        }
    }
}

// Script'i çalıştır
$setup = new DatabaseSetup();
$setup->setup();

echo "İşlem tamamlandı!\n";





?>