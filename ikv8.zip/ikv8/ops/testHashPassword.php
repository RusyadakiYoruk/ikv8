<?php
// Password verification test script
require_once 'config/config.php';
require_once 'config/database.php';

// Connect to database
$database = new Database();
$db = $database->connect();

// Test password
$test_password = 'Aliveli123';
$email = 'levent.gunay@hotmail.com';

// Get current password hash from database
try {
    $stmt = $db->prepare("SELECT password FROM users WHERE email = :email LIMIT 1");
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        echo "Kullanıcı bulunamadı: $email<br>";
    } else {
        $stored_hash = $user['password'];
        echo "Veritabanındaki hash: $stored_hash<br>";
        
        // Test password_verify
        $is_valid = password_verify($test_password, $stored_hash);
        echo "password_verify sonucu: " . ($is_valid ? 'Başarılı' : 'Başarısız') . "<br>";
        
        // Generate a new hash for comparison
        $new_hash = password_hash($test_password, PASSWORD_DEFAULT);
        echo "Yeni oluşturulan hash: $new_hash<br>";
        
        // Update password in database with new hash
        if (!$is_valid) {
            echo "Şifre doğrulanamadı. Yeni hash ile güncelleniyor...<br>";
            $stmt = $db->prepare("UPDATE users SET password = :password WHERE email = :email");
            $stmt->execute([
                'password' => $new_hash,
                'email' => $email
            ]);
            
            if ($stmt->rowCount() > 0) {
                echo "Şifre başarıyla güncellendi. Şimdi giriş yapmayı tekrar deneyin.<br>";
            } else {
                echo "Şifre güncellenemedi.<br>";
            }
        }
    }
} catch (PDOException $e) {
    echo "Veritabanı hatası: " . $e->getMessage();
}
?>