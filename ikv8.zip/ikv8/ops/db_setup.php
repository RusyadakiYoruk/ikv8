<?php
// Database setup script
require_once 'config/config.php';

try {
    // Create database connection
    $pdo = new PDO("mysql:host=" . DB_HOST, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Create database if not exists
    $pdo->exec("CREATE DATABASE IF NOT EXISTS " . DB_NAME . " CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE " . DB_NAME);
    
    echo "Database created successfully.<br>";
    
    // Create users table
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(255) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        role ENUM('admin', 'manager', 'employee') NOT NULL DEFAULT 'employee',
        is_active BOOLEAN NOT NULL DEFAULT TRUE,
        last_login DATETIME,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )");
    
    echo "Users table created successfully.<br>";
    
    // Check if admin user exists
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
    $stmt->execute(['levent.gunay@hotmail.com']);
    $adminExists = (bool) $stmt->fetchColumn();
    
    if (!$adminExists) {
        // Create admin user with password 'Aliveli123'
        $hashedPassword = password_hash('Aliveli123', PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (email, password, role, is_active) VALUES (?, ?, 'admin', 1)");
        $stmt->execute(['levent.gunay@hotmail.com', $hashedPassword]);
        
        echo "Admin user created successfully.<br>";
    } else {
        echo "Admin user already exists.<br>";
    }
    
    // Create settings table
    $pdo->exec("CREATE TABLE IF NOT EXISTS settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        setting_key VARCHAR(100) NOT NULL UNIQUE,
        setting_value TEXT,
        setting_group VARCHAR(100) NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )");
    
    echo "Settings table created successfully.<br>";
    
    // Insert default settings if not exist
    $defaultSettings = [
        ['company_name', 'Construction Company LLC', 'general', 'Company name'],
        ['company_logo', 'assets/img/logo.png', 'general', 'Company logo path'],
        ['company_address', 'Moscow, Russia', 'general', 'Company address'],
        ['company_phone', '+7 123 456 7890', 'general', 'Company phone number'],
        ['company_email', 'info@construction.ru', 'general', 'Company email'],
        ['default_language', 'en', 'general', 'Default language'],
        ['default_timezone', 'Europe/Moscow', 'general', 'Default timezone'],
        ['currency', 'RUB', 'general', 'Default currency'],
        ['date_format', 'Y-m-d', 'general', 'Date format'],
        ['time_format', 'H:i', 'general', 'Time format']
    ];
    
    $stmt = $pdo->prepare("INSERT IGNORE INTO settings (setting_key, setting_value, setting_group, description) VALUES (?, ?, ?, ?)");
    
    foreach ($defaultSettings as $setting) {
        $stmt->execute($setting);
    }
    
    echo "Default settings inserted successfully.<br>";
    
    echo "Database setup completed successfully!";
    
} catch (PDOException $e) {
    die("Database setup failed: " . $e->getMessage());
}
?>