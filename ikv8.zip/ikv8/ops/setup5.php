<?php
// create_employee_meta_table.php
require_once '../config/config.php';
require_once '../config/database.php';

// Connect to database
$database = new Database();
$db = $database->connect();

try {
    // Create employee_meta table
    $sql = "CREATE TABLE IF NOT EXISTS employee_meta (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT NOT NULL,
        meta_key VARCHAR(100) NOT NULL,
        meta_value TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
        UNIQUE KEY unique_employee_meta (employee_id, meta_key)
    )";
    
    $db->exec($sql);
    echo "employee_meta table created successfully.";
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>