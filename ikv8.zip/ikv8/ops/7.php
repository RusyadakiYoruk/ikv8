

<?php

// Database bağlantısını kontrol et
try {
    $test_query = $db->query("SELECT 1");
    echo "Veritabanı bağlantısı başarılı.<br>";
} catch (Exception $e) {
    echo "Veritabanı bağlantı hatası: " . $e->getMessage() . "<br>";
}