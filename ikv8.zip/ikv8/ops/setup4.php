<?php
// create_job_titles_table.php
require_once '../config/config.php';
require_once '../config/database.php';

// Connect to database
$database = new Database();
$db = $database->connect();

try {
    // Check if job_titles table exists
    $stmt = $db->query("SHOW TABLES LIKE 'job_titles'");
    $tableExists = $stmt->rowCount() > 0;
    
    if (!$tableExists) {
        // Create job_titles table
        $sql = "CREATE TABLE job_titles (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(100) NOT NULL,
            description TEXT,
            base_salary DECIMAL(15, 2),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )";
        
        $db->exec($sql);
        echo "job_titles table created successfully.<br>";
    } else {
        echo "job_titles table already exists.<br>";
    }
    
    // Insert some default job titles if the table is empty
    $stmt = $db->query("SELECT COUNT(*) FROM job_titles");
    $count = $stmt->fetchColumn();
    
    if ($count == 0) {
        $jobTitles = [
            ['İnşaat Mühendisi', 'İnşaat projelerinin tasarımı ve uygulaması', 60000.00],
            ['Mimar', 'Bina ve yapıların tasarımı', 55000.00],
            ['Proje Müdürü', 'İnşaat projelerinin yönetimi', 75000.00],
            ['Şantiye Şefi', 'Şantiye operasyonlarının yönetimi', 65000.00],
            ['İş Güvenliği Uzmanı', 'İş sağlığı ve güvenliği standartlarının uygulanması', 50000.00],
            ['Elektrik Mühendisi', 'Elektrik sistemlerinin tasarımı ve uygulaması', 58000.00],
            ['Makine Mühendisi', 'Mekanik sistemlerin tasarımı ve uygulaması', 58000.00],
            ['Muhasebeci', 'Finansal kayıtların tutulması', 45000.00],
            ['İnsan Kaynakları Uzmanı', 'İK süreçlerinin yönetimi', 48000.00],
            ['Satın Alma Uzmanı', 'Malzeme ve ekipman tedariki', 46000.00],
            ['Pazarlama Uzmanı', 'Pazarlama stratejilerinin geliştirilmesi', 47000.00],
            ['Genel Müdür', 'Şirketin genel yönetimi', 100000.00],
            ['Finans Müdürü', 'Finansal operasyonların yönetimi', 80000.00],
            ['İK Müdürü', 'İnsan kaynakları departmanının yönetimi', 78000.00],
            ['Operasyon Müdürü', 'Operasyonel süreçlerin yönetimi', 82000.00]
        ];
        
        $stmt = $db->prepare("INSERT INTO job_titles (title, description, base_salary) VALUES (?, ?, ?)");
        
        foreach ($jobTitles as $jobTitle) {
            $stmt->execute($jobTitle);
        }
        
        echo "Default job titles inserted successfully.";
    } else {
        echo "Job titles already exist in the table.";
    }
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>