<?php
// update_security_settings.php - Script to update security settings in the database
require_once 'config/config.php';
require_once 'config/database.php';

// Connect to database
$database = new Database();
$db = $database->connect();

try {
    // Begin transaction
    $db->beginTransaction();
    
    // Delete IP restriction settings
    $stmt = $db->prepare("DELETE FROM settings WHERE setting_key IN ('enable_ip_restriction', 'allowed_ips')");
    $stmt->execute();
    
    // Update security settings descriptions and types
    $updates = [
        ['min_password_length', 'Minimum Şifre Uzunluğu', '8'],
        ['password_complexity', 'Şifre Karmaşıklığı Gerekli', '1'],
        ['password_expiry_days', 'Şifre Sona Erme Süresi (gün)', '90'],
        ['max_login_attempts', 'Maksimum Giriş Denemesi', '5'],
        ['lockout_time', 'Hesap Kilitleme Süresi (dakika)', '30'],
        ['enable_two_factor', 'İki Faktörlü Kimlik Doğrulamayı Etkinleştir', '0']
    ];
    
    $stmt = $db->prepare("UPDATE settings SET description = ?, setting_value = ? WHERE setting_key = ?");
    
    foreach ($updates as $update) {
        $stmt->execute([$update[1], $update[2], $update[0]]);
    }
    
    // Commit transaction
    $db->commit();
    
    echo "Security settings updated successfully!";
    
} catch (PDOException $e) {
    // Rollback transaction on error
    $db->rollBack();
    echo "Error: " . $e->getMessage();
}
?>