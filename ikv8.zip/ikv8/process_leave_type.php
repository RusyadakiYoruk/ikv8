<?php
// process_leave_type.php
session_start();
require_once 'config/config.php';
require_once 'config/database.php';

// Yetki kontrolü
if (!isset($_SESSION['user_id'])) {
    die(json_encode(['success' => false, 'message' => 'Unauthorized']));
}

$database = new Database();
$db = $database->connect();

// Kullanıcı rolünü kontrol et
$stmt = $db->prepare("SELECT role FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user_role = $stmt->fetchColumn();

if ($user_role !== 'admin') {
    die(json_encode(['success' => false, 'message' => 'Unauthorized']));
}

try {
    $action = $_POST['action'] ?? '';

    switch ($action) {
        case 'add':
            // Zorunlu alanları kontrol et
            if (empty($_POST['name']) || !isset($_POST['default_days'])) {
                throw new Exception('Lütfen tüm zorunlu alanları doldurun.');
            }

            $stmt = $db->prepare("
                INSERT INTO leave_types (
                    name, description, default_days, is_paid, 
                    requires_approval, is_active
                ) VALUES (?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $_POST['name'],
                $_POST['description'] ?? null,
                $_POST['default_days'],
                $_POST['is_paid'] ?? 1,
                $_POST['requires_approval'] ?? 1,
                $_POST['is_active'] ?? 1
            ]);

            // Log activity
            logActivity($db, $_SESSION['user_id'], 'leave_type_added', "Yeni izin türü eklendi: {$_POST['name']}");

            echo json_encode(['success' => true]);
            break;
            header('Location: leave_types.php');

        case 'edit':
            // ID ve zorunlu alanları kontrol et
            if (!isset($_POST['id']) || empty($_POST['name']) || !isset($_POST['default_days'])) {
                throw new Exception('Lütfen tüm zorunlu alanları doldurun.');
            }

            $stmt = $db->prepare("
                UPDATE leave_types 
                SET name = ?,
                    description = ?,
                    default_days = ?,
                    is_paid = ?,
                    requires_approval = ?,
                    is_active = ?
                WHERE id = ?
            ");

            $stmt->execute([
                $_POST['name'],
                $_POST['description'] ?? null,
                $_POST['default_days'],
                $_POST['edit_is_paid'] ?? 1,
                $_POST['edit_requires_approval'] ?? 1,
                $_POST['edit_is_active'] ?? 1,
                $_POST['id']
            ]);

            // Log activity
            logActivity($db, $_SESSION['user_id'], 'leave_type_updated', "İzin türü güncellendi: {$_POST['name']}");

            echo json_encode(['success' => true]);
            break;

        case 'delete':
            // ID kontrolü
            if (!isset($_POST['id'])) {
                throw new Exception('Geçersiz istek.');
            }

            // Kullanımda olan izin türünü silmeyi engelle
            $stmt = $db->prepare("
                SELECT COUNT(*) 
                FROM leave_requests 
                WHERE leave_type_id = ?
            ");
            $stmt->execute([$_POST['id']]);
            if ($stmt->fetchColumn() > 0) {
                throw new Exception('Bu izin türü kullanımda olduğu için silinemez.');
            }

            $stmt = $db->prepare("DELETE FROM leave_types WHERE id = ?");
            $stmt->execute([$_POST['id']]);

            // Log activity
            logActivity($db, $_SESSION['user_id'], 'leave_type_deleted', "İzin türü silindi (ID: {$_POST['id']})");

            echo json_encode(['success' => true]);
            break;
            header('Location: leave_types.php');

        default:
            throw new Exception('Geçersiz işlem.');
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

function logActivity($db, $user_id, $activity_type, $description) {
    $stmt = $db->prepare("
        INSERT INTO activity_logs (user_id, activity_type, description, ip_address)
        VALUES (?, ?, ?, ?)
    ");
    $stmt->execute([$user_id, $activity_type, $description, $_SERVER['REMOTE_ADDR']]);
}
?>