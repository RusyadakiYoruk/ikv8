<?php
// Calendar Page
session_start();

// Load configuration
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';

// Set timezone
date_default_timezone_set(DEFAULT_TIMEZONE);

// Connect to database
$database = new Database();
$db = $database->connect();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Get user information
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

// Handle AJAX requests
if (isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    try {
        switch ($_POST['action']) {
            case 'add':
                // Validate CSRF token
                if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
                    throw new Exception('Geçersiz form gönderimi.');
                }
                
                $stmt = $db->prepare("
                    INSERT INTO calendar_events (
                        title, description, start_datetime, end_datetime, 
                        location, event_type, is_all_day, created_by, 
                        visibility, department_id
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                
                $stmt->execute([
                    $_POST['title'],
                    $_POST['description'] ?? null,
                    $_POST['start'],
                    $_POST['end'],
                    $_POST['location'] ?? null,
                    $_POST['event_type'],
                    isset($_POST['is_all_day']) ? 1 : 0,
                    $user_id,
                    $_POST['visibility'],
                    $_POST['department_id'] ?? null
                ]);
                
                $event_id = $db->lastInsertId();
                
                // Add attendees if any
                if (!empty($_POST['attendees'])) {
                    $stmt = $db->prepare("
                        INSERT INTO calendar_event_attendees (event_id, employee_id)
                        VALUES (?, ?)
                    ");
                    
                    foreach ($_POST['attendees'] as $employee_id) {
                        $stmt->execute([$event_id, $employee_id]);
                    }
                }
                
                echo json_encode(['success' => true, 'id' => $event_id]);
                break;
                
            case 'update':
                // Validate CSRF token
                if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
                    throw new Exception('Geçersiz form gönderimi.');
                }
                
                $stmt = $db->prepare("
                    UPDATE calendar_events 
                    SET title = ?, description = ?, start_datetime = ?, 
                        end_datetime = ?, location = ?, event_type = ?,
                        is_all_day = ?, visibility = ?, department_id = ?
                    WHERE id = ? AND (created_by = ? OR ? = 'admin')
                ");
                
                $stmt->execute([
                    $_POST['title'],
                    $_POST['description'] ?? null,
                    $_POST['start'],
                    $_POST['end'],
                    $_POST['location'] ?? null,
                    $_POST['event_type'],
                    isset($_POST['is_all_day']) ? 1 : 0,
                    $_POST['visibility'],
                    $_POST['department_id'] ?? null,
                    $_POST['id'],
                    $user_id,
                    $user_role
                ]);
                
                // Update attendees
                if (isset($_POST['attendees'])) {
                    // Remove existing attendees
                    $stmt = $db->prepare("DELETE FROM calendar_event_attendees WHERE event_id = ?");
                    $stmt->execute([$_POST['id']]);
                    
                    // Add new attendees
                    $stmt = $db->prepare("
                        INSERT INTO calendar_event_attendees (event_id, employee_id)
                        VALUES (?, ?)
                    ");
                    
                    foreach ($_POST['attendees'] as $employee_id) {
                        $stmt->execute([$_POST['id'], $employee_id]);
                    }
                }
                
                echo json_encode(['success' => true]);
                break;
                
            case 'delete':
                // Validate CSRF token
                if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
                    throw new Exception('Geçersiz form gönderimi.');
                }
                
                $stmt = $db->prepare("
                    DELETE FROM calendar_events 
                    WHERE id = ? AND (created_by = ? OR ? = 'admin')
                ");
                
                $stmt->execute([$_POST['id'], $user_id, $user_role]);
                
                echo json_encode(['success' => true]);
                break;
                
            case 'fetch':
                $start = $_POST['start'];
                $end = $_POST['end'];
                
                // Build query based on user role and visibility
                $sql = "
                    SELECT e.*, 
                           d.name as department_name,
                           CONCAT(emp.first_name, ' ', emp.last_name) as created_by_name
                    FROM calendar_events e
                    LEFT JOIN departments d ON e.department_id = d.id
                    LEFT JOIN employees emp ON e.created_by = emp.user_id
                    WHERE e.start_datetime BETWEEN ? AND ?
                    AND (
                        e.visibility = 'public'
                        OR e.created_by = ?
                        OR (e.visibility = 'department' AND e.department_id IN (
                            SELECT department_id FROM employees WHERE user_id = ?
                        ))
                        OR ? = 'admin'
                    )
                ";
                
                $stmt = $db->prepare($sql);
                $stmt->execute([$start, $end, $user_id, $user_id, $user_role]);
                $events = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                // Format events for FullCalendar
                $formatted_events = array_map(function($event) {
                    return [
                        'id' => $event['id'],
                        'title' => $event['title'],
                        'start' => $event['start_datetime'],
                        'end' => $event['end_datetime'],
                        'allDay' => (bool)$event['is_all_day'],
                        'description' => $event['description'],
                        'location' => $event['location'],
                        'eventType' => $event['event_type'],
                        'visibility' => $event['visibility'],
                        'departmentId' => $event['department_id'],
                        'departmentName' => $event['department_name'],
                        'createdBy' => $event['created_by_name'],
                        'editable' => $event['created_by'] == $user_id || $user_role == 'admin'
                    ];
                }, $events);
                
                echo json_encode($formatted_events);
                break;
        }
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit;
}

// Get departments for dropdown
$stmt = $db->query("SELECT * FROM departments ORDER BY name");
$departments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get employees for attendees selection
$stmt = $db->query("
    SELECT e.id, e.first_name, e.last_name, d.name as department_name
    FROM employees e
    LEFT JOIN departments d ON e.department_id = d.id
    WHERE e.termination_date IS NULL OR e.termination_date > CURRENT_DATE
    ORDER BY e.first_name, e.last_name
");
$employees = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Include header
include 'includes/header.php';
?>

<div class="flex h-screen bg-gray-100">
    <!-- Sidebar -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- Main Content -->
    <div class="flex-1 overflow-auto ml-0 lg:ml-64 pt-16">
        <div class="py-6 px-8">
            <!-- Page Header -->
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold text-gray-800">Takvim</h1>
                <button type="button" onclick="showAddEventModal()" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                    <svg class="mr-2 -ml-1 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                    </svg>
                    Yeni Etkinlik
                </button>
            </div>
            
            <!-- Calendar -->
            <div class="bg-white rounded-lg shadow overflow-hidden">
                <div class="p-6">
                    <div id="calendar" style="height: 800px;"></div> <!-- Yükseklik eklendi -->
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add/Edit Event Modal -->
<div id="eventModal" class="fixed inset-0 z-50 overflow-y-auto hidden" aria-labelledby="modal-title" role="dialog" aria-modal="true">
    <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" aria-hidden="true"></div>
        <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
        <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
            <form id="eventForm">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="add">
                <input type="hidden" name="id" id="event_id">
                
                <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                    <div class="sm:flex sm:items-start">
                        <div class="mt-3 text-center sm:mt-0 sm:text-left w-full">
                            <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                                Yeni Etkinlik
                            </h3>
                            <div class="mt-4 space-y-4">
                                <div>
                                    <label for="title" class="block text-sm font-medium text-gray-700">Başlık <span class="text-red-500">*</span></label>
                                    <input type="text" name="title" id="title" required class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                
                                <div>
                                    <label for="description" class="block text-sm font-medium text-gray-700">Açıklama</label>
                                    <textarea name="description" id="description" rows="3" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"></textarea>
                                </div>
                                
                                <div class="grid grid-cols-2 gap-4">
                                    <div>
                                        <label for="start" class="block text-sm font-medium text-gray-700">Başlangıç <span class="text-red-500">*</span></label>
                                        <input type="datetime-local" name="start" id="start" required class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                    </div>
                                    
                                    <div>
                                        <label for="end" class="block text-sm font-medium text-gray-700">Bitiş <span class="text-red-500">*</span></label>
                                        <input type="datetime-local" name="end" id="end" required class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                    </div>
                                </div>
                                
                                <div>
                                    <label for="location" class="block text-sm font-medium text-gray-700">Konum</label>
                                    <input type="text" name="location" id="location" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                
                                <div class="grid grid-cols-2 gap-4">
                                    <div>
                                        <label for="event_type" class="block text-sm font-medium text-gray-700">Etkinlik Türü <span class="text-red-500">*</span></label>
                                        <select name="event_type" id="event_type" required class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                            <option value="meeting">Toplantı</option>
                                            <option value="holiday">Tatil</option>
                                            <option value="event">Etkinlik</option>
                                            <option value="reminder">Hatırlatma</option>
                                        </select>
                                    </div>
                                    
                                    <div>
                                        <label for="visibility" class="block text-sm font-medium text-gray-700">Görünürlük <span class="text-red-500">*</span></label>
                                        <select name="visibility" id="visibility" required class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                            <option value="public">Herkese Açık</option>
                                            <option value="private">Özel</option>
                                            <option value="department">Departman</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div id="departmentSection" class="hidden">
                                    <label for="department_id" class="block text-sm font-medium text-gray-700">Departman</label>
                                    <select name="department_id" id="department_id" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                        <option value="">Seçiniz</option>
                                        <?php foreach ($departments as $dept): ?>
                                            <option value="<?php echo $dept['id']; ?>"><?php echo htmlspecialchars($dept['name']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div>
                                    <label for="attendees" class="block text-sm font-medium text-gray-700">Katılımcılar</label>
                                    <select name="attendees[]" id="attendees" multiple class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                        <?php foreach ($employees as $emp): ?>
                                            <option value="<?php echo $emp['id']; ?>">
                                                <?php echo htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name'] . ' (' . $emp['department_name'] . ')'); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div>
                                    <label class="inline-flex items-center">
                                        <input type="checkbox" name="is_all_day" id="is_all_day" class="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                                        <span class="ml-2 text-sm text-gray-600">Tüm Gün</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                    <button type="submit" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm">
                        Kaydet
                    </button>
                    <button type="button" class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm close-modal">
                        İptal
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Event Modal -->
<div id="deleteEventModal" class="fixed inset-0 z-50 overflow-y-auto hidden" aria-labelledby="modal-title" role="dialog" aria-modal="true">
    <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" aria-hidden="true"></div>
        <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
        <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
            <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <div class="sm:flex sm:items-start">
                    <div class="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-red-100 sm:mx-0 sm:h-10 sm:w-10">
                        <svg class="h-6 w-6 text-red-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                        </svg>
                    </div>
                    <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                        <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                            Etkinliği Sil
                        </h3>
                        <div class="mt-2">
                            <p class="text-sm text-gray-500">
                                Bu etkinliği silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <button type="button" id="confirmDelete" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-red-600 text-base font-medium text-white hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 sm:ml-3 sm:w-auto sm:text-sm">
                    Sil
                </button>
                <button type="button" class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm close-modal">
                    İptal
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Calendar Initialization Script -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize calendar
    var calendarEl = document.getElementById('calendar');
    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay,listWeek'
        },
        height: 'auto', // Otomatik yükseklik
        locale: 'tr',
        editable: true,
        selectable: true,
        selectMirror: true,
        dayMaxEvents: true,
        events: function(info, successCallback, failureCallback) {
            // Fetch events from server
            fetch('calendar.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'fetch',
                    start: info.startStr,
                    end: info.endStr
                })
            })
            .then(response => response.json())
            .then(data => successCallback(data))
            .catch(error => failureCallback(error));
        },
        select: function(info) {
            showAddEventModal(info.startStr, info.endStr);
        },
        eventClick: function(info) {
            showEditEventModal(info.event);
        },
        eventDrop: function(info) {
            updateEvent(info.event);
        },
        eventResize: function(info) {
            updateEvent(info.event);
        }
    });
    
    calendar.render();
    
    // Show add event modal
    window.showAddEventModal = function(start = null, end = null) {
        document.getElementById('eventForm').reset();
        document.getElementById('eventForm').action.value = 'add';
        document.getElementById('event_id').value = '';
        document.getElementById('modal-title').textContent = 'Yeni Etkinlik';
        
        if (start) document.getElementById('start').value = start.slice(0, 16);
        if (end) document.getElementById('end').value = end.slice(0, 16);
        
        document.getElementById('eventModal').classList.remove('hidden');
    };
    
    // Show edit event modal
    window.showEditEventModal = function(event) {
        document.getElementById('eventForm').reset();
        document.getElementById('eventForm').action.value = 'update';
        document.getElementById('event_id').value = event.id;
        document.getElementById('modal-title').textContent = 'Etkinliği Düzenle';
        
        document.getElementById('title').value = event.title;
        document.getElementById('description').value = event.extendedProps.description || '';
        document.getElementById('start').value = event.start.toISOString().slice(0, 16);
        document.getElementById('end').value = event.end ? event.end.toISOString().slice(0, 16) : '';
        document.getElementById('location').value = event.extendedProps.location || '';
        document.getElementById('event_type').value = event.extendedProps.eventType;
        document.getElementById('visibility').value = event.extendedProps.visibility;
        document.getElementById('department_id').value = event.extendedProps.departmentId || '';
        document.getElementById('is_all_day').checked = event.allDay;
        
        // Show delete button for editable events
        if (event.extendedProps.editable) {
            const deleteButton = document.createElement('button');
            deleteButton.type = 'button';
            deleteButton.className = 'mt-3 w-full inline-flex justify-center rounded-md border border-red-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-red-700 hover:bg-red-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm';
            deleteButton.textContent = 'Sil';
            deleteButton.onclick = function() {
                document.getElementById('eventModal').classList.add('hidden');
                showDeleteEventModal(event.id);
            };
            
            const modalFooter = document.querySelector('#eventModal .bg-gray-50');
            if (!modalFooter.querySelector('.delete-button')) {
                modalFooter.appendChild(deleteButton);
                deleteButton.classList.add('delete-button');
            }
        }
        
        document.getElementById('eventModal').classList.remove('hidden');
    };
    
    // Show delete event modal
    window.showDeleteEventModal = function(eventId) {
        const modal = document.getElementById('deleteEventModal');
        const confirmButton = document.getElementById('confirmDelete');
        
        confirmButton.onclick = function() {
            deleteEvent(eventId);
        };
        
        modal.classList.remove('hidden');
    };
    
    // Handle form submission
    document.getElementById('eventForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        
        fetch('calendar.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                calendar.refetchEvents();
                document.getElementById('eventModal').classList.add('hidden');
            } else {
                alert('Bir hata oluştu: ' + data.error);
            }
        })
        .catch(error => {
            alert('Bir hata oluştu: ' + error);
        });
    });
    
    // Update event
    function updateEvent(event) {
        fetch('calendar.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                action: 'update',
                csrf_token: document.querySelector('input[name="csrf_token"]').value,
                id: event.id,
                title: event.title,
                start: event.start.toISOString(),
                end: event.end ? event.end.toISOString() : event.start.toISOString(),
                is_all_day: event.allDay ? 1 : 0
            })
        })
        .then(response => response.json())
        .then(data => {
            if (!data.success) {
                alert('Bir hata oluştu: ' + data.error);
                calendar.refetchEvents();
            }
        })
        .catch(error => {
            alert('Bir hata oluştu: ' + error);
            calendar.refetchEvents();
        });
    }
    // Delete event
    function deleteEvent(eventId) {
        fetch('calendar.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                action: 'delete',
                csrf_token: document.querySelector('input[name="csrf_token"]').value,
                id: eventId
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                calendar.refetchEvents();
                document.getElementById('deleteEventModal').classList.add('hidden');
            } else {
                alert('Bir hata oluştu: ' + data.error);
            }
        })
        .catch(error => {
            alert('Bir hata oluştu: ' + error);
        });
    }

    // Handle visibility change
    document.getElementById('visibility').addEventListener('change', function(e) {
        const departmentSection = document.getElementById('departmentSection');
        if (e.target.value === 'department') {
            departmentSection.classList.remove('hidden');
            document.getElementById('department_id').required = true;
        } else {
            departmentSection.classList.add('hidden');
            document.getElementById('department_id').required = false;
        }
    });

    // Handle all-day event toggle
    document.getElementById('is_all_day').addEventListener('change', function(e) {
        const startInput = document.getElementById('start');
        const endInput = document.getElementById('end');
        
        if (e.target.checked) {
            startInput.type = 'date';
            endInput.type = 'date';
        } else {
            startInput.type = 'datetime-local';
            endInput.type = 'datetime-local';
        }
    });

    // Close modals
    document.querySelectorAll('.close-modal').forEach(button => {
        button.addEventListener('click', function() {
            document.getElementById('eventModal').classList.add('hidden');
            document.getElementById('deleteEventModal').classList.add('hidden');
            
            // Remove delete button if exists
            const deleteButton = document.querySelector('.delete-button');
            if (deleteButton) {
                deleteButton.remove();
            }
        });
    });

    // Close modals when clicking outside
    window.addEventListener('click', function(event) {
        if (event.target.classList.contains('fixed')) {
            event.target.classList.add('hidden');
            
            // Remove delete button if exists
            const deleteButton = document.querySelector('.delete-button');
            if (deleteButton) {
                deleteButton.remove();
            }
        }
    });
});
</script>

<!-- Custom Calendar Styles -->
<style>
/* FullCalendar Styles */
.fc {
    height: 100%;
    background: white;
}

.fc .fc-toolbar {
    padding: 1rem;
}

.fc .fc-toolbar-title {
    font-size: 1.25rem;
    font-weight: 600;
}

.fc .fc-button-primary {
    background-color: #3b82f6;
    border-color: #3b82f6;
}

.fc .fc-button-primary:hover {
    background-color: #2563eb;
    border-color: #2563eb;
}

.fc .fc-button-primary:disabled {
    background-color: #93c5fd;
    border-color: #93c5fd;
}

.fc .fc-daygrid-day {
    min-height: 100px;
}

.fc .fc-day-today {
    background-color: #eff6ff !important;
}

.fc .fc-event {
    border-radius: 4px;
    padding: 2px 4px;
    margin: 1px 0;
    cursor: pointer;
}

/* Responsive Design */
@media (max-width: 768px) {
    .fc .fc-toolbar {
        flex-direction: column;
        gap: 1rem;
    }
    
    .fc .fc-toolbar-chunk {
        display: flex;
        justify-content: center;
    }
}
</style>

<?php
// Include footer
include 'includes/footer.php';
?>