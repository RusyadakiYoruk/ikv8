<?php
// General Settings Page - Attendance Settings
session_start();

// Load configuration
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';

// Set timezone
date_default_timezone_set(DEFAULT_TIMEZONE);

// Connect to database
$database = new Database();
$db = $database->connect();

// Check if user is logged in and has admin role
require_role('admin');

// Get user information
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

// Get employee information if available
$employee = null;
$stmt = $db->prepare("SELECT * FROM employees WHERE user_id = :user_id LIMIT 1");
$stmt->execute(['user_id' => $user_id]);
$employee = $stmt->fetch(PDO::FETCH_ASSOC);

// Define setting groups
$setting_groups = [
    'general' => 'Genel Ayarlar',
    'attendance' => 'Devam Takibi',
    'leave' => 'İzin Ayarları',
    'expense' => 'Harcama Ayarları',
    'performance' => 'Performans Ayarları',
    'notification' => 'Bildirim Ayarları',
    'security' => 'Güvenlik Ayarları'
];

// Get current group from URL parameter
$current_group = isset($_GET['group']) && array_key_exists($_GET['group'], $setting_groups) ? $_GET['group'] : 'general';

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
        set_flash_message('settings_error', 'Geçersiz form gönderimi. Lütfen tekrar deneyin.', 'danger');
    } else {
        try {
            // Begin transaction
            $db->beginTransaction();
            
            // Get all toggle settings for current group to handle unchecked checkboxes
            $stmt = $db->prepare("SELECT setting_key FROM settings WHERE setting_group = :group AND (setting_key LIKE 'enable_%' OR setting_key LIKE 'disable_%' OR setting_value IN ('0', '1'))");
            $stmt->execute(['group' => $current_group]);
            $toggle_settings = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            // Set all toggle settings to 0 (off) by default
            foreach ($toggle_settings as $toggle_key) {
                $stmt = $db->prepare("UPDATE settings SET setting_value = '0' WHERE setting_key = :key");
                $stmt->execute(['key' => $toggle_key]);
            }
            
            // Update settings from form data
            foreach ($_POST as $key => $value) {
                // Skip CSRF token and submit button
                if ($key === 'csrf_token' || $key === 'submit') {
                    continue;
                }
                
                // Handle checkbox groups
                if (is_array($value)) {
                    $value = implode(',', $value);
                }
                
                // For toggle settings (checkboxes), set to 1 (on) if present in POST data
                if (in_array($key, $toggle_settings)) {
                    $value = '1';
                }
                
                // Sanitize input
                $key = sanitize($key);
                $value = sanitize($value);
                
                // Update setting in database
                $stmt = $db->prepare("UPDATE settings SET setting_value = :value WHERE setting_key = :key");
                $stmt->execute([
                    'key' => $key,
                    'value' => $value
                ]);
            }
            
            // Commit transaction
            $db->commit();
            
            // Log activity
            $stmt = $db->prepare("INSERT INTO activity_logs (user_id, activity_type, description, ip_address) VALUES (:user_id, 'settings_update', :description, :ip_address)");
            $stmt->execute([
                'user_id' => $user_id,
                'description' => 'Genel ayarlar güncellendi: ' . $setting_groups[$current_group],
                'ip_address' => $_SERVER['REMOTE_ADDR']
            ]);
            
            set_flash_message('settings_success', 'Ayarlar başarıyla güncellendi.', 'success');
        } catch (PDOException $e) {
            // Rollback transaction on error
            $db->rollBack();
            set_flash_message('settings_error', 'Ayarlar güncellenirken bir hata oluştu: ' . $e->getMessage(), 'danger');
        }
    }
    
    // Redirect to prevent form resubmission
    redirect('general_settings.php?group=' . $current_group);
}

// Get settings for current group
$stmt = $db->prepare("SELECT * FROM settings WHERE setting_group = :group ORDER BY id");
$stmt->execute(['group' => $current_group]);
$settings = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Include header
include 'includes/header.php';
?>

<div class="flex h-screen bg-gray-100">
    <!-- Sidebar -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- Main Content -->
    <div class="flex-1 overflow-auto ml-0 lg:ml-64 pt-16">
        <div class="py-6 px-8">
            <!-- Page Header -->
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold text-gray-800">Genel Ayarlar</h1>
                <nav class="flex" aria-label="Breadcrumb">
                    <ol class="inline-flex items-center space-x-1 md:space-x-3">
                        <li class="inline-flex items-center">
                            <a href="index.php" class="text-gray-700 hover:text-gray-900 inline-flex items-center">
                                <svg class="w-5 h-5 mr-2.5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"></path>
                                </svg>
                                Dashboard
                            </a>
                        </li>
                        <li>
                            <div class="flex items-center">
                                <svg class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <a href="general_settings.php" class="ml-1 text-gray-700 hover:text-gray-900 md:ml-2">Ayarlar</a>
                            </div>
                        </li>
                        <li aria-current="page">
                            <div class="flex items-center">
                                <svg class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span class="ml-1 text-gray-500 md:ml-2"><?php echo $setting_groups[$current_group]; ?></span>
                            </div>
                        </li>
                    </ol>
                </nav>
            </div>
            
            <!-- Flash Messages -->
            <?php if (isset($_SESSION['flash_messages']['settings_success'])): ?>
                <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6" role="alert">
                    <p><?php echo $_SESSION['flash_messages']['settings_success']['message']; ?></p>
                </div>
                <?php unset($_SESSION['flash_messages']['settings_success']); ?>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['flash_messages']['settings_error'])): ?>
                <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                    <p><?php echo $_SESSION['flash_messages']['settings_error']['message']; ?></p>
                </div>
                <?php unset($_SESSION['flash_messages']['settings_error']); ?>
            <?php endif; ?>
            
            <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
                <!-- Settings Navigation -->
                <div class="col-span-1">
                    <div class="bg-white rounded-lg shadow">
                        <div class="border-b px-4 py-3">
                            <h3 class="text-lg font-semibold text-gray-700">Ayar Kategorileri</h3>
                        </div>
                        <div class="p-4">
                            <ul class="space-y-2">
                                <?php foreach ($setting_groups as $group_key => $group_name): ?>
                                    <li>
                                        <a href="general_settings.php?group=<?php echo $group_key; ?>" class="<?php echo $current_group === $group_key ? 'bg-blue-50 text-blue-600 border-l-4 border-blue-500' : 'text-gray-700 hover:bg-gray-50'; ?> block px-4 py-2 rounded">
                                            <?php echo $group_name; ?>
                                        </a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <!-- Settings Form -->
                <div class="col-span-1 md:col-span-3">
                    <div class="bg-white rounded-lg shadow">
                        <div class="border-b px-4 py-3">
                            <h3 class="text-lg font-semibold text-gray-700"><?php echo $setting_groups[$current_group]; ?></h3>
                        </div>
                        <div class="p-6">
                            <form method="POST" action="general_settings.php?group=<?php echo $current_group; ?>">
                                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                
                                <?php if (empty($settings)): ?>
                                    <div class="text-center py-4">
                                        <p class="text-gray-500">Bu kategori için henüz ayar bulunmamaktadır.</p>
                                    </div>
                                <?php else: ?>
                                    <div class="space-y-6">
                                        <?php foreach ($settings as $setting): ?>
                                            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
                                                <div class="col-span-1">
                                                    <label for="<?php echo $setting['setting_key']; ?>" class="block text-sm font-medium text-gray-700">
                                                        <?php echo $setting['description']; ?>
                                                    </label>
                                                </div>
                                                <div class="col-span-1 md:col-span-2">
                                                    <?php
                                                    // Determine input type based on setting key or value
$input_type = 'text';
$input_options = '';
$input_min = '';
$input_max = '';
$input_step = '';

if (strpos($setting['setting_key'], 'email') !== false) {
    $input_type = 'email';
} elseif (strpos($setting['setting_key'], 'password') !== false && strpos($setting['setting_key'], 'length') === false && strpos($setting['setting_key'], 'complexity') === false && strpos($setting['setting_key'], 'expiry') === false) {
    $input_type = 'password';
} elseif (strpos($setting['setting_key'], 'date') !== false) {
    $input_type = 'date';
} elseif (strpos($setting['setting_key'], 'time') !== false && strpos($setting['setting_key'], 'timeout') === false && strpos($setting['setting_key'], 'lockout') === false) {
    $input_type = 'time';
} elseif (strpos($setting['setting_key'], 'color') !== false) {
    $input_type = 'color';
} elseif (strpos($setting['setting_key'], 'enable') !== false || strpos($setting['setting_key'], 'disable') !== false || $setting['setting_key'] === 'password_complexity' || $setting['setting_value'] === '0' || $setting['setting_value'] === '1') {
    $input_type = 'toggle';
} elseif ($setting['setting_key'] === 'work_days') {
    $input_type = 'checkbox_group';
    $input_options = ['Monday' => 'Pazartesi', 'Tuesday' => 'Salı', 'Wednesday' => 'Çarşamba', 'Thursday' => 'Perşembe', 'Friday' => 'Cuma', 'Saturday' => 'Cumartesi', 'Sunday' => 'Pazar'];
} elseif ($setting['setting_key'] === 'week_start') {
    $input_type = 'select';
    $input_options = ['Monday' => 'Pazartesi', 'Tuesday' => 'Salı', 'Wednesday' => 'Çarşamba', 'Thursday' => 'Perşembe', 'Friday' => 'Cuma', 'Saturday' => 'Cumartesi', 'Sunday' => 'Pazar'];
} elseif ($setting['setting_key'] === 'performance_review_frequency') {
    $input_type = 'select';
    $input_options = ['monthly' => 'Aylık', 'quarterly' => 'Üç Aylık', 'biannually' => 'Altı Aylık', 'annually' => 'Yıllık'];
} elseif ($setting['setting_key'] === 'min_password_length') {
    $input_type = 'number';
    $input_min = '6';
    $input_max = '32';
    $input_step = '1';
} elseif ($setting['setting_key'] === 'password_expiry_days') {
    $input_type = 'number';
    $input_min = '0';
    $input_max = '365';
    $input_step = '1';
} elseif ($setting['setting_key'] === 'max_login_attempts') {
    $input_type = 'number';
    $input_min = '1';
    $input_max = '10';
    $input_step = '1';
} elseif ($setting['setting_key'] === 'lockout_time') {
    $input_type = 'number';
    $input_min = '1';
    $input_max = '1440';
    $input_step = '1';
} elseif (strpos($setting['setting_key'], 'threshold') !== false || strpos($setting['setting_key'], 'multiplier') !== false) {
    $input_type = 'number';
    $input_step = '0.01';
}
                                                    
                                                    // Render appropriate input based on type
                                                    switch ($input_type) {
                                                        case 'toggle':
                                                            ?>
                                                            <div class="flex items-center">
                                                                <label class="inline-flex items-center cursor-pointer">
                                                                    <input type="checkbox" name="<?php echo $setting['setting_key']; ?>" value="1" class="sr-only peer toggle-checkbox" <?php echo $setting['setting_value'] == '1' ? 'checked' : ''; ?>>
                                                                    <div class="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                                                                </label>
                                                                <span class="ml-3 text-sm font-medium text-gray-700 toggle-status"><?php echo $setting['setting_value'] == '1' ? 'Aktif' : 'Pasif'; ?></span>
                                                            </div>
                                                            <?php
                                                            break;
                                                        
                                                        case 'number':
                                                            ?>
                                                             <input type="number" name="<?php echo $setting['setting_key']; ?>" id="<?php echo $setting['setting_key']; ?>" value="<?php echo $setting['setting_value']; ?>" <?php echo $input_min !== '' ? "min=\"{$input_min}\"" : ''; ?> <?php echo $input_max !== '' ? "max=\"{$input_max}\"" : ''; ?> <?php echo $input_step !== '' ? "step=\"{$input_step}\"" : ''; ?> class="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md">
                                                            <?php
                                                            break;
                                                            
                                                        case 'checkbox_group':
                                                            $selected_values = explode(',', $setting['setting_value']);
                                                            ?>
                                                            <div class="flex flex-wrap gap-4">
                                                                <?php foreach ($input_options as $option_key => $option_label): ?>
                                                                    <label class="inline-flex items-center">
                                                                        <input type="checkbox" name="<?php echo $setting['setting_key']; ?>[]" value="<?php echo $option_key; ?>" class="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50" <?php echo in_array($option_key, $selected_values) ? 'checked' : ''; ?>>
                                                                        <span class="ml-2"><?php echo $option_label; ?></span>
                                                                    </label>
                                                                <?php endforeach; ?>
                                                            </div>
                                                            <?php
                                                            break;
                                                            
                                                        case 'select':
                                                            ?>
                                                            <select name="<?php echo $setting['setting_key']; ?>" id="<?php echo $setting['setting_key']; ?>" class="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md">
                                                                <?php foreach ($input_options as $option_key => $option_label): ?>
                                                                    <option value="<?php echo $option_key; ?>" <?php echo $setting['setting_value'] === $option_key ? 'selected' : ''; ?>><?php echo $option_label; ?></option>
                                                                <?php endforeach; ?>
                                                            </select>
                                                            <?php
                                                            break;
                                                            
                                                        case 'textarea':
                                                            ?>
                                                            <textarea name="<?php echo $setting['setting_key']; ?>" id="<?php echo $setting['setting_key']; ?>" rows="3" class="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"><?php echo $setting['setting_value']; ?></textarea>
                                                            <?php
                                                            break;
                                                            
                                                        case 'time':
                                                            ?>
                                                            <input type="time" name="<?php echo $setting['setting_key']; ?>" id="<?php echo $setting['setting_key']; ?>" value="<?php echo $setting['setting_value']; ?>" class="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md">
                                                            <?php
                                                            break;
                                                            
                                                        default:
                                                            ?>
                                                            <input type="<?php echo $input_type; ?>" name="<?php echo $setting['setting_key']; ?>" id="<?php echo $setting['setting_key']; ?>" value="<?php echo $setting['setting_value']; ?>" class="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md">
                                                            <?php
                                                            break;
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                    
                                    <div class="mt-8 flex justify-end">
                                        <button type="submit" name="submit" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                            <svg class="mr-2 -ml-1 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                                            </svg>
                                            Ayarları Kaydet
                                        </button>
                                    </div>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript for handling checkbox groups and toggle switches -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Handle checkbox groups to combine values into a comma-separated string
        const form = document.querySelector('form');
        
        form.addEventListener('submit', function(e) {
            // Find all checkbox groups
            const checkboxGroups = document.querySelectorAll('input[type="checkbox"][name$="[]"]');
            const groupNames = new Set();
            
            // Get unique group names
            checkboxGroups.forEach(checkbox => {
                const groupName = checkbox.name.slice(0, -2); // Remove [] from the end
                groupNames.add(groupName);
            });
            
            // Process each group
            groupNames.forEach(groupName => {
                const checkboxes = document.querySelectorAll(`input[name="${groupName}[]"]:checked`);
                const values = Array.from(checkboxes).map(cb => cb.value);
                
                // Create a hidden input with the combined values
                const hiddenInput = document.createElement('input');
                hiddenInput.type = 'hidden';
                hiddenInput.name = groupName;
                hiddenInput.value = values.join(',');
                
                form.appendChild(hiddenInput);
            });
        });
        
        // Update toggle status text when checkbox is clicked
        const toggleCheckboxes = document.querySelectorAll('.toggle-checkbox');
        
        toggleCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const statusText = this.closest('.flex.items-center').querySelector('.toggle-status');
                if (statusText) {
                    statusText.textContent = this.checked ? 'Aktif' : 'Pasif';
                }
            });
        });
    });
</script>

<?php
// Include footer
include 'includes/footer.php';
?>