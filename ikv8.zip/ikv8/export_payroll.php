<?php
// Export Payroll to Excel
session_start();

// Load configuration
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';

// Set timezone
date_default_timezone_set(DEFAULT_TIMEZONE);

// Check if user is logged in and has admin or finance role
require_role(['admin', 'finance']);

// Check if period ID is provided
if (!isset($_GET['period_id']) || !is_numeric($_GET['period_id'])) {
    set_flash_message('payroll_error', 'Geçersiz bordro dönemi ID\'si.', 'danger');
    redirect('payroll_periods.php');
    exit;
}

$period_id = (int)$_GET['period_id'];

// Connect to database
$database = new Database();
$db = $database->connect();

// Get period details
$stmt = $db->prepare("SELECT * FROM payroll_periods WHERE id = :period_id");
$stmt->execute(['period_id' => $period_id]);
$period = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$period) {
    set_flash_message('payroll_error', 'Bordro dönemi bulunamadı.', 'danger');
    redirect('payroll_periods.php');
    exit;
}

// Get all employees with their payroll data for this period
$sql = "SELECT e.*, 
        d.name AS department_name,
        jt.title AS job_title,
        pr.id AS payroll_id,
        pr.base_salary,
        pr.gross_salary,
        pr.net_salary,
        pr.tax_amount,
        pr.insurance_amount,
        pr.allowances,
        pr.deductions,
        pr.payment_status,
        pr.payment_date,
        pr.notes
        FROM employees e
        LEFT JOIN departments d ON e.department_id = d.id
        LEFT JOIN job_titles jt ON e.job_title_id = jt.id
        LEFT JOIN payrolls pr ON e.id = pr.employee_id AND pr.period_id = :period_id
        WHERE (e.termination_date IS NULL OR e.termination_date > :period_start)
        AND pr.id IS NOT NULL
        ORDER BY e.last_name, e.first_name";

$stmt = $db->prepare($sql);
$stmt->execute([
    'period_id' => $period_id,
    'period_start' => $period['start_date']
]);
$employees = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Set headers for Excel download
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="bordro_' . $period['period_name'] . '.xls"');
header('Pragma: no-cache');
header('Expires: 0');

// Output Excel content
echo '<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Bordro: ' . htmlspecialchars($period['period_name']) . '</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #000000;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        .text-right {
            text-align: right;
        }
        .header {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .subheader {
            font-size: 14px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="header">Bordro Dönemi: ' . htmlspecialchars($period['period_name']) . '</div>
    <div class="subheader">Tarih Aralığı: ' . date('d.m.Y', strtotime($period['start_date'])) . ' - ' . date('d.m.Y', strtotime($period['end_date'])) . '</div>
    
    <table>
        <thead>
            <tr>
                <th>Sicil No</th>
                <th>Ad Soyad</th>
                <th>Departman</th>
                <th>Pozisyon</th>
                <th>Brüt Maaş</th>
                <th>Ek Ödemeler</th>
                <th>Vergi</th>
                <th>SGK</th>
                <th>Diğer Kesintiler</th>
                <th>Net Maaş</th>
                <th>Ödeme Durumu</th>
            </tr>
        </thead>
        <tbody>';

$total_gross = 0;
$total_net = 0;
$total_tax = 0;
$total_insurance = 0;

foreach ($employees as $employee) {
    $payment_status = '';
    switch ($employee['payment_status']) {
        case 'pending':
            $payment_status = 'Beklemede';
            break;
        case 'paid':
            $payment_status = 'Ödendi';
            break;
        case 'cancelled':
            $payment_status = 'İptal Edildi';
            break;
        default:
            $payment_status = $employee['payment_status'];
    }
    
    echo '<tr>
            <td>' . ($employee['employee_id'] ?? '') . '</td>
            <td>' . htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']) . '</td>
            <td>' . htmlspecialchars($employee['department_name'] ?? '') . '</td>
            <td>' . htmlspecialchars($employee['job_title'] ?? '') . '</td>
            <td class="text-right">' . number_format($employee['gross_salary'], 2, ',', '.') . '</td>
            <td class="text-right">' . number_format($employee['allowances'] ?? 0, 2, ',', '.') . '</td>
            <td class="text-right">' . number_format($employee['tax_amount'], 2, ',', '.') . '</td>
            <td class="text-right">' . number_format($employee['insurance_amount'], 2, ',', '.') . '</td>
            <td class="text-right">' . number_format($employee['deductions'] ?? 0, 2, ',', '.') . '</td>
            <td class="text-right">' . number_format($employee['net_salary'], 2, ',', '.') . '</td>
            <td>' . $payment_status . '</td>
          </tr>';
          
    $total_gross += $employee['gross_salary'];
    $total_net += $employee['net_salary'];
    $total_tax += $employee['tax_amount'];
    $total_insurance += $employee['insurance_amount'];
}

echo '</tbody>
        <tfoot>
            <tr>
                <th colspan="4">TOPLAM</th>
                <th class="text-right">' . number_format($total_gross, 2, ',', '.') . '</th>
                <th class="text-right"></th>
                <th class="text-right">' . number_format($total_tax, 2, ',', '.') . '</th>
                <th class="text-right">' . number_format($total_insurance, 2, ',', '.') . '</th>
                <th class="text-right"></th>
                <th class="text-right">' . number_format($total_net, 2, ',', '.') . '</th>
                <th></th>
            </tr>
        </tfoot>
    </table>
</body>
</html>';

exit;