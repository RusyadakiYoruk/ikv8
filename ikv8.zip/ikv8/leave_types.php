<?php
// leave_types.php
session_start();
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';

// Yetki kontrolü
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$database = new Database();
$db = $database->connect();

// Kullanıcı rolünü kontrol et
$stmt = $db->prepare("SELECT role FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user_role = $stmt->fetchColumn();

// Sadece admin erişebilir
if ($user_role !== 'admin') {
    header('Location: index.php');
    exit;
}

// İzin türlerini getir
$stmt = $db->query("
    SELECT 
        lt.*,
        (SELECT COUNT(*) FROM leave_requests WHERE leave_type_id = lt.id) as usage_count
    FROM leave_types lt 
    ORDER BY lt.name
");
$leave_types = $stmt->fetchAll(PDO::FETCH_ASSOC);

include 'includes/header.php';
?>

<div class="flex h-screen bg-gray-100">
    <?php include 'includes/sidebar.php'; ?>

    <div class="flex-1 overflow-auto ml-0 lg:ml-64 pt-16">
        <div class="p-6">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-semibold text-gray-900">İzin Türleri Yönetimi</h1>
                <button onclick="showAddModal()" 
                        class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded inline-flex items-center">
                    <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/>
                    </svg>
                    Yeni İzin Türü Ekle
                </button>
            </div>

            <!-- İzin Türleri Tablosu -->
            <div class="bg-white shadow-md rounded-lg overflow-hidden">
                <table id="leaveTypesTable" class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">İzin Türü</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Açıklama</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Varsayılan Gün</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ücret</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Onay Gerekli</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Durum</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Kullanım</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">İşlemler</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($leave_types as $type): ?>
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm font-medium text-gray-900">
                                        <?= htmlspecialchars($type['name']) ?>
                                    </div>
                                </td>
                                <td class="px-6 py-4">
                                    <div class="text-sm text-gray-900">
                                        <?= htmlspecialchars($type['description'] ?? '-') ?>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900">
                                        <?= $type['default_days'] ?> gün
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?= $type['is_paid'] ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' ?>">
                                        <?= $type['is_paid'] ? 'Ücretli' : 'Ücretsiz' ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?= $type['requires_approval'] ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800' ?>">
                                        <?= $type['requires_approval'] ? 'Evet' : 'Hayır' ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?= $type['is_active'] ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800' ?>">
                                        <?= $type['is_active'] ? 'Aktif' : 'Pasif' ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900">
                                        <?= $type['usage_count'] ?> kez
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                    <button onclick="showEditModal(<?= htmlspecialchars(json_encode($type)) ?>)" 
                                            class="text-blue-600 hover:text-blue-900 mr-3">
                                        Düzenle
                                    </button>
                                    <?php if ($type['usage_count'] == 0): ?>
                                        <button onclick="confirmDelete(<?= $type['id'] ?>, '<?= htmlspecialchars($type['name']) ?>')" 
                                                class="text-red-600 hover:text-red-900">
                                            Sil
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Ekleme Modalı -->
<div id="addModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">Yeni İzin Türü Ekle</h3>
            <form id="addForm" method="POST" action="process_leave_type.php">
                <input type="hidden" name="action" value="add">
                
                <div class="mb-4">
                    <label for="name" class="block text-sm font-medium text-gray-700 mb-1">İzin Türü Adı <span class="text-red-500">*</span></label>
                    <input type="text" id="name" name="name" required
                           class="shadow-sm focus:ring-blue-500 focus:border-blue-500 mt-1 block w-full sm:text-sm border border-gray-300 rounded-md">
                </div>

                <div class="mb-4">
                    <label for="description" class="block text-sm font-medium text-gray-700 mb-1">Açıklama</label>
                    <textarea id="description" name="description" rows="3"
                              class="shadow-sm focus:ring-blue-500 focus:border-blue-500 mt-1 block w-full sm:text-sm border border-gray-300 rounded-md"></textarea>
                </div>

                <div class="mb-4">
                    <label for="default_days" class="block text-sm font-medium text-gray-700 mb-1">Varsayılan Gün Sayısı <span class="text-red-500">*</span></label>
                    <input type="number" id="default_days" name="default_days" required min="0"
                           class="shadow-sm focus:ring-blue-500 focus:border-blue-500 mt-1 block w-full sm:text-sm border border-gray-300 rounded-md">
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Ücret Durumu</label>
                    <div class="mt-2">
                        <label class="inline-flex items-center">
                            <input type="radio" name="is_paid" value="1" checked
                                   class="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300">
                            <span class="ml-2">Ücretli</span>
                        </label>
                        <label class="inline-flex items-center ml-6">
                            <input type="radio" name="is_paid" value="0"
                                   class="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300">
                            <span class="ml-2">Ücretsiz</span>
                        </label>
                    </div>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Onay Gerekli mi?</label>
                    <div class="mt-2">
                        <label class="inline-flex items-center">
                            <input type="radio" name="requires_approval" value="1" checked
                                   class="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300">
                            <span class="ml-2">Evet</span>
                        </label>
                        <label class="inline-flex items-center ml-6">
                            <input type="radio" name="requires_approval" value="0"
                                   class="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300">
                            <span class="ml-2">Hayır</span>
                        </label>
                    </div>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Durum</label>
                    <div class="mt-2">
                        <label class="inline-flex items-center">
                            <input type="radio" name="is_active" value="1" checked
                                   class="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300">
                            <span class="ml-2">Aktif</span>
                        </label>
                        <label class="inline-flex items-center ml-6">
                            <input type="radio" name="is_active" value="0"
                                   class="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300">
                            <span class="ml-2">Pasif</span>
                        </label>
                    </div>
                </div>
                
                <div class="flex justify-end">
                    <button type="button" onclick="closeAddModal()" 
                            class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded mr-2">
                        İptal
                    </button>
                    <button type="submit" 
                            class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                        Ekle
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Düzenleme Modalı -->
<div id="editModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">İzin Türü Düzenle</h3>
            <form id="editForm" method="POST" action="process_leave_type.php">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="id" id="edit_id">
                
                <div class="mb-4">
                    <label for="edit_name" class="block text-sm font-medium text-gray-700 mb-1">İzin Türü Adı <span class="text-red-500">*</span></label>
                    <input type="text" id="edit_name" name="name" required
                           class="shadow-sm focus:ring-blue-500 focus:border-blue-500 mt-1 block w-full sm:text-sm border border-gray-300 rounded-md">
                </div>

                <div class="mb-4">
                    <label for="edit_description" class="block text-sm font-medium text-gray-700 mb-1">Açıklama</label>
                    <textarea id="edit_description" name="description" rows="3"
                              class="shadow-sm focus:ring-blue-500 focus:border-blue-500 mt-1 block w-full sm:text-sm border border-gray-300 rounded-md"></textarea>
                </div>

                <div class="mb-4">
                    <label for="edit_default_days" class="block text-sm font-medium text-gray-700 mb-1">Varsayılan Gün Sayısı <span class="text-red-500">*</span></label>
                    <input type="number" id="edit_default_days" name="default_days" required min="0"
                           class="shadow-sm focus:ring-blue-500 focus:border-blue-500 mt-1 block w-full sm:text-sm border border-gray-300 rounded-md">
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Ücret Durumu</label>
                    <div class="mt-2">
                        <label class="inline-flex items-center">
                            <input type="radio" name="edit_is_paid" value="1" id="edit_is_paid_1"
                                   class="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300">
                            <span class="ml-2">Ücretli</span>
                        </label>
                        <label class="inline-flex items-center ml-6">
                            <input type="radio" name="edit_is_paid" value="0" id="edit_is_paid_0"
                                   class="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300">
                            <span class="ml-2">Ücretsiz</span>
                        </label>
                    </div>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Onay Gerekli mi?</label>
                    <div class="mt-2">
                        <label class="inline-flex items-center">
                            <input type="radio" name="edit_requires_approval" value="1" id="edit_requires_approval_1"
                                   class="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300">
                            <span class="ml-2">Evet</span>
                        </label>
                        <label class="inline-flex items-center ml-6">
                            <input type="radio" name="edit_requires_approval" value="0" id="edit_requires_approval_0"
                                   class="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300">
                            <span class="ml-2">Hayır</span>
                        </label>
                    </div>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Durum</label>
                    <div class="mt-2">
                        <label class="inline-flex items-center">
                            <input type="radio" name="edit_is_active" value="1" id="edit_is_active_1"
                                   class="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300">
                            <span class="ml-2">Aktif</span>
                        </label>
                        <label class="inline-flex items-center ml-6">
                            <input type="radio" name="edit_is_active" value="0" id="edit_is_active_0"
                                   class="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300">
                            <span class="ml-2">Pasif</span>
                        </label>
                    </div>
                </div>
                
                <div class="flex justify-end">
                    <button type="button" onclick="closeEditModal()" 
                            class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded mr-2">
                        İptal
                    </button>
                    <button type="submit" 
                            class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                        Güncelle
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#leaveTypesTable').DataTable({
        language: {
            url: '//cdn.datatables.net/plug-ins/1.10.24/i18n/Turkish.json'
        },
        order: [[0, 'asc']],
        pageLength: 25
    });

    // Form submissions
    $('#addForm').on('submit', function(e) {
        e.preventDefault();
        $.ajax({
            url: $(this).attr('action'),
            type: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                const data = JSON.parse(response);
                if (data.success) {
                    alert('İzin türü başarıyla eklendi.');
                    window.location.reload();
                } else {
                    alert(data.message || 'Bir hata oluştu.');
                }
            },
            error: function() {
                alert('İşlem sırasında bir hata oluştu.');
            }
        });
    });

    $('#editForm').on('submit', function(e) {
        e.preventDefault();
        $.ajax({
            url: $(this).attr('action'),
            type: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                const data = JSON.parse(response);
                if (data.success) {
                    alert('İzin türü başarıyla güncellendi.');
                    window.location.reload();
                } else {
                    alert(data.message || 'Bir hata oluştu.');
                }
            },
            error: function() {
                alert('İşlem sırasında bir hata oluştu.');
            }
        });
    });
});

function showAddModal() {
    document.getElementById('addModal').classList.remove('hidden');
}

function closeAddModal() {
    document.getElementById('addModal').classList.add('hidden');
}

function showEditModal(type) {
    document.getElementById('edit_id').value = type.id;
    document.getElementById('edit_name').value = type.name;
    document.getElementById('edit_description').value = type.description || '';
    document.getElementById('edit_default_days').value = type.default_days;
    
    document.getElementById('edit_is_paid_' + (type.is_paid ? '1' : '0')).checked = true;
    document.getElementById('edit_requires_approval_' + (type.requires_approval ? '1' : '0')).checked = true;
    document.getElementById('edit_is_active_' + (type.is_active ? '1' : '0')).checked = true;
    
    document.getElementById('editModal').classList.remove('hidden');
}

function closeEditModal() {
    document.getElementById('editModal').classList.add('hidden');
}

function confirmDelete(id, name) {
    if (confirm(`"${name}" izin türünü silmek istediğinizden emin misiniz?`)) {
        $.ajax({
            url: 'process_leave_type.php',
            type: 'POST',
            data: {
                action: 'delete',
                id: id
            },
            success: function(response) {
                const data = JSON.parse(response);
                if (data.success) {
                    alert('İzin türü başarıyla silindi.');
                    window.location.reload();
                } else {
                    alert(data.message || 'Bir hata oluştu.');
                }
            },
            error: function() {
                alert('İşlem sırasında bir hata oluştu.');
            }
        });
    }
}
</script>

<?php include 'includes/footer.php'; ?>