<?php
// inventory.php
session_start();
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';

// Yetki kontrolü
require_role(['admin', 'manager']);

$db = new Database();
$conn = $db->connect();

// Stok ekleme/düzenleme/silme işlemleri
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $stmt = $conn->prepare("
                    INSERT INTO inventory_items (name, description, category, serial_number, quantity, unit, minimum_stock)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $_POST['name'],
                    $_POST['description'],
                    $_POST['category'],
                    $_POST['serial_number'],
                    $_POST['quantity'],
                    $_POST['unit'],
                    $_POST['minimum_stock']
                ]);
                break;

            case 'edit':
                $stmt = $conn->prepare("
                    UPDATE inventory_items 
                    SET name = ?, description = ?, category = ?, serial_number = ?, 
                        quantity = ?, unit = ?, minimum_stock = ?
                    WHERE id = ?
                ");
                $stmt->execute([
                    $_POST['name'],
                    $_POST['description'],
                    $_POST['category'],
                    $_POST['serial_number'],
                    $_POST['quantity'],
                    $_POST['unit'],
                    $_POST['minimum_stock'],
                    $_POST['id']
                ]);
                break;

            case 'delete':
                $stmt = $conn->prepare("DELETE FROM inventory_items WHERE id = ?");
                $stmt->execute([$_POST['id']]);
                break;
        }
        header('Location: inventory.php');
        exit;
    }
}

// Stok listesini al
$stmt = $conn->query("
    SELECT *, 
    CASE 
        WHEN quantity = 0 THEN 'out_of_stock'
        WHEN quantity <= minimum_stock THEN 'low_stock'
        ELSE 'available'
    END as stock_status
    FROM inventory_items 
    ORDER BY category, name
");
$inventory_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

include 'includes/header.php';
?>

<div class="flex h-screen bg-gray-100">
    <?php include 'includes/sidebar.php'; ?>

    <div class="flex-1 overflow-auto ml-0 lg:ml-64 pt-16">
        <div class="p-6">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-semibold text-gray-900">Depo Yönetimi</h1>
                <button onclick="showAddItemModal()" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                    Yeni Ürün Ekle
                </button>
            </div>

            <!-- Stok Tablosu -->
            <div class="bg-white shadow-md rounded-lg overflow-hidden">
                <table id="inventoryTable" class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ürün Adı</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Kategori</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Seri No</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Miktar</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Durum</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">İşlemler</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($inventory_items as $item): ?>
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm font-medium text-gray-900"><?= htmlspecialchars($item['name']) ?></div>
                                    <div class="text-sm text-gray-500"><?= htmlspecialchars($item['description']) ?></div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900"><?= htmlspecialchars($item['category']) ?></div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900"><?= htmlspecialchars($item['serial_number']) ?></div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900">
                                        <?= $item['quantity'] ?> <?= htmlspecialchars($item['unit']) ?>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                        <?php
                                        switch ($item['stock_status']) {
                                            case 'out_of_stock':
                                                echo 'bg-red-100 text-red-800';
                                                break;
                                            case 'low_stock':
                                                echo 'bg-yellow-100 text-yellow-800';
                                                break;
                                            default:
                                                echo 'bg-green-100 text-green-800';
                                        }
                                        ?>">
                                        <?php
                                        switch ($item['stock_status']) {
                                            case 'out_of_stock':
                                                echo 'Stokta Yok';
                                                break;
                                            case 'low_stock':
                                                echo 'Az Stok';
                                                break;
                                            default:
                                                echo 'Stokta Var';
                                        }
                                        ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                    <button onclick="showEditItemModal(<?= htmlspecialchars(json_encode($item)) ?>)" 
                                            class="text-indigo-600 hover:text-indigo-900 mr-3">Düzenle</button>
                                    <button onclick="showDeleteItemModal(<?= $item['id'] ?>)" 
                                            class="text-red-600 hover:text-red-900">Sil</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add/Edit Item Modal -->
<div id="itemModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg leading-6 font-medium text-gray-900" id="modalTitle">Yeni Ürün Ekle</h3>
            <form id="itemForm" class="mt-4">
                <input type="hidden" name="action" value="add">
                <input type="hidden" name="id" id="item_id">
                
                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="name">Ürün Adı</label>
                    <input type="text" name="name" id="name" required 
                           class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                </div>
                
                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="description">Açıklama</label>
                    <textarea name="description" id="description" 
                              class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"></textarea>
                </div>
                
                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="category">Kategori</label>
                    <input type="text" name="category" id="category" required 
                           class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                </div>
                
                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="serial_number">Seri No</label>
                    <input type="text" name="serial_number" id="serial_number" 
                           class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                </div>
                
                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div>
                        <label class="block text-gray-700 text-sm font-bold mb-2" for="quantity">Miktar</label>
                        <input type="number" name="quantity" id="quantity" required min="0" 
                               class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                    </div>
                    <div>
                        <label class="block text-gray-700 text-sm font-bold mb-2" for="unit">Birim</label>
                        <input type="text" name="unit" id="unit" required 
                               class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                    </div>
                </div>
                
                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="minimum_stock">Minimum Stok</label>
                    <input type="number" name="minimum_stock" id="minimum_stock" required min="0" 
                           class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                </div>
                
                <div class="flex items-center justify-end">
                    <button type="button" onclick="closeItemModal()" 
                            class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded mr-2">
                        İptal
                    </button>
                    <button type="submit" 
                            class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                        Kaydet
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div id="deleteModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg leading-6 font-medium text-gray-900">Ürünü Sil</h3>
            <div class="mt-2 px-7 py-3">
                <p class="text-sm text-gray-500">Bu ürünü silmek istediğinizden emin misiniz?</p>
            </div>
            <div class="flex items-center justify-end">
                <button onclick="closeDeleteModal()" 
                        class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded mr-2">
                    İptal
                </button>
                <form id="deleteForm" method="POST" class="inline">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" id="delete_item_id">
                    <button type="submit" 
                            class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                        Sil
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
// DataTables initialization
$(document).ready(function() {
    $('#inventoryTable').DataTable({
        language: {
            url: '//cdn.datatables.net/plug-ins/1.10.24/i18n/Turkish.json'
        }
    });
});

// Modal functions
function showAddItemModal() {
    document.getElementById('itemForm').reset();
    document.getElementById('modalTitle').textContent = 'Yeni Ürün Ekle';
    document.getElementById('itemForm').action.value = 'add';
    document.getElementById('itemModal').classList.remove('hidden');
}

function showEditItemModal(item) {
    document.getElementById('modalTitle').textContent = 'Ürün Düzenle';
    document.getElementById('itemForm').action.value = 'edit';
    document.getElementById('item_id').value = item.id;
    document.getElementById('name').value = item.name;
    document.getElementById('description').value = item.description;
    document.getElementById('category').value = item.category;
    document.getElementById('serial_number').value = item.serial_number;
    document.getElementById('quantity').value = item.quantity;
    document.getElementById('unit').value = item.unit;
    document.getElementById('minimum_stock').value = item.minimum_stock;
    document.getElementById('itemModal').classList.remove('hidden');
}

function closeItemModal() {
    document.getElementById('itemModal').classList.add('hidden');
}

function showDeleteItemModal(id) {
    document.getElementById('delete_item_id').value = id;
    document.getElementById('deleteModal').classList.remove('hidden');
}

function closeDeleteModal() {
    document.getElementById('deleteModal').classList.add('hidden');
}
</script>

<?php include 'includes/footer.php'; ?>