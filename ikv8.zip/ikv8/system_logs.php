<?php
// System Logs Page
session_start();

// Load configuration
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';

// Set timezone
date_default_timezone_set(DEFAULT_TIMEZONE);

// Connect to database
$database = new Database();
$db = $database->connect();

// Check if user is logged in and has admin role
require_role('admin');

// Get user information
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

// Get employee information if available
$employee = null;
$stmt = $db->prepare("SELECT * FROM employees WHERE user_id = :user_id LIMIT 1");
$stmt->execute(['user_id' => $user_id]);
$employee = $stmt->fetch(PDO::FETCH_ASSOC);

// Process log clearing if requested
if (isset($_POST['action']) && $_POST['action'] === 'clear_logs') {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
        set_flash_message('logs_error', 'Geçersiz form gönderimi. Lütfen tekrar deneyin.', 'danger');
    } else {
        try {
            // Begin transaction
            $db->beginTransaction();
            
            // Get the total number of logs before deletion
            $stmt = $db->query("SELECT COUNT(*) FROM activity_logs");
            $total_logs = $stmt->fetchColumn();
            
            // Clear all logs - WHERE koşulu olmadan tüm kayıtları siliyoruz
            $stmt = $db->prepare("DELETE FROM activity_logs");
            $stmt->execute();
            
            $affected_rows = $stmt->rowCount();
            
            // Log this action - Silme işleminin kendisini log olarak kaydediyoruz
            $log_description = "Tüm log kayıtları temizlendi. Toplam {$affected_rows} kayıt silindi.";
            $stmt = $db->prepare("INSERT INTO activity_logs (user_id, activity_type, description, ip_address) VALUES (:user_id, 'logs_clear', :description, :ip_address)");
            $stmt->execute([
                'user_id' => $user_id,
                'description' => $log_description,
                'ip_address' => $_SERVER['REMOTE_ADDR']
            ]);
            
            // Commit transaction
            $db->commit();
            
            set_flash_message('logs_success', "Tüm log kayıtları başarıyla temizlendi. Toplam {$affected_rows} kayıt silindi.", 'success');
        } catch (Exception $e) {
            // Rollback transaction on error
            $db->rollBack();
            set_flash_message('logs_error', 'Log kayıtları temizlenirken bir hata oluştu: ' . $e->getMessage(), 'danger');
            // Debug için hata mesajını loglayalım
            error_log('Log temizleme hatası: ' . $e->getMessage());
        }
    }
    
    // Redirect to prevent form resubmission
    redirect('system_logs.php');
    exit; // Yönlendirmeden sonra kodun çalışmasını durdur
}

// Get logs with pagination and filtering
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 20;
$offset = ($page - 1) * $per_page;

// Filters
$activity_type = isset($_GET['activity_type']) ? sanitize($_GET['activity_type']) : '';
$user_filter = isset($_GET['user']) ? (int)$_GET['user'] : 0;
$date_from = isset($_GET['date_from']) ? sanitize($_GET['date_from']) : '';
$date_to = isset($_GET['date_to']) ? sanitize($_GET['date_to']) : '';
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';

// Build query conditions
$conditions = [];
$params = [];

if (!empty($activity_type)) {
    $conditions[] = "activity_type = :activity_type";
    $params['activity_type'] = $activity_type;
}

if ($user_filter > 0) {
    $conditions[] = "user_id = :user_filter";
    $params['user_filter'] = $user_filter;
}

if (!empty($date_from)) {
    $conditions[] = "created_at >= :date_from";
    $params['date_from'] = $date_from . ' 00:00:00';
}

if (!empty($date_to)) {
    $conditions[] = "created_at <= :date_to";
    $params['date_to'] = $date_to . ' 23:59:59';
}

if (!empty($search)) {
    $conditions[] = "description LIKE :search";
    $params['search'] = "%{$search}%";
}

$where_clause = !empty($conditions) ? "WHERE " . implode(" AND ", $conditions) : "";

// Get total logs count
$count_sql = "SELECT COUNT(*) FROM activity_logs {$where_clause}";
$stmt = $db->prepare($count_sql);
if (!empty($params)) {
    $stmt->execute($params);
} else {
    $stmt->execute();
}
$total_logs = $stmt->fetchColumn();
$total_pages = ceil($total_logs / $per_page);

// Get logs for current page
$sql = "SELECT al.*, u.email as user_email 
        FROM activity_logs al 
        LEFT JOIN users u ON al.user_id = u.id 
        {$where_clause} 
        ORDER BY al.created_at DESC 
        LIMIT :offset, :per_page";
$stmt = $db->prepare($sql);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->bindValue(':per_page', $per_page, PDO::PARAM_INT);
foreach ($params as $key => $value) {
    $stmt->bindValue(':' . $key, $value);
}
$stmt->execute();
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get unique activity types for filter
$stmt = $db->query("SELECT DISTINCT activity_type FROM activity_logs ORDER BY activity_type");
$activity_types = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Get users for filter
$stmt = $db->query("SELECT DISTINCT u.id, u.email FROM users u INNER JOIN activity_logs al ON u.id = al.user_id ORDER BY u.email");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Include header
include 'includes/header.php';
?>

<div class="flex h-screen bg-gray-100">
    <!-- Sidebar -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- Main Content -->
    <div class="flex-1 overflow-auto ml-0 lg:ml-64 pt-16">
        <div class="py-6 px-8">
            <!-- Page Header -->
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold text-gray-800">Sistem Logları</h1>
                <nav class="flex" aria-label="Breadcrumb">
                    <ol class="inline-flex items-center space-x-1 md:space-x-3">
                        <li class="inline-flex items-center">
                            <a href="index.php" class="text-gray-700 hover:text-gray-900 inline-flex items-center">
                                <svg class="w-5 h-5 mr-2.5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"></path>
                                </svg>
                                Dashboard
                            </a>
                        </li>
                        <li>
                            <div class="flex items-center">
                                <svg class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <a href="system_logs.php" class="ml-1 text-gray-700 hover:text-gray-900 md:ml-2">Sistem Logları</a>
                            </div>
                        </li>
                    </ol>
                </nav>
            </div>
            
            <!-- Flash Messages -->
            <?php if (isset($_SESSION['flash_messages']['logs_success'])): ?>
                <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6" role="alert">
                    <p><?php echo $_SESSION['flash_messages']['logs_success']['message']; ?></p>
                </div>
                <?php unset($_SESSION['flash_messages']['logs_success']); ?>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['flash_messages']['logs_error'])): ?>
                <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                    <p><?php echo $_SESSION['flash_messages']['logs_error']['message']; ?></p>
                </div>
                <?php unset($_SESSION['flash_messages']['logs_error']); ?>
            <?php endif; ?>
            
            <!-- System Logs Section -->
            <div class="grid grid-cols-1 gap-6">
                <!-- Filters and Actions Card -->
                <div class="bg-white rounded-lg shadow">
                    <div class="border-b px-4 py-3 flex justify-between items-center">
                        <h3 class="text-lg font-semibold text-gray-700">Filtreler ve İşlemler</h3>
                        <button type="button" id="toggleFiltersForm" class="text-blue-600 hover:text-blue-800">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                            </svg>
                        </button>
                    </div>
                    <div id="filtersForm" class="p-6">
                        <form method="GET" action="system_logs.php" class="space-y-4">
                            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                                <!-- Activity Type Filter -->
                                <div>
                                    <label for="activity_type" class="block text-sm font-medium text-gray-700">İşlem Türü</label>
                                    <select name="activity_type" id="activity_type" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                        <option value="">Tümü</option>
                                        <?php foreach ($activity_types as $type): ?>
                                            <option value="<?php echo $type; ?>" <?php echo $activity_type === $type ? 'selected' : ''; ?>><?php echo ucfirst(str_replace('_', ' ', $type)); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <!-- User Filter -->
                                <div>
                                    <label for="user" class="block text-sm font-medium text-gray-700">Kullanıcı</label>
                                    <select name="user" id="user" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                        <option value="0">Tümü</option>
                                        <?php foreach ($users as $u): ?>
                                            <option value="<?php echo $u['id']; ?>" <?php echo $user_filter === (int)$u['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($u['email']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <!-- Date From Filter -->
                                <div>
                                    <label for="date_from" class="block text-sm font-medium text-gray-700">Başlangıç Tarihi</label>
                                    <input type="date" name="date_from" id="date_from" value="<?php echo $date_from; ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                
                                <!-- Date To Filter -->
                                <div>
                                    <label for="date_to" class="block text-sm font-medium text-gray-700">Bitiş Tarihi</label>
                                    <input type="date" name="date_to" id="date_to" value="<?php echo $date_to; ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                            </div>
                            
                            <!-- Search -->
                            <div>
                                <label for="search" class="block text-sm font-medium text-gray-700">Açıklama Ara</label>
                                <div class="mt-1 relative rounded-md shadow-sm">
                                <input type="text" name="search" id="search" value="<?php echo htmlspecialchars($search); ?>" class="focus:ring-blue-500 focus:border-blue-500 block w-full pr-10 sm:text-sm border-gray-300 rounded-md" placeholder="Açıklama içinde ara...">
                                    <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                                        <svg class="h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                            <path fill-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clip-rule="evenodd" />
                                        </svg>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Filter Buttons -->
                            <div class="flex items-center justify-between">
                                <div class="flex items-center space-x-2">
                                    <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"></path>
                                        </svg>
                                        Filtrele
                                    </button>
                                    <a href="system_logs.php" class="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
                                        </svg>
                                        Sıfırla
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Clear Logs Card -->
                <div class="bg-white rounded-lg shadow">
                    <div class="border-b px-4 py-3 flex justify-between items-center">
                        <h3 class="text-lg font-semibold text-gray-700">Log Temizleme</h3>
                        <button type="button" id="toggleClearLogsForm" class="text-blue-600 hover:text-blue-800">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                            </svg>
                        </button>
                    </div>
                    <div id="clearLogsForm" class="p-6">
                        <form method="POST" action="system_logs.php" class="space-y-4" onsubmit="return confirm('Belirtilen günden eski log kayıtları silinecektir. Devam etmek istiyor musunuz?');">
                            <input type="hidden" name="action" value="clear_logs">
                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                            
                            <div>
                                <label for="days" class="block text-sm font-medium text-gray-700">Kaç Günden Eski Loglar Temizlensin?</label>
                                <select name="days" id="days" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                    <option value="30">30 Gün</option>
                                    <option value="60">60 Gün</option>
                                    <option value="90">90 Gün</option>
                                    <option value="180">180 Gün</option>
                                    <option value="365">365 Gün</option>
                                </select>
                            </div>
                            
                            <div>
                                <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500">
                                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                    </svg>
                                    Logları Temizle
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Logs Table Card -->
                <div class="bg-white rounded-lg shadow overflow-hidden">
                    <div class="border-b px-4 py-3">
                        <h3 class="text-lg font-semibold text-gray-700">Sistem Logları</h3>
                        <p class="text-sm text-gray-500 mt-1">Toplam <?php echo $total_logs; ?> kayıt bulundu.</p>
                    </div>
                    
                    <?php if (count($logs) > 0): ?>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tarih</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Kullanıcı</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">İşlem Türü</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Açıklama</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">IP Adresi</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    <?php foreach ($logs as $log): ?>
                                        <tr>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo $log['id']; ?></td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo date('d.m.Y H:i:s', strtotime($log['created_at'])); ?></td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo htmlspecialchars($log['user_email'] ?? 'Bilinmiyor'); ?></td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                                    <?php 
                                                    $type_class = 'bg-gray-100 text-gray-800';
                                                    switch ($log['activity_type']) {
                                                        case 'login':
                                                        case 'login_success':
                                                            $type_class = 'bg-green-100 text-green-800';
                                                            break;
                                                        case 'login_failed':
                                                        case 'error':
                                                            $type_class = 'bg-red-100 text-red-800';
                                                            break;
                                                        case 'logout':
                                                            $type_class = 'bg-yellow-100 text-yellow-800';
                                                            break;
                                                        case 'create':
                                                        case 'add':
                                                            $type_class = 'bg-blue-100 text-blue-800';
                                                            break;
                                                        case 'update':
                                                        case 'edit':
                                                            $type_class = 'bg-indigo-100 text-indigo-800';
                                                            break;
                                                        case 'delete':
                                                            $type_class = 'bg-pink-100 text-pink-800';
                                                            break;
                                                    }
                                                    echo $type_class;
                                                    ?>">
                                                    <?php echo ucfirst(str_replace('_', ' ', $log['activity_type'])); ?>
                                                </span>
                                            </td>
                                            <td class="px-6 py-4 text-sm text-gray-500"><?php echo htmlspecialchars($log['description']); ?></td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo htmlspecialchars($log['ip_address']); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <!-- Pagination -->
                        <?php if ($total_pages > 1): ?>
                            <div class="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200 sm:px-6">
                                <div class="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
                                    <div>
                                        <p class="text-sm text-gray-700">
                                            <span class="font-medium"><?php echo ($offset + 1); ?></span> - 
                                            <span class="font-medium"><?php echo min($offset + $per_page, $total_logs); ?></span> / 
                                            <span class="font-medium"><?php echo $total_logs; ?></span> kayıt gösteriliyor
                                        </p>
                                    </div>
                                    <div>
                                        <nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                                            <?php
                                            // Build pagination query string
                                            $query_params = $_GET;
                                            
                                            // Previous page link
                                            if ($page > 1) {
                                                $query_params['page'] = $page - 1;
                                                $prev_link = 'system_logs.php?' . http_build_query($query_params);
                                                echo '<a href="' . $prev_link . '" class="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">';
                                                echo '<span class="sr-only">Önceki</span>';
                                                echo '<svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">';
                                                echo '<path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />';
                                                echo '</svg>';
                                                echo '</a>';
                                            } else {
                                                echo '<span class="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-gray-100 text-sm font-medium text-gray-400">';
                                                echo '<span class="sr-only">Önceki</span>';
                                                echo '<svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">';
                                                echo '<path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />';
                                                echo '</svg>';
                                                echo '</span>';
                                            }
                                            
                                            // Page numbers
                                            $start_page = max(1, $page - 2);
                                            $end_page = min($total_pages, $page + 2);
                                            
                                            for ($i = $start_page; $i <= $end_page; $i++) {
                                                $query_params['page'] = $i;
                                                $page_link = 'system_logs.php?' . http_build_query($query_params);
                                                
                                                if ($i == $page) {
                                                    echo '<span aria-current="page" class="relative inline-flex items-center px-4 py-2 border border-blue-500 bg-blue-50 text-sm font-medium text-blue-600">';
                                                    echo $i;
                                                    echo '</span>';
                                                } else {
                                                    echo '<a href="' . $page_link . '" class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50">';
                                                    echo $i;
                                                    echo '</a>';
                                                }
                                            }
                                            
                                            // Next page link
                                            if ($page < $total_pages) {
                                                $query_params['page'] = $page + 1;
                                                $next_link = 'system_logs.php?' . http_build_query($query_params);
                                                echo '<a href="' . $next_link . '" class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">';
                                                echo '<span class="sr-only">Sonraki</span>';
                                                echo '<svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">';
                                                echo '<path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" />';
                                                echo '</svg>';
                                                echo '</a>';
                                            } else {
                                                echo '<span class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-gray-100 text-sm font-medium text-gray-400">';
                                                echo '<span class="sr-only">Sonraki</span>';
                                                echo '<svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">';
                                                echo '<path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" />';
                                                echo '</svg>';
                                                echo '</span>';
                                            }
                                            ?>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="p-6 text-center">
                            <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                            </svg>
                            <h3 class="mt-2 text-sm font-medium text-gray-900">Log Kaydı Bulunamadı</h3>
                            <p class="mt-1 text-sm text-gray-500">Belirtilen kriterlere uygun log kaydı bulunmamaktadır.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript for toggle functionality -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Toggle filters form
        const toggleFiltersBtn = document.getElementById('toggleFiltersForm');
        const filtersForm = document.getElementById('filtersForm');
        
        toggleFiltersBtn.addEventListener('click', function() {
            if (filtersForm.classList.contains('hidden')) {
                filtersForm.classList.remove('hidden');
                toggleFiltersBtn.innerHTML = '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 15l7-7 7 7"></path></svg>';
            } else {
                filtersForm.classList.add('hidden');
                toggleFiltersBtn.innerHTML = '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>';
            }
        });
        
        // Toggle clear logs form
        const toggleClearLogsBtn = document.getElementById('toggleClearLogsForm');
        const clearLogsForm = document.getElementById('clearLogsForm');
        
        toggleClearLogsBtn.addEventListener('click', function() {
            if (clearLogsForm.classList.contains('hidden')) {
                clearLogsForm.classList.remove('hidden');
                toggleClearLogsBtn.innerHTML = '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 15l7-7 7 7"></path></svg>';
            } else {
                clearLogsForm.classList.add('hidden');
                toggleClearLogsBtn.innerHTML = '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>';
            }
        });
    });
</script>

<?php include 'includes/footer.php'; ?>