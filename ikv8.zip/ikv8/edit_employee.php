<?php
// Edit Employee Page
session_start();

// Load configuration
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';

// Set timezone
date_default_timezone_set(DEFAULT_TIMEZONE);

// Connect to database
$database = new Database();
$db = $database->connect();

// Check if user is logged in and has admin or manager role
require_role(['admin', 'manager']);

// Get user information
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

// Check if employee ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    set_flash_message('employee_error', 'Çalışan ID\'si belirtilmedi.', 'danger');
    redirect('employees.php');
    exit;
}

$employee_id = (int)$_GET['id'];

// Get employee details
$stmt = $db->prepare("
    SELECT e.*, 
           d.name as department_name, 
           b.name as branch_name, 
           jt.title as job_title,
           m.first_name as manager_first_name,
           m.last_name as manager_last_name,
           u.email
    FROM employees e
    LEFT JOIN departments d ON e.department_id = d.id
    LEFT JOIN branches b ON e.branch_id = b.id
    LEFT JOIN job_titles jt ON e.job_title_id = jt.id
    LEFT JOIN employees m ON e.manager_id = m.id
    LEFT JOIN users u ON e.user_id = u.id
    WHERE e.id = :employee_id
");
$stmt->execute(['employee_id' => $employee_id]);
$employee = $stmt->fetch(PDO::FETCH_ASSOC);

// Check if employee exists
if (!$employee) {
    set_flash_message('employee_error', 'Çalışan bulunamadı.', 'danger');
    redirect('employees.php');
    exit;
}

// Get departments for dropdown
$stmt = $db->query("SELECT * FROM departments ORDER BY name");
$departments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get branches for dropdown
$stmt = $db->query("SELECT * FROM branches ORDER BY name");
$branches = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get job titles for dropdown
$stmt = $db->query("SELECT * FROM job_titles ORDER BY title");
$job_titles = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get managers for dropdown
// Yönetici listesini al
$managers_query = "
    SELECT 
        e.id,
        e.first_name,
        e.last_name,
        jt.title as job_title,
        d.name as department_name
    FROM employees e
    INNER JOIN job_titles jt ON e.job_title_id = jt.id
    INNER JOIN departments d ON e.department_id = d.id
    WHERE e.termination_date IS NULL
    AND e.id != :current_employee_id
    ORDER BY d.name, e.first_name, e.last_name
";

$stmt = $db->prepare($managers_query);
$stmt->execute(['current_employee_id' => $employee_id]);
$managers = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
        set_flash_message('employee_error', 'Geçersiz form gönderimi. Lütfen tekrar deneyin.', 'danger');
    } else {
        try {
            // Begin transaction
            $db->beginTransaction();
            
            // Prepare update query
            $sql = "UPDATE employees SET 
                    first_name = ?,
                    last_name = ?,
                    middle_name = ?,
                    birth_date = ?,
                    gender = ?,
                    nationality = ?,
                    passport_number = ?,
                    passport_expiry = ?,
                    address = ?,
                    phone = ?,
                    emergency_contact_name = ?,
                    emergency_contact_phone = ?,
                    department_id = ?,
                    branch_id = ?,
                    job_title_id = ?,
                    manager_id = ?,
                    employment_type = ?,
                    salary_type = ?,
                    salary_amount = ?,
                    bank_account = ?,
                    tax_id = ?,
                    social_security_number = ?,
                    notes = ?
                    WHERE id = ?";
        
            // Format salary amount
            $salary_amount = !empty($_POST['salary_amount']) ? 
                str_replace(['.', ','], ['', '.'], $_POST['salary_amount']) : null;
        
            // Prepare parameters array
            $params = [
                sanitize($_POST['first_name']),
                sanitize($_POST['last_name']),
                !empty($_POST['middle_name']) ? sanitize($_POST['middle_name']) : null,
                !empty($_POST['birth_date']) ? sanitize($_POST['birth_date']) : null,
                !empty($_POST['gender']) ? sanitize($_POST['gender']) : null,
                !empty($_POST['nationality']) ? sanitize($_POST['nationality']) : null,
                !empty($_POST['passport_number']) ? sanitize($_POST['passport_number']) : null,
                !empty($_POST['passport_expiry']) ? sanitize($_POST['passport_expiry']) : null,
                !empty($_POST['address']) ? sanitize($_POST['address']) : null,
                !empty($_POST['phone']) ? sanitize($_POST['phone']) : null,
                !empty($_POST['emergency_contact_name']) ? sanitize($_POST['emergency_contact_name']) : null,
                !empty($_POST['emergency_contact_phone']) ? sanitize($_POST['emergency_contact_phone']) : null,
                !empty($_POST['department_id']) ? (int)$_POST['department_id'] : null,
                !empty($_POST['branch_id']) ? (int)$_POST['branch_id'] : null,
                !empty($_POST['job_title_id']) ? (int)$_POST['job_title_id'] : null,
                !empty($_POST['manager_id']) ? (int)$_POST['manager_id'] : null,
                sanitize($_POST['employment_type']),
                sanitize($_POST['salary_type']),
                $salary_amount,
                !empty($_POST['bank_account']) ? sanitize($_POST['bank_account']) : null,
                !empty($_POST['tax_id']) ? sanitize($_POST['tax_id']) : null,
                !empty($_POST['social_security_number']) ? sanitize($_POST['social_security_number']) : null,
                !empty($_POST['notes']) ? sanitize($_POST['notes']) : null,
                $employee_id // WHERE clause parameter
            ];
        
            // Execute update query
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
        
            // Update salary currency if different from default
            if (!empty($_POST['salary_currency']) && $_POST['salary_currency'] !== 'TRY') {
                $stmt = $db->prepare("
                    INSERT INTO employee_meta (employee_id, meta_key, meta_value) 
                    VALUES (?, 'salary_currency', ?)
                    ON DUPLICATE KEY UPDATE meta_value = ?
                ");
                $stmt->execute([$employee_id, $_POST['salary_currency'], $_POST['salary_currency']]);
            }
        
            // Update user email if provided and changed
            if (!empty($_POST['email']) && $employee['email'] !== $_POST['email']) {
                if ($employee['user_id']) {
                    $stmt = $db->prepare("UPDATE users SET email = ? WHERE id = ?");
                    $stmt->execute([$_POST['email'], $employee['user_id']]);
                }
            }
        
            // Log the action
            $stmt = $db->prepare("INSERT INTO activity_logs (user_id, activity_type, description, ip_address) VALUES (?, ?, ?, ?)");
            $stmt->execute([
                $user_id,
                'employee_update',
                "Çalışan güncellendi: {$_POST['first_name']} {$_POST['last_name']} (ID: {$employee_id})",
                $_SERVER['REMOTE_ADDR']
            ]);
        
            // Commit transaction
            $db->commit();
        
            set_flash_message('employee_success', "Çalışan başarıyla güncellendi: {$_POST['first_name']} {$_POST['last_name']}", 'success');
            redirect("view_employee.php?id={$employee_id}");
            exit;
        
        } catch (Exception $e) {
            // Rollback transaction on error
            $db->rollBack();
            set_flash_message('employee_error', 'Çalışan güncellenirken bir hata oluştu: ' . $e->getMessage(), 'danger');
        }
    }
}

// Include header
include 'includes/header.php';
?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const departmentSelect = document.getElementById('department_id');
    const managerSelect = document.getElementById('manager_id');
    
    // Departman değiştiğinde yönetici listesini filtrele
    departmentSelect.addEventListener('change', function() {
        const selectedDepartment = this.options[this.selectedIndex].text;
        const managerOptions = managerSelect.options;
        
        // "Seçiniz" seçeneğini her zaman göster
        managerSelect.value = '';
        
        // Tüm seçenekleri gözden geçir
        for (let i = 1; i < managerOptions.length; i++) {
            const option = managerOptions[i];
            const managerDepartment = option.getAttribute('data-department');
            
            // Seçili departmana ait yöneticileri göster, diğerlerini gizle
            if (selectedDepartment === managerDepartment || selectedDepartment === '') {
                option.style.display = '';
            } else {
                option.style.display = 'none';
            }
        }
    });
});
</script>
<div class="flex h-screen bg-gray-100">
    <!-- Sidebar -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- Main Content -->
    <div class="flex-1 overflow-auto ml-0 lg:ml-64 pt-16">
        <div class="py-6 px-8">
            <!-- Page Header -->
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold text-gray-800">Çalışan Düzenle</h1>
                <div class="flex space-x-2">
                    <a href="view_employee.php?id=<?php echo $employee_id; ?>" class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                        <svg class="mr-2 -ml-1 h-5 w-5 text-gray-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                        </svg>
                        Çalışan Profiline Dön
                    </a>
                </div>
            </div>
            
            <!-- Flash Messages -->
            <?php if (isset($_SESSION['flash_messages']['employee_error'])): ?>
                <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                    <p><?php echo $_SESSION['flash_messages']['employee_error']['message']; ?></p>
                </div>
                <?php unset($_SESSION['flash_messages']['employee_error']); ?>
            <?php endif; ?>
            
            <!-- Employee Form -->
            <div class="bg-white rounded-lg shadow">
                <div class="border-b px-4 py-3">
                    <h3 class="text-lg font-semibold text-gray-700">Çalışan Bilgileri</h3>
                </div>
                <div class="p-6">
                    <form method="POST" action="edit_employee.php?id=<?php echo $employee_id; ?>">
                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                        
                        <!-- Personal Information Section -->
                        <div class="mb-8">
                            <h4 class="text-md font-medium text-gray-700 mb-4 pb-2 border-b">Kişisel Bilgiler</h4>
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <!-- First Name -->
                                <div>
                                    <label for="first_name" class="block text-sm font-medium text-gray-700">Ad <span class="text-red-500">*</span></label>
                                    <input type="text" name="first_name" id="first_name" value="<?php echo htmlspecialchars($employee['first_name']); ?>" required class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                
                                <!-- Middle Name -->
                                <div>
                                    <label for="middle_name" class="block text-sm font-medium text-gray-700">İkinci Ad</label>
                                    <input type="text" name="middle_name" id="middle_name" value="<?php echo htmlspecialchars($employee['middle_name'] ?? ''); ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                
                                <!-- Last Name -->
                                <div>
                                    <label for="last_name" class="block text-sm font-medium text-gray-700">Soyad <span class="text-red-500">*</span></label>
                                    <input type="text" name="last_name" id="last_name" value="<?php echo htmlspecialchars($employee['last_name']); ?>" required class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                
                                <!-- Email -->
                                <div>
                                    <label for="email" class="block text-sm font-medium text-gray-700">E-posta</label>
                                    <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($employee['email'] ?? ''); ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                
                                <!-- Birth Date -->
                                <div>
                                    <label for="birth_date" class="block text-sm font-medium text-gray-700">Doğum Tarihi</label>
                                    <input type="date" name="birth_date" id="birth_date" value="<?php echo $employee['birth_date']; ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                
                                <!-- Gender -->
                                <div>
                                    <label for="gender" class="block text-sm font-medium text-gray-700">Cinsiyet</label>
                                    <select name="gender" id="gender" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                        <option value="">Seçiniz</option>
                                        <option value="male" <?php echo $employee['gender'] === 'male' ? 'selected' : ''; ?>>Erkek</option>
                                        <option value="female" <?php echo $employee['gender'] === 'female' ? 'selected' : ''; ?>>Kadın</option>
                                        <option value="other" <?php echo $employee['gender'] === 'other' ? 'selected' : ''; ?>>Diğer</option>
                                    </select>
                                </div>
                                
                                <!-- Nationality -->
                                <div>
                                    <label for="nationality" class="block text-sm font-medium text-gray-700">Uyruk</label>
                                    <input type="text" name="nationality" id="nationality" value="<?php echo htmlspecialchars($employee['nationality'] ?? ''); ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                
                                <!-- Passport Number -->
                                <div>
                                    <label for="passport_number" class="block text-sm font-medium text-gray-700">Pasaport Numarası</label>
                                    <input type="text" name="passport_number" id="passport_number" value="<?php echo htmlspecialchars($employee['passport_number'] ?? ''); ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                
                                <!-- Passport Expiry -->
                                <div>
                                    <label for="passport_expiry" class="block text-sm font-medium text-gray-700">Pasaport Geçerlilik Tarihi</label>
                                    <input type="date" name="passport_expiry" id="passport_expiry" value="<?php echo $employee['passport_expiry']; ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                            </div>
                        </div>
                        
                        <!-- Contact Information Section -->
                        <div class="mb-8">
                            <h4 class="text-md font-medium text-gray-700 mb-4 pb-2 border-b">İletişim Bilgileri</h4>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <!-- Phone -->
                                <div>
                                    <label for="phone" class="block text-sm font-medium text-gray-700">Telefon</label>
                                    <input type="tel" name="phone" id="phone" value="<?php echo htmlspecialchars($employee['phone'] ?? ''); ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                
                                <!-- Address -->
                                <div class="md:col-span-2">
                                    <label for="address" class="block text-sm font-medium text-gray-700">Adres</label>
                                    <textarea name="address" id="address" rows="3" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"><?php echo htmlspecialchars($employee['address'] ?? ''); ?></textarea>
                                </div>
                                
                                <!-- Emergency Contact Name -->
                                <div>
                                    <label for="emergency_contact_name" class="block text-sm font-medium text-gray-700">Acil Durumda Aranacak Kişi</label>
                                    <input type="text" name="emergency_contact_name" id="emergency_contact_name" value="<?php echo htmlspecialchars($employee['emergency_contact_name'] ?? ''); ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                
                                <!-- Emergency Contact Phone -->
                                <div>
                                    <label for="emergency_contact_phone" class="block text-sm font-medium text-gray-700">Acil Durumda Aranacak Telefon</label>
                                    <input type="tel" name="emergency_contact_phone" id="emergency_contact_phone" value="<?php echo htmlspecialchars($employee['emergency_contact_phone'] ?? ''); ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                            </div>
                        </div>
                        
                        <!-- Employment Information Section -->
                        <div class="mb-8">
                            <h4 class="text-md font-medium text-gray-700 mb-4 pb-2 border-b">İş Bilgileri</h4>
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <!-- Department -->
                                <div>
                                    <label for="department_id" class="block text-sm font-medium text-gray-700">Departman <span class="text-red-500">*</span></label>
                                    <select name="department_id" id="department_id" required class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                        <option value="">Seçiniz</option>
                                        <?php foreach ($departments as $dept): ?>
                                            <option value="<?php echo $dept['id']; ?>" <?php echo $employee['department_id'] == $dept['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($dept['name']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <!-- Branch -->
                                <div>
                                    <label for="branch_id" class="block text-sm font-medium text-gray-700">Şube</label>
                                    <select name="branch_id" id="branch_id" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                        <option value="">Seçiniz</option>
                                        <?php foreach ($branches as $branch): ?>
                                            <option value="<?php echo $branch['id']; ?>" <?php echo $employee['branch_id'] == $branch['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($branch['name']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <!-- Job Title -->
                                <div>
                                    <label for="job_title_id" class="block text-sm font-medium text-gray-700">İş Unvanı <span class="text-red-500">*</span></label>
                                    <select name="job_title_id" id="job_title_id" required class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                        <option value="">Seçiniz</option>
                                        <?php foreach ($job_titles as $title): ?>
                                            <option value="<?php echo $title['id']; ?>" <?php echo $employee['job_title_id'] == $title['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($title['title']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <!-- Manager -->
                                <div class="form-group">
    <label for="manager_id" class="block text-sm font-medium text-gray-700">Yönetici</label>
    <select name="manager_id" id="manager_id" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
        <option value="">Yönetici Seçiniz</option>
        <?php foreach ($managers as $manager): ?>
            <option value="<?php echo $manager['id']; ?>" 
                    data-department="<?php echo htmlspecialchars($manager['department_name']); ?>"
                    <?php echo ($employee['manager_id'] == $manager['id']) ? 'selected' : ''; ?>>
                <?php echo htmlspecialchars($manager['first_name'] . ' ' . $manager['last_name'] . 
                      ' (' . $manager['job_title'] . ' - ' . $manager['department_name'] . ')'); ?>
            </option>
        <?php endforeach; ?>
    </select>
</div>
                                
                                <!-- Employment Type -->
                                <div>
                                    <label for="employment_type" class="block text-sm font-medium text-gray-700">İstihdam Türü</label>
                                    <select name="employment_type" id="employment_type" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                        <option value="full-time" <?php echo $employee['employment_type'] === 'full-time' ? 'selected' : ''; ?>>Tam Zamanlı</option>
                                        <option value="part-time" <?php echo $employee['employment_type'] === 'part-time' ? 'selected' : ''; ?>>Yarı Zamanlı</option>
                                        <option value="contract" <?php echo $employee['employment_type'] === 'contract' ? 'selected' : ''; ?>>Sözleşmeli</option>
                                        <option value="temporary" <?php echo $employee['employment_type'] === 'temporary' ? 'selected' : ''; ?>>Geçici</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Salary Information Section -->
                        <div class="mb-8">
                            <h4 class="text-md font-medium text-gray-700 mb-4 pb-2 border-b">Maaş Bilgileri</h4>
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <!-- Salary Type -->
                                <div>
                                    <label for="salary_type" class="block text-sm font-medium text-gray-700">Maaş Türü</label>
                                    <select name="salary_type" id="salary_type" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                        <option value="monthly" <?php echo $employee['salary_type'] === 'monthly' ? 'selected' : ''; ?>>Aylık</option>
                                        <option value="hourly" <?php echo $employee['salary_type'] === 'hourly' ? 'selected' : ''; ?>>Saatlik</option>
                                    </select>
                                </div>
                                
                                <!-- Salary Amount -->
                                <div>
                                    <label for="salary_amount" class="block text-sm font-medium text-gray-700">Maaş Tutarı</label>
                                    <input type="text" name="salary_amount" id="salary_amount" value="<?php echo number_format($employee['salary_amount'], 2, ',', '.'); ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                
                                <!-- Salary Currency -->
                                <div>
                                    <label for="salary_currency" class="block text-sm font-medium text-gray-700">Para Birimi</label>
                                    <select name="salary_currency" id="salary_currency" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                        <?php
                                        // Get current currency
                                        $stmt = $db->prepare("SELECT meta_value FROM employee_meta WHERE employee_id = :employee_id AND meta_key = 'salary_currency' LIMIT 1");
                                        $stmt->execute(['employee_id' => $employee_id]);
                                        $current_currency = $stmt->fetchColumn() ?: 'TRY';
                                        ?>
                                        <option value="TRY" <?php echo $current_currency === 'TRY' ? 'selected' : ''; ?>>Türk Lirası (₺)</option>
                                        <option value="USD" <?php echo $current_currency === 'USD' ? 'selected' : ''; ?>>Amerikan Doları ($)</option>
                                        <option value="EUR" <?php echo $current_currency === 'EUR' ? 'selected' : ''; ?>>Euro (€)</option>
                                        <option value="GBP" <?php echo $current_currency === 'GBP' ? 'selected' : ''; ?>>İngiliz Sterlini (£)</option>
                                        <option value="RUB" <?php echo $current_currency === 'RUB' ? 'selected' : ''; ?>>Rus Rublesi (₽)</option>
                                    </select>
                                </div>
                                
                                <!-- Bank Account -->
                                <div>
                                    <label for="bank_account" class="block text-sm font-medium text-gray-700">Banka Hesap Numarası</label>
                                    <input type="text" name="bank_account" id="bank_account" value="<?php echo htmlspecialchars($employee['bank_account'] ?? ''); ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                
                                <!-- Tax ID -->
                                <div>
                                    <label for="tax_id" class="block text-sm font-medium text-gray-700">Vergi Numarası</label>
                                    <input type="text" name="tax_id" id="tax_id" value="<?php echo htmlspecialchars($employee['tax_id'] ?? ''); ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                
                                <!-- Social Security Number -->
                                <div>
                                <label for="social_security_number" class="block text-sm font-medium text-gray-700">Sosyal Güvenlik Numarası</label>
                                    <input type="text" name="social_security_number" id="social_security_number" value="<?php echo htmlspecialchars($employee['social_security_number'] ?? ''); ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                            </div>
                        </div>
                        
                        <!-- Additional Information Section -->
                        <div class="mb-8">
                            <h4 class="text-md font-medium text-gray-700 mb-4 pb-2 border-b">Ek Bilgiler</h4>
                            <div class="grid grid-cols-1 gap-6">
                                <!-- Notes -->
                                <div>
                                    <label for="notes" class="block text-sm font-medium text-gray-700">Notlar</label>
                                    <textarea name="notes" id="notes" rows="4" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"><?php echo htmlspecialchars($employee['notes'] ?? ''); ?></textarea>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Form Actions -->
                        <div class="flex justify-end space-x-3">
                            <a href="view_employee.php?id=<?php echo $employee_id; ?>" class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                İptal
                            </a>
                            <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                <svg class="mr-2 -ml-1 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                                </svg>
                                Değişiklikleri Kaydet
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript for form handling -->
<script>
    // Format salary amount with thousand separators
    document.getElementById('salary_amount').addEventListener('input', function(e) {
        let value = e.target.value.replace(/[^\d,]/g, '').replace(',', '.');
        if (value) {
            value = parseFloat(value).toLocaleString('tr-TR', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
            e.target.value = value;
        }
    });
    
    // Form validation before submit
    document.querySelector('form').addEventListener('submit', function(e) {
        let firstName = document.getElementById('first_name').value.trim();
        let lastName = document.getElementById('last_name').value.trim();
        let departmentId = document.getElementById('department_id').value;
        let jobTitleId = document.getElementById('job_title_id').value;
        
        if (!firstName || !lastName || !departmentId || !jobTitleId) {
            e.preventDefault();
            alert('Lütfen zorunlu alanları doldurun.');
        }
    });
</script>

<?php
// Include footer
include 'includes/footer.php';
?>
