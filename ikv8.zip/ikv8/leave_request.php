<?php
// leave_request.php
session_start();

// Load configuration
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Connect to database
$database = new Database();
$db = $database->connect();

// Get user role
$stmt = $db->prepare("SELECT role FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user_role = $stmt->fetchColumn();

// Check if admin or manager
$is_admin = in_array($user_role, ['admin', 'manager']);

// Get employee ID from URL if admin/manager
$selected_employee_id = null;
if ($is_admin && isset($_GET['employee_id'])) {
    $selected_employee_id = (int)$_GET['employee_id'];
}

// Get current user's employee info
$stmt = $db->prepare("
    SELECT e.*, d.name as department_name, d.id as department_id, jt.title as job_title 
    FROM employees e
    LEFT JOIN departments d ON e.department_id = d.id
    LEFT JOIN job_titles jt ON e.job_title_id = jt.id
    WHERE e.user_id = ?
");
$stmt->execute([$_SESSION['user_id']]);
$current_employee = $stmt->fetch(PDO::FETCH_ASSOC);

// If admin/manager and employee_id is provided, get that employee's info
$employee = $current_employee;
if ($is_admin && $selected_employee_id) {
    $stmt = $db->prepare("
        SELECT e.*, d.name as department_name, d.id as department_id, jt.title as job_title 
        FROM employees e
        LEFT JOIN departments d ON e.department_id = d.id
        LEFT JOIN job_titles jt ON e.job_title_id = jt.id
        WHERE e.id = ?
    ");
    $stmt->execute([$selected_employee_id]);
    $selected_employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($selected_employee) {
        $employee = $selected_employee;
    }
}

// If no employee info found
if (!$employee) {
    die("Çalışan bilgisi bulunamadı. Lütfen yöneticinizle iletişime geçin.");
}

// Get all employees for admin/manager selection
$employees = [];
if ($is_admin) {
    $stmt = $db->query("
        SELECT e.id, e.first_name, e.last_name, d.name as department_name 
        FROM employees e
        LEFT JOIN departments d ON e.department_id = d.id
        WHERE e.termination_date IS NULL
        ORDER BY e.first_name, e.last_name
    ");
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Find department chief (with "Şef" title)
$department_chief = null;
if ($employee['department_id']) {
    $stmt = $db->prepare("
        SELECT e.*, u.id as user_id, jt.title as job_title 
        FROM employees e
        JOIN job_titles jt ON e.job_title_id = jt.id
        JOIN users u ON e.user_id = u.id
        WHERE e.department_id = ? 
        AND (LOWER(jt.title) LIKE '%şef%' OR LOWER(jt.title) LIKE '%sef%')
        AND e.termination_date IS NULL
        LIMIT 1
    ");
    $stmt->execute([$employee['department_id']]);
    $department_chief = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Find admin users if no department chief
$admin_users = [];
if (!$department_chief) {
    $stmt = $db->query("
        SELECT u.id, e.first_name, e.last_name, e.id as employee_id
        FROM users u
        JOIN employees e ON u.id = e.user_id
        WHERE u.role = 'admin'
        AND e.termination_date IS NULL
    ");
    $admin_users = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Get leave types
$stmt = $db->query("SELECT * FROM leave_types WHERE is_active = 1 ORDER BY name");
$leave_types = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get employee's leave balances
$stmt = $db->prepare("
    SELECT lt.id, lt.name, lt.default_days, 
           COALESCE(elb.total_days, lt.default_days) as total_days,
           COALESCE(elb.used_days, 0) as used_days,
           COALESCE(elb.total_days, lt.default_days) - COALESCE(elb.used_days, 0) as remaining_days
    FROM leave_types lt
    LEFT JOIN employee_leave_balances elb ON lt.id = elb.leave_type_id AND elb.employee_id = ? AND elb.year = YEAR(CURRENT_DATE)
    WHERE lt.is_active = 1
    ORDER BY lt.name
");
$stmt->execute([$employee['id']]);
$leave_balances = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Validate inputs
        $employee_id = $is_admin && isset($_POST['employee_id']) ? (int)$_POST['employee_id'] : $employee['id'];
        $leave_type_id = $_POST['leave_type_id'] ?? null;
        $start_date = $_POST['start_date'] ?? null;
        $end_date = $_POST['end_date'] ?? null;
        $reason = $_POST['reason'] ?? '';
        $contact_info = $_POST['contact_info'] ?? '';
        
        if (!$employee_id || !$leave_type_id || !$start_date || !$end_date) {
            throw new Exception("Lütfen tüm zorunlu alanları doldurun.");
        }
        
        // Calculate total days (excluding weekends)
        $start = new DateTime($start_date);
        $end = new DateTime($end_date);
        $end->modify('+1 day'); // Include end date
        
        $total_days = 0;
        $interval = new DateInterval('P1D');
        $period = new DatePeriod($start, $interval, $end);
        
        foreach ($period as $day) {
            $dayOfWeek = $day->format('N');
            // Skip weekends (6=Saturday, 7=Sunday)
            if ($dayOfWeek < 6) {
                $total_days++;
            }
        }
        
        if ($total_days <= 0) {
            throw new Exception("İzin süresi en az 1 gün olmalıdır.");
        }
        
        // Check leave balance
        $stmt = $db->prepare("
            SELECT lt.name, lt.is_paid,
                   COALESCE(elb.total_days, lt.default_days) as total_days,
                   COALESCE(elb.used_days, 0) as used_days,
                   COALESCE(elb.total_days, lt.default_days) - COALESCE(elb.used_days, 0) as remaining_days
            FROM leave_types lt
            LEFT JOIN employee_leave_balances elb ON lt.id = elb.leave_type_id 
                AND elb.employee_id = ? AND elb.year = YEAR(CURRENT_DATE)
            WHERE lt.id = ?
        ");
        $stmt->execute([$employee_id, $leave_type_id]);
        $leave_balance = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($leave_balance['is_paid'] && $total_days > $leave_balance['remaining_days']) {
            throw new Exception("Yetersiz izin bakiyesi. Kalan izin hakkı: " . $leave_balance['remaining_days'] . " gün.");
        }
        
        // Begin transaction
        $db->beginTransaction();
        
        // Determine approver (department chief or admin)
        $approver_id = null;
        $approver_type = 'none';
        
        if ($department_chief) {
            $approver_id = $department_chief['user_id'];
            $approver_type = 'chief';
        } elseif (!empty($admin_users)) {
            $approver_id = $admin_users[0]['id']; // First admin
            $approver_type = 'admin';
        }
        
        // Insert leave request
        $stmt = $db->prepare("
            INSERT INTO leave_requests (
                employee_id, leave_type_id, start_date, end_date, 
                total_days, reason, contact_info, status,
                approver_id, approver_type
            ) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?)
        ");
        $stmt->execute([
            $employee_id,
            $leave_type_id,
            $start_date,
            $end_date,
            $total_days,
            $reason,
            $contact_info,
            $approver_id,
            $approver_type
        ]);
        
        $leave_request_id = $db->lastInsertId();
        
        // Log activity
        $stmt = $db->prepare("
            INSERT INTO activity_logs (
                user_id, activity_type, description, ip_address
            ) VALUES (?, 'leave_request', ?, ?)
        ");
        $stmt->execute([
            $_SESSION['user_id'],
            "İzin talebi oluşturuldu (ID: $leave_request_id, Çalışan ID: $employee_id)",
            $_SERVER['REMOTE_ADDR']
        ]);
        
        // Send notification to approver
        if ($approver_id) {
            $stmt = $db->prepare("
                INSERT INTO notifications (
                    user_id, type, title, message, related_id, is_read
                ) VALUES (?, 'leave_request', 'Yeni İzin Talebi', ?, ?, 0)
            ");
            $stmt->execute([
                $approver_id,
                "{$employee['first_name']} {$employee['last_name']} tarafından yeni bir izin talebi oluşturuldu.",
                $leave_request_id
            ]);
        }
        
        // Commit transaction
        $db->commit();
        
        // Set success message
        $approver_message = $department_chief 
            ? "Onay için departman şefine ({$department_chief['first_name']} {$department_chief['last_name']}) iletildi."
            : "Onay için sistem yöneticisine iletildi.";
            
        set_flash_message('success', "İzin talebi başarıyla oluşturuldu. $approver_message");
        
        // Redirect to prevent form resubmission
        if ($is_admin) {
            header('Location: leave_requests.php');
        } else {
            header('Location: my_leave_requests.php');
        }
        exit;
        
    } catch (Exception $e) {
        // Rollback transaction
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        
        // Set error message
        set_flash_message('error', $e->getMessage());
    }
}

// Include header
include 'includes/header.php';
?>

<div class="flex h-screen bg-gray-100">
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="flex-1 overflow-auto ml-0 lg:ml-64 pt-16">
        <div class="p-6">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-semibold text-gray-900">İzin Talebi Oluştur</h1>
                <?php if ($is_admin): ?>
                    <a href="leave_requests.php" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded inline-flex items-center">
                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                        </svg>
                        İzin Talepleri
                    </a>
                <?php else: ?>
                    <a href="my_leave_requests.php" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded inline-flex items-center">
                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                        </svg>
                        İzin Taleplerim
                    </a>
                <?php endif; ?>
            </div>
            
            <?php if (isset($_SESSION['flash_messages'])): ?>
                <?php foreach ($_SESSION['flash_messages'] as $type => $message): ?>
                    <div class="mb-4 p-4 rounded <?= $type === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' ?>">
                        <?= $message['message'] ?>
                    </div>
                <?php endforeach; ?>
                <?php unset($_SESSION['flash_messages']); ?>
            <?php endif; ?>
            
            <div class="bg-white shadow-md rounded-lg overflow-hidden">
                <div class="p-6">
                    <?php if ($is_admin): ?>
                        <div class="mb-6">
                            <form method="GET" action="leave_request.php" class="flex items-center space-x-4">
                                <div class="flex-grow">
                                    <label for="employee_selector" class="block text-sm font-medium text-gray-700 mb-1">Çalışan Seçin</label>
                                    <select id="employee_selector" name="employee_id" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                        <option value="">Seçiniz</option>
                                        <?php foreach ($employees as $emp): ?>
                                            <option value="<?= $emp['id'] ?>" <?= $selected_employee_id == $emp['id'] ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name'] . ' (' . $emp['department_name'] . ')') ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="pt-6">
                                    <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                                        Seç
                                    </button>
                                </div>
                            </form>
                        </div>
                    <?php endif; ?>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                        <div>
                            <h2 class="text-lg font-medium text-gray-900 mb-4">Çalışan Bilgileri</h2>
                            <div class="bg-gray-50 p-4 rounded-lg">
                                <p class="mb-2"><span class="font-medium">Ad Soyad:</span> <?= htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']) ?></p>
                                <p class="mb-2"><span class="font-medium">Departman:</span> <?= htmlspecialchars($employee['department_name'] ?? 'Belirtilmemiş') ?></p>
                                <p class="mb-2"><span class="font-medium">Unvan:</span> <?= htmlspecialchars($employee['job_title'] ?? 'Belirtilmemiş') ?></p>
                                <p><span class="font-medium">İşe Başlama Tarihi:</span> <?= date('d.m.Y', strtotime($employee['hire_date'])) ?></p>
                            </div>
                        </div>
                        
                        <div>
                            <h2 class="text-lg font-medium text-gray-900 mb-4">Onaylayacak Yetkili Bilgileri</h2>
                            <div class="bg-gray-50 p-4 rounded-lg">
                                <?php if ($department_chief): ?>
                                    <p class="mb-2"><span class="font-medium">Ad Soyad:</span> 
                                        <?= htmlspecialchars($department_chief['first_name'] . ' ' . $department_chief['last_name']) ?>
                                    </p>
                                    <p class="mb-2"><span class="font-medium">Unvan:</span> 
                                        <?= htmlspecialchars($department_chief['job_title']) ?>
                                    </p>
                                    <p class="text-sm text-blue-600">
                                        İzin talebiniz departman şefinizin onayına sunulacaktır.
                                    </p>
                                <?php elseif (!empty($admin_users)): ?>
                                    <p class="mb-2"><span class="font-medium">Onaylayacak:</span> Sistem Yöneticisi</p>
                                    <p class="text-sm text-blue-600">
                                        Departman şefi bulunmadığından, izin talebiniz sistem yöneticisinin onayına sunulacaktır.
                                    </p>
                                <?php else: ?>
                                    <p class="text-yellow-600">
                                        Dikkat: Sistemde onay verecek yetkili bulunamadı. 
                                        Lütfen İK departmanı ile iletişime geçin.
                                    </p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-6">
                        <h2 class="text-lg font-medium text-gray-900 mb-4">İzin Bakiyesi</h2>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">İzin Türü</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Toplam</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Kullanılan</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Kalan</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    <?php foreach ($leave_balances as $balance): ?>
                                        <tr>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?= htmlspecialchars($balance['name']) ?></td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?= $balance['total_days'] ?> gün</td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?= $balance['used_days'] ?> gün</td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?= $balance['remaining_days'] ?> gün</td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    <form method="POST" action="leave_request.php<?= $is_admin && $selected_employee_id ? '?employee_id='.$selected_employee_id : '' ?>" id="leaveRequestForm">
                        <h2 class="text-lg font-medium text-gray-900 mb-4">İzin Talebi</h2>
                        
                        <?php if ($is_admin): ?>
                            <input type="hidden" name="employee_id" value="<?= $employee['id'] ?>">
                        <?php endif; ?>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                            <div>
                                <label for="leave_type_id" class="block text-sm font-medium text-gray-700 mb-1">İzin Türü <span class="text-red-500">*</span></label>
                                <select id="leave_type_id" name="leave_type_id" required class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                    <option value="">Seçiniz</option>
                                    <?php foreach ($leave_types as $type): ?>
                                        <option value="<?= $type['id'] ?>" data-is-paid="<?= $type['is_paid'] ?>">
                                            <?= htmlspecialchars($type['name']) ?>
                                            <?= $type['is_paid'] ? ' (Ücretli)' : ' (Ücretsiz)' ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div>
                                <label for="contact_info" class="block text-sm font-medium text-gray-700 mb-1">İzin Sırasında İletişim Bilgisi</label>
                                <input type="text" id="contact_info" name="contact_info" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" placeholder="Telefon, adres vb.">
                            </div>
                        </div>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                            <div>
                                <label for="start_date" class="block text-sm font-medium text-gray-700 mb-1">Başlangıç Tarihi <span class="text-red-500">*</span></label>
                                <input type="date" id="start_date" name="start_date" required class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" min="<?= date('Y-m-d') ?>">
                            </div>
                            
                            <div>
                                <label for="end_date" class="block text-sm font-medium text-gray-700 mb-1">Bitiş Tarihi <span class="text-red-500">*</span></label>
                                <input type="date" id="end_date" name="end_date" required class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" min="<?= date('Y-m-d') ?>">
                            </div>
                        </div>
                        
                        <div class="mb-6">
                            <label for="reason" class="block text-sm font-medium text-gray-700 mb-1">İzin Nedeni</label>
                            <textarea id="reason" name="reason" rows="3" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"></textarea>
                        </div>
                        
                        <div class="bg-gray-50 p-4 rounded-lg mb-6">
                            <div class="flex items-start">
                                <div class="flex-shrink-0">
                                    <svg class="h-5 w-5 text-blue-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                        <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd" />
                                    </svg>
                                </div>
                                <div class="ml-3">
                                    <h3 class="text-sm font-medium text-blue-800">Bilgilendirme</h3>
                                    <div class="mt-2 text-sm text-blue-700">
                                        <p>İzin talebi yönetici tarafından onaylandıktan sonra geçerli olacaktır. Talebin durumunu "İzin Taleplerim" sayfasından takip edebilirsiniz.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="flex justify-end">
                            <button type="button" id="calculateDays" class="mr-4 bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded">
                                Gün Sayısını Hesapla
                            </button>
                            <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                                İzin Talebi Oluştur
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="calculationModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">İzin Gün Hesaplama</h3>
            <div id="calculationResult" class="mb-4">
                <!-- JavaScript ile doldurulacak -->
            </div>
            <div class="flex justify-end">
                <button onclick="closeCalculationModal()" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded">
                    Kapat
                </button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Çalışan seçildiğinde sayfayı yenile
    const employeeSelector = document.getElementById('employee_selector');
    if (employeeSelector) {
        employeeSelector.addEventListener('change', function() {
            if (this.value) {
                window.location.href = 'leave_request.php?employee_id=' + this.value;
            }
        });
    }
    
    // Tarih kontrolü
    const startDateInput = document.getElementById('start_date');
    const endDateInput = document.getElementById('end_date');
    
    startDateInput.addEventListener('change', function() {
        endDateInput.min = this.value;
        if (endDateInput.value && endDateInput.value < this.value) {
            endDateInput.value = this.value;
        }
    });
    
    // Gün hesaplama
    document.getElementById('calculateDays').addEventListener('click', function() {
        const leaveTypeSelect = document.getElementById('leave_type_id');
        const startDate = document.getElementById('start_date').value;
        const endDate = document.getElementById('end_date').value;
        
        if (!leaveTypeSelect.value || !startDate || !endDate) {
            alert('Lütfen izin türü, başlangıç ve bitiş tarihlerini seçin.');
            return;
        }
        
        const leaveTypeName = leaveTypeSelect.options[leaveTypeSelect.selectedIndex].text;
        const isPaid = leaveTypeSelect.options[leaveTypeSelect.selectedIndex].dataset.isPaid === '1';
        
        // Gün sayısını hesapla (hafta sonları hariç)
        const start = new Date(startDate);
        const end = new Date(endDate);
        end.setDate(end.getDate() + 1); // Bitiş tarihini dahil et
        
        let totalDays = 0;
        let weekendDays = 0;
        const currentDate = new Date(start);
        
        while (currentDate < end) {
            const dayOfWeek = currentDate.getDay(); // 0: Pazar, 6: Cumartesi
            if (dayOfWeek !== 0 && dayOfWeek !== 6) {
                totalDays++;
            } else {
                weekendDays++;
            }
            currentDate.setDate(currentDate.getDate() + 1);
        }
        
        // Sonuçları göster
        const resultDiv = document.getElementById('calculationResult');
        resultDiv.innerHTML = `
            <p><strong>İzin Türü:</strong> ${leaveTypeName}</p>
            <p><strong>Başlangıç:</strong> ${formatDate(startDate)}</p>
            <p><strong>Bitiş:</strong> ${formatDate(endDate)}</p>
            <p><strong>Toplam Gün:</strong> ${totalDays + weekendDays} gün</p>
            <p><strong>Hafta Sonu:</strong> ${weekendDays} gün</p>
            <p><strong>İş Günü:</strong> ${totalDays} gün</p>
            <p><strong>İzin Türü:</strong> ${isPaid ? 'Ücretli' : 'Ücretsiz'}</p>
        `;
        
        document.getElementById('calculationModal').classList.remove('hidden');
    });
    
    // Form gönderimi öncesi kontrol
    document.getElementById('leaveRequestForm').addEventListener('submit', function(e) {
        const leaveTypeSelect = document.getElementById('leave_type_id');
        const startDate = document.getElementById('start_date').value;
        const endDate = document.getElementById('end_date').value;
        
        if (!leaveTypeSelect.value || !startDate || !endDate) {
            e.preventDefault();
            alert('Lütfen tüm zorunlu alanları doldurun.');
            return;
        }
        
        // Tarih kontrolü
        const start = new Date(startDate);
        const end = new Date(endDate);
        
        if (start > end) {
            e.preventDefault();
            alert('Başlangıç tarihi bitiş tarihinden sonra olamaz.');
            return;
        }
    });
});

function closeCalculationModal() {
    document.getElementById('calculationModal').classList.add('hidden');
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('tr-TR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
    });
}
</script>

<?php include 'includes/footer.php'; ?>