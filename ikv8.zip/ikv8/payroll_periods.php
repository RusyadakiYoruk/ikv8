<?php
// Payroll Periods Management Page
session_start();

// Load configuration
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';

// Set timezone
date_default_timezone_set(DEFAULT_TIMEZONE);

// Connect to database
$database = new Database();
$db = $database->connect();

// Check if user is logged in and has admin or finance role
require_role(['admin', 'finance']);

// Get user information
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

// Initialize variables
$errors = [];
$success_message = '';

// Process form submission for adding/editing payroll period
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
        $errors['general'] = 'Geçersiz form gönderimi. Lütfen tekrar deneyin.';
    } else {
        $action = $_POST['action'];
        
        // Add new payroll period
        if ($action === 'add') {
            $period_name = sanitize($_POST['period_name'] ?? '');
            $start_date = sanitize($_POST['start_date'] ?? '');
            $end_date = sanitize($_POST['end_date'] ?? '');
            $payment_date = sanitize($_POST['payment_date'] ?? '');
            $status = sanitize($_POST['status'] ?? 'pending');
            
            // Validate required fields
            if (empty($period_name)) {
                $errors['period_name'] = 'Dönem adı zorunludur.';
            }
            
            if (empty($start_date)) {
                $errors['start_date'] = 'Başlangıç tarihi zorunludur.';
            } elseif (!validate_date($start_date)) {
                $errors['start_date'] = 'Geçerli bir tarih giriniz.';
            }
            
            if (empty($end_date)) {
                $errors['end_date'] = 'Bitiş tarihi zorunludur.';
            } elseif (!validate_date($end_date)) {
                $errors['end_date'] = 'Geçerli bir tarih giriniz.';
            }
            
            if (!empty($start_date) && !empty($end_date) && strtotime($start_date) > strtotime($end_date)) {
                $errors['end_date'] = 'Bitiş tarihi, başlangıç tarihinden sonra olmalıdır.';
            }
            
            if (empty($payment_date)) {
                $errors['payment_date'] = 'Ödeme tarihi zorunludur.';
            } elseif (!validate_date($payment_date)) {
                $errors['payment_date'] = 'Geçerli bir tarih giriniz.';
            }
            
            // Check if period with same dates already exists
            if (empty($errors)) {
                $stmt = $db->prepare("SELECT COUNT(*) FROM payroll_periods WHERE 
                    (start_date <= :end_date AND end_date >= :start_date)");
                $stmt->execute([
                    'start_date' => $start_date,
                    'end_date' => $end_date
                ]);
                
                if ($stmt->fetchColumn() > 0) {
                    $errors['general'] = 'Bu tarih aralığında zaten bir bordro dönemi bulunmaktadır.';
                }
            }
            
            // If no errors, insert payroll period
            if (empty($errors)) {
                try {
                    $stmt = $db->prepare("INSERT INTO payroll_periods (
                        period_name, start_date, end_date, payment_date, status, created_by, created_at
                    ) VALUES (
                        :period_name, :start_date, :end_date, :payment_date, :status, :created_by, NOW()
                    )");
                    
                    $stmt->execute([
                        'period_name' => $period_name,
                        'start_date' => $start_date,
                        'end_date' => $end_date,
                        'payment_date' => $payment_date,
                        'status' => $status,
                        'created_by' => $user_id
                    ]);
                    
                    $period_id = $db->lastInsertId();
                    
                    // Log the action
                    $stmt = $db->prepare("INSERT INTO activity_logs (user_id, activity_type, description, ip_address) VALUES (:user_id, 'payroll_period_add', :description, :ip_address)");
                    $stmt->execute([
                        'user_id' => $user_id,
                        'description' => "Yeni bordro dönemi eklendi: {$period_name} (ID: {$period_id})",
                        'ip_address' => $_SERVER['REMOTE_ADDR']
                    ]);
                    
                    $success_message = "Bordro dönemi başarıyla eklendi: {$period_name}";
                    
                    // Redirect to prevent form resubmission
                    set_flash_message('payroll_success', $success_message, 'success');
                    redirect('payroll_periods.php');
                    exit;
                    
                } catch (Exception $e) {
                    $errors['general'] = 'Bordro dönemi eklenirken bir hata oluştu: ' . $e->getMessage();
                    error_log('Bordro dönemi ekleme hatası: ' . $e->getMessage());
                }
            }
        }
        // Edit existing payroll period
        elseif ($action === 'edit' && isset($_POST['period_id'])) {
            $period_id = (int)$_POST['period_id'];
            $period_name = sanitize($_POST['period_name'] ?? '');
            $start_date = sanitize($_POST['start_date'] ?? '');
            $end_date = sanitize($_POST['end_date'] ?? '');
            $payment_date = sanitize($_POST['payment_date'] ?? '');
            $status = sanitize($_POST['status'] ?? 'pending');
            
            // Validate required fields
            if (empty($period_name)) {
                $errors['period_name_edit'] = 'Dönem adı zorunludur.';
            }
            
            if (empty($start_date)) {
                $errors['start_date_edit'] = 'Başlangıç tarihi zorunludur.';
            } elseif (!validate_date($start_date)) {
                $errors['start_date_edit'] = 'Geçerli bir tarih giriniz.';
            }
            
            if (empty($end_date)) {
                $errors['end_date_edit'] = 'Bitiş tarihi zorunludur.';
            } elseif (!validate_date($end_date)) {
                $errors['end_date_edit'] = 'Geçerli bir tarih giriniz.';
            }
            
            if (!empty($start_date) && !empty($end_date) && strtotime($start_date) > strtotime($end_date)) {
                $errors['end_date_edit'] = 'Bitiş tarihi, başlangıç tarihinden sonra olmalıdır.';
            }
            
            if (empty($payment_date)) {
                $errors['payment_date_edit'] = 'Ödeme tarihi zorunludur.';
            } elseif (!validate_date($payment_date)) {
                $errors['payment_date_edit'] = 'Geçerli bir tarih giriniz.';
            }
            
            // Check if period with same dates already exists (excluding current period)
            if (empty($errors)) {
                $stmt = $db->prepare("SELECT COUNT(*) FROM payroll_periods WHERE 
                    (start_date <= :end_date AND end_date >= :start_date) AND id != :period_id");
                $stmt->execute([
                    'start_date' => $start_date,
                    'end_date' => $end_date,
                    'period_id' => $period_id
                ]);
                
                if ($stmt->fetchColumn() > 0) {
                    $errors['general_edit'] = 'Bu tarih aralığında zaten başka bir bordro dönemi bulunmaktadır.';
                }
            }
            
            // If no errors, update payroll period
            if (empty($errors)) {
                try {
                    $stmt = $db->prepare("UPDATE payroll_periods SET 
                        period_name = :period_name, 
                        start_date = :start_date, 
                        end_date = :end_date, 
                        payment_date = :payment_date, 
                        status = :status, 
                        updated_by = :updated_by, 
                        updated_at = NOW() 
                    WHERE id = :period_id");
                    
                    $stmt->execute([
                        'period_name' => $period_name,
                        'start_date' => $start_date,
                        'end_date' => $end_date,
                        'payment_date' => $payment_date,
                        'status' => $status,
                        'updated_by' => $user_id,
                        'period_id' => $period_id
                    ]);
                    
                    // Log the action
                    $stmt = $db->prepare("INSERT INTO activity_logs (user_id, activity_type, description, ip_address) VALUES (:user_id, 'payroll_period_edit', :description, :ip_address)");
                    $stmt->execute([
                        'user_id' => $user_id,
                        'description' => "Bordro dönemi güncellendi: {$period_name} (ID: {$period_id})",
                        'ip_address' => $_SERVER['REMOTE_ADDR']
                    ]);
                    
                    $success_message = "Bordro dönemi başarıyla güncellendi: {$period_name}";
                    
                    // Redirect to prevent form resubmission
                    set_flash_message('payroll_success', $success_message, 'success');
                    redirect('payroll_periods.php');
                    exit;
                    
                } catch (Exception $e) {
                    $errors['general_edit'] = 'Bordro dönemi güncellenirken bir hata oluştu: ' . $e->getMessage();
                    error_log('Bordro dönemi güncelleme hatası: ' . $e->getMessage());
                }
            }
        }
        // Delete payroll period
        elseif ($action === 'delete' && isset($_POST['period_id'])) {
            $period_id = (int)$_POST['period_id'];
            
            try {
                // Check if there are any payrolls associated with this period
                $stmt = $db->prepare("SELECT COUNT(*) FROM payrolls WHERE period_id = :period_id");
                $stmt->execute(['period_id' => $period_id]);
                
                if ($stmt->fetchColumn() > 0) {
                    set_flash_message('payroll_error', 'Bu dönemle ilişkili bordro kayıtları bulunduğu için silinemez.', 'danger');
                    redirect('payroll_periods.php');
                    exit;
                }
                
                // Get period name for logging
                $stmt = $db->prepare("SELECT period_name FROM payroll_periods WHERE id = :period_id");
                $stmt->execute(['period_id' => $period_id]);
                $period_name = $stmt->fetchColumn();
                
                // Delete the period
                $stmt = $db->prepare("DELETE FROM payroll_periods WHERE id = :period_id");
                $stmt->execute(['period_id' => $period_id]);
                
                // Log the action
                $stmt = $db->prepare("INSERT INTO activity_logs (user_id, activity_type, description, ip_address) VALUES (:user_id, 'payroll_period_delete', :description, :ip_address)");
                $stmt->execute([
                    'user_id' => $user_id,
                    'description' => "Bordro dönemi silindi: {$period_name} (ID: {$period_id})",
                    'ip_address' => $_SERVER['REMOTE_ADDR']
                ]);
                
                set_flash_message('payroll_success', "Bordro dönemi başarıyla silindi: {$period_name}", 'success');
                redirect('payroll_periods.php');
                exit;
                
            } catch (Exception $e) {
                set_flash_message('payroll_error', 'Bordro dönemi silinirken bir hata oluştu: ' . $e->getMessage(), 'danger');
                error_log('Bordro dönemi silme hatası: ' . $e->getMessage());
                redirect('payroll_periods.php');
                exit;
            }
        }
    }
}

// Get payroll periods with pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 10;
$offset = ($page - 1) * $per_page;

// Get total count
$stmt = $db->query("SELECT COUNT(*) FROM payroll_periods");
$total_periods = $stmt->fetchColumn();
$total_pages = ceil($total_periods / $per_page);

// Get periods for current page
$sql = "SELECT pp.* FROM payroll_periods pp
        ORDER BY pp.start_date DESC
        LIMIT :offset, :per_page";

$stmt = $db->prepare($sql);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->bindValue(':per_page', $per_page, PDO::PARAM_INT);
$stmt->execute();
$periods = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Include header
include 'includes/header.php';
?>

<div class="flex h-screen bg-gray-100">
    <!-- Sidebar -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- Main Content -->
    <div class="flex-1 overflow-auto ml-0 lg:ml-64 pt-16">
        <div class="py-6 px-8">
            <!-- Page Header -->
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold text-gray-800">Bordro Dönemleri</h1>
                <nav class="flex" aria-label="Breadcrumb">
                    <ol class="inline-flex items-center space-x-1 md:space-x-3">
                        <li class="inline-flex items-center">
                        <a href="index.php" class="text-gray-700 hover:text-gray-900 inline-flex items-center">
                                <svg class="w-5 h-5 mr-2.5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"></path>
                                </svg>
                                Dashboard
                            </a>
                        </li>
                        <li>
                            <div class="flex items-center">
                                <svg class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span class="ml-1 text-gray-500 md:ml-2">Bordro Dönemleri</span>
                            </div>
                        </li>
                    </ol>
                </nav>
            </div>
            
            <!-- Flash Messages -->
            <?php if (isset($_SESSION['flash_messages']['payroll_success'])): ?>
                <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6" role="alert">
                    <p><?php echo $_SESSION['flash_messages']['payroll_success']['message']; ?></p>
                </div>
                <?php unset($_SESSION['flash_messages']['payroll_success']); ?>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['flash_messages']['payroll_error'])): ?>
                <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                    <p><?php echo $_SESSION['flash_messages']['payroll_error']['message']; ?></p>
                </div>
                <?php unset($_SESSION['flash_messages']['payroll_error']); ?>
            <?php endif; ?>
            
            <?php if (isset($errors['general'])): ?>
                <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                    <p><?php echo $errors['general']; ?></p>
                </div>
            <?php endif; ?>
            
            <!-- Add New Period Button -->
            <div class="mb-6">
                <button type="button" id="addPeriodBtn" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                    </svg>
                    Yeni Dönem Ekle
                </button>
            </div>
            
            <!-- Periods Table -->
            <div class="bg-white shadow-md rounded-lg overflow-hidden">
                <div class="px-4 py-5 border-b border-gray-200 sm:px-6">
                    <h3 class="text-lg leading-6 font-medium text-gray-900">
                        Bordro Dönemleri
                    </h3>
                    <p class="mt-1 max-w-2xl text-sm text-gray-500">
                        Maaş ödemelerinin yapıldığı dönemler
                    </p>
                </div>
                
                <?php if (count($periods) > 0): ?>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Dönem Adı
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Başlangıç Tarihi
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Bitiş Tarihi
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Ödeme Tarihi
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Durum
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Oluşturulma Tarihi
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        İşlemler
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php foreach ($periods as $period): ?>
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm font-medium text-gray-900">
                                                <?php echo htmlspecialchars($period['period_name']); ?>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm text-gray-500">
                                                <?php echo date('d.m.Y', strtotime($period['start_date'])); ?>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm text-gray-500">
                                                <?php echo date('d.m.Y', strtotime($period['end_date'])); ?>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm text-gray-500">
                                                <?php echo date('d.m.Y', strtotime($period['payment_date'])); ?>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            <?php echo date('d.m.Y H:i', strtotime($period['created_at'])); ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                                <?php 
                                                switch ($period['status']) {
                                                    case 'pending':
                                                        echo 'bg-yellow-100 text-yellow-800';
                                                        break;
                                                    case 'processing':
                                                        echo 'bg-blue-100 text-blue-800';
                                                        break;
                                                    case 'completed':
                                                        echo 'bg-green-100 text-green-800';
                                                        break;
                                                    case 'cancelled':
                                                        echo 'bg-red-100 text-red-800';
                                                        break;
                                                    default:
                                                        echo 'bg-gray-100 text-gray-800';
                                                }
                                                ?>">
                                                <?php 
                                                switch ($period['status']) {
                                                    case 'pending':
                                                        echo 'Beklemede';
                                                        break;
                                                    case 'processing':
                                                        echo 'İşleniyor';
                                                        break;
                                                    case 'completed':
                                                        echo 'Tamamlandı';
                                                        break;
                                                    case 'cancelled':
                                                        echo 'İptal Edildi';
                                                        break;
                                                    default:
                                                        echo $period['status'];
                                                }
                                                ?>
                                            </span>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            <?php echo date('d.m.Y H:i', strtotime($period['created_at'])); ?>
                                            <div class="text-xs text-gray-400">
                                                <?php echo htmlspecialchars($period['created_by_name'] ?? 'Sistem'); ?>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                            <div class="flex justify-end space-x-2">
                                                <a href="generate_payroll.php?period_id=<?php echo $period['id']; ?>" class="text-indigo-600 hover:text-indigo-900" title="Bordro Oluştur">
                                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
                                                    </svg>
                                                </a>
                                                <button type="button" class="text-blue-600 hover:text-blue-900 edit-period-btn" 
                                                        data-id="<?php echo $period['id']; ?>"
                                                        data-name="<?php echo htmlspecialchars($period['period_name']); ?>"
                                                        data-start="<?php echo $period['start_date']; ?>"
                                                        data-end="<?php echo $period['end_date']; ?>"
                                                        data-payment="<?php echo $period['payment_date']; ?>"
                                                        data-status="<?php echo $period['status']; ?>"
                                                        title="Düzenle">
                                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"></path>
                                                    </svg>
                                                </button>
                                                <button type="button" class="text-red-600 hover:text-red-900 delete-period-btn" 
                                                        data-id="<?php echo $period['id']; ?>"
                                                        data-name="<?php echo htmlspecialchars($period['period_name']); ?>"
                                                        title="Sil">
                                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                                    </svg>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <div class="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200 sm:px-6">
                            <div class="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
                                <div>
                                    <p class="text-sm text-gray-700">
                                        <span class="font-medium"><?php echo ($offset + 1); ?></span> - 
                                        <span class="font-medium"><?php echo min($offset + $per_page, $total_periods); ?></span> / 
                                        <span class="font-medium"><?php echo $total_periods; ?></span> kayıt gösteriliyor
                                    </p>
                                </div>
                                <div>
                                    <nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                                        <?php if ($page > 1): ?>
                                            <a href="?page=<?php echo ($page - 1); ?>" class="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                                                <span class="sr-only">Önceki</span>
                                                <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                                    <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />
                                                </svg>
                                            </a>
                                        <?php endif; ?>
                                        
                                        <?php
                                        $start_page = max(1, $page - 2);
                                        $end_page = min($total_pages, $page + 2);
                                        
                                        for ($i = $start_page; $i <= $end_page; $i++):
                                        ?>
                                            <a href="?page=<?php echo $i; ?>" class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium <?php echo $i === $page ? 'text-blue-600 bg-blue-50' : 'text-gray-700 hover:bg-gray-50'; ?>">
                                                <?php echo $i; ?>
                                            </a>
                                        <?php endfor; ?>
                                        
                                        <?php if ($page < $total_pages): ?>
                                            <a href="?page=<?php echo ($page + 1); ?>" class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                                                <span class="sr-only">Sonraki</span>
                                                <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                                    <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" />
                                                </svg>
                                            </a>
                                        <?php endif; ?>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                <?php else: ?>
                    <div class="p-6 text-center">
                        <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                        </svg>
                        <h3 class="mt-2 text-sm font-medium text-gray-900">Bordro Dönemi Bulunamadı</h3>
                        <p class="mt-1 text-sm text-gray-500">Henüz hiç bordro dönemi oluşturulmamış.</p>
                        <div class="mt-6">
                            <button type="button" id="addPeriodBtnEmpty" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                                </svg>
                                Yeni Dönem Ekle
                            </button>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Add Period Modal -->
<div id="addPeriodModal" class="fixed z-10 inset-0 overflow-y-auto hidden">
    <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div class="fixed inset-0 transition-opacity" aria-hidden="true">
            <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
        </div>
        <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
        <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
            <form method="POST" action="payroll_periods.php">
                <input type="hidden" name="action" value="add">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                
                <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                    <div class="sm:flex sm:items-start">
                        <div class="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-blue-100 sm:mx-0 sm:h-10 sm:w-10">
                            <svg class="h-6 w-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                            </svg>
                        </div>
                        <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                            <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                                Yeni Bordro Dönemi Ekle
                            </h3>
                            <div class="mt-4 space-y-4">
                                <div>
                                    <label for="period_name" class="block text-sm font-medium text-gray-700">Dönem Adı <span class="text-red-500">*</span></label>
                                    <input type="text" name="period_name" id="period_name" required class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md <?php echo isset($errors['period_name']) ? 'border-red-300' : ''; ?>" placeholder="Örn: Ocak 2023">
                                    <?php if (isset($errors['period_name'])): ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo $errors['period_name']; ?></p>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="grid grid-cols-2 gap-4">
                                    <div>
                                        <label for="start_date" class="block text-sm font-medium text-gray-700">Başlangıç Tarihi <span class="text-red-500">*</span></label>
                                        <input type="date" name="start_date" id="start_date" required class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md <?php echo isset($errors['start_date']) ? 'border-red-300' : ''; ?>">
                                        <?php if (isset($errors['start_date'])): ?>
                                            <p class="mt-1 text-sm text-red-600"><?php echo $errors['start_date']; ?></p>
                                        <?php endif; ?>
                                    </div>
                                    <div>
                                        <label for="end_date" class="block text-sm font-medium text-gray-700">Bitiş Tarihi <span class="text-red-500">*</span></label>
                                        <input type="date" name="end_date" id="end_date" required class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md <?php echo isset($errors['end_date']) ? 'border-red-300' : ''; ?>">
                                        <?php if (isset($errors['end_date'])): ?>
                                            <p class="mt-1 text-sm text-red-600"><?php echo $errors['end_date']; ?></p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div>
                                    <label for="payment_date" class="block text-sm font-medium text-gray-700">Ödeme Tarihi <span class="text-red-500">*</span></label>
                                    <input type="date" name="payment_date" id="payment_date" required class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md <?php echo isset($errors['payment_date']) ? 'border-red-300' : ''; ?>">
                                    <?php if (isset($errors['payment_date'])): ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo $errors['payment_date']; ?></p>
                                    <?php endif; ?>
                                </div>
                                
                                <div>
                                    <label for="status" class="block text-sm font-medium text-gray-700">Durum</label>
                                    <select name="status" id="status" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                        <option value="pending">Beklemede</option>
                                        <option value="processing">İşleniyor</option>
                                        <option value="completed">Tamamlandı</option>
                                        <option value="cancelled">İptal Edildi</option>
                                    </select>
                                </div>
                                
                                <?php if (isset($errors['general'])): ?>
                                    <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4" role="alert">
                                        <p><?php echo $errors['general']; ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                    <button type="submit" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm">
                        Kaydet
                    </button>
                    <button type="button" id="closeAddModal" class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">
                        İptal
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Period Modal -->
<div id="editPeriodModal" class="fixed z-10 inset-0 overflow-y-auto hidden">
    <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div class="fixed inset-0 transition-opacity" aria-hidden="true">
            <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
        </div>
        <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
        <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
            <form method="POST" action="payroll_periods.php">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="period_id" id="edit_period_id">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                
                <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                    <div class="sm:flex sm:items-start">
                        <div class="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-blue-100 sm:mx-0 sm:h-10 sm:w-10">
                        <svg class="h-6 w-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"></path>
                            </svg>
                        </div>
                        <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                            <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                                Bordro Dönemi Düzenle
                            </h3>
                            <div class="mt-4 space-y-4">
                                <div>
                                    <label for="edit_period_name" class="block text-sm font-medium text-gray-700">Dönem Adı <span class="text-red-500">*</span></label>
                                    <input type="text" name="period_name" id="edit_period_name" required class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md <?php echo isset($errors['period_name_edit']) ? 'border-red-300' : ''; ?>">
                                    <?php if (isset($errors['period_name_edit'])): ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo $errors['period_name_edit']; ?></p>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="grid grid-cols-2 gap-4">
                                    <div>
                                        <label for="edit_start_date" class="block text-sm font-medium text-gray-700">Başlangıç Tarihi <span class="text-red-500">*</span></label>
                                        <input type="date" name="start_date" id="edit_start_date" required class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md <?php echo isset($errors['start_date_edit']) ? 'border-red-300' : ''; ?>">
                                        <?php if (isset($errors['start_date_edit'])): ?>
                                            <p class="mt-1 text-sm text-red-600"><?php echo $errors['start_date_edit']; ?></p>
                                        <?php endif; ?>
                                    </div>
                                    <div>
                                        <label for="edit_end_date" class="block text-sm font-medium text-gray-700">Bitiş Tarihi <span class="text-red-500">*</span></label>
                                        <input type="date" name="end_date" id="edit_end_date" required class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md <?php echo isset($errors['end_date_edit']) ? 'border-red-300' : ''; ?>">
                                        <?php if (isset($errors['end_date_edit'])): ?>
                                            <p class="mt-1 text-sm text-red-600"><?php echo $errors['end_date_edit']; ?></p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div>
                                    <label for="edit_payment_date" class="block text-sm font-medium text-gray-700">Ödeme Tarihi <span class="text-red-500">*</span></label>
                                    <input type="date" name="payment_date" id="edit_payment_date" required class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md <?php echo isset($errors['payment_date_edit']) ? 'border-red-300' : ''; ?>">
                                    <?php if (isset($errors['payment_date_edit'])): ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo $errors['payment_date_edit']; ?></p>
                                    <?php endif; ?>
                                </div>
                                
                                <div>
                                    <label for="edit_status" class="block text-sm font-medium text-gray-700">Durum</label>
                                    <select name="status" id="edit_status" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                        <option value="pending">Beklemede</option>
                                        <option value="processing">İşleniyor</option>
                                        <option value="completed">Tamamlandı</option>
                                        <option value="cancelled">İptal Edildi</option>
                                    </select>
                                </div>
                                
                                <?php if (isset($errors['general_edit'])): ?>
                                    <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4" role="alert">
                                        <p><?php echo $errors['general_edit']; ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                    <button type="submit" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm">
                        Güncelle
                    </button>
                    <button type="button" id="closeEditModal" class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">
                        İptal
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Period Modal -->
<div id="deletePeriodModal" class="fixed z-10 inset-0 overflow-y-auto hidden">
    <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div class="fixed inset-0 transition-opacity" aria-hidden="true">
            <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
        </div>
        <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
        <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
            <form method="POST" action="payroll_periods.php">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="period_id" id="delete_period_id">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                
                <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                    <div class="sm:flex sm:items-start">
                        <div class="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-red-100 sm:mx-0 sm:h-10 sm:w-10">
                            <svg class="h-6 w-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
                            </svg>
                        </div>
                        <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                            <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                                Bordro Dönemini Sil
                            </h3>
                            <div class="mt-2">
                                <p class="text-sm text-gray-500">
                                    <span id="delete_period_name"></span> dönemini silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                    <button type="submit" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-red-600 text-base font-medium text-white hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 sm:ml-3 sm:w-auto sm:text-sm">
                        Sil
                    </button>
                    <button type="button" id="closeDeleteModal" class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">
                        İptal
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
    // Modal elements
    const addPeriodModal = document.getElementById('addPeriodModal');
    const editPeriodModal = document.getElementById('editPeriodModal');
    const deletePeriodModal = document.getElementById('deletePeriodModal');
    
    // Add Period Modal buttons
    const addPeriodBtn = document.getElementById('addPeriodBtn');
    const addPeriodBtnEmpty = document.getElementById('addPeriodBtnEmpty');
    const closeAddModal = document.getElementById('closeAddModal');
    
    // Edit Period Modal buttons
    const editPeriodBtns = document.querySelectorAll('.edit-period-btn');
    const closeEditModal = document.getElementById('closeEditModal');
    
    // Delete Period Modal buttons
    const deletePeriodBtns = document.querySelectorAll('.delete-period-btn');
    const closeDeleteModal = document.getElementById('closeDeleteModal');
    
    // Add Period Modal functions
    function openAddModal() {
        console.log('Opening add modal');
        addPeriodModal.classList.remove('hidden');
        
        // Set default dates
        const today = new Date();
        const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
        const lastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0);
        const paymentDay = new Date(today.getFullYear(), today.getMonth() + 1, 5);
        
        document.getElementById('start_date').value = formatDate(firstDay);
        document.getElementById('end_date').value = formatDate(lastDay);
        document.getElementById('payment_date').value = formatDate(paymentDay);
        
        // Set default period name (e.g., "January 2023")
        const monthNames = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"];
        document.getElementById('period_name').value = monthNames[today.getMonth()] + " " + today.getFullYear();
    }
    
    function closeAddModalFunc() {
        console.log('Closing add modal');
        addPeriodModal.classList.add('hidden');
    }
    
    // Edit Period Modal functions
    function openEditModal(event) {
        const button = event.currentTarget;
        const id = button.getAttribute('data-id');
        const name = button.getAttribute('data-name');
        const start = button.getAttribute('data-start');
        const end = button.getAttribute('data-end');
        const payment = button.getAttribute('data-payment');
        const status = button.getAttribute('data-status');
        
        document.getElementById('edit_period_id').value = id;
        document.getElementById('edit_period_name').value = name;
        document.getElementById('edit_start_date').value = start;
        document.getElementById('edit_end_date').value = end;
        document.getElementById('edit_payment_date').value = payment;
        document.getElementById('edit_status').value = status;
        
        editPeriodModal.classList.remove('hidden');
    }
    
    function closeEditModalFunc() {
        editPeriodModal.classList.add('hidden');
    }
    
    // Delete Period Modal functions
    function openDeleteModal(event) {
        const button = event.currentTarget;
        const id = button.getAttribute('data-id');
        const name = button.getAttribute('data-name');
        
        document.getElementById('delete_period_id').value = id;
        document.getElementById('delete_period_name').textContent = name;
        
        deletePeriodModal.classList.remove('hidden');
    }
    
    function closeDeleteModalFunc() {
        deletePeriodModal.classList.add('hidden');
    }
    
    // Helper function to format date as YYYY-MM-DD
    function formatDate(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
    
    // Add event listeners
    if (addPeriodBtn) {
        console.log('Adding event listener to addPeriodBtn');
        addPeriodBtn.addEventListener('click', openAddModal);
    }
    
    if (addPeriodBtnEmpty) {
        console.log('Adding event listener to addPeriodBtnEmpty');
        addPeriodBtnEmpty.addEventListener('click', openAddModal);
    }
    
    if (closeAddModal) {
        closeAddModal.addEventListener('click', closeAddModalFunc);
    }
    
    editPeriodBtns.forEach(button => {
        button.addEventListener('click', openEditModal);
    });
    
    if (closeEditModal) {
        closeEditModal.addEventListener('click', closeEditModalFunc);
    }
    
    deletePeriodBtns.forEach(button => {
        button.addEventListener('click', openDeleteModal);
    });
    
    if (closeDeleteModal) {
        closeDeleteModal.addEventListener('click', closeDeleteModalFunc);
    }
    
    // Close modals when clicking outside
    window.addEventListener('click', function(event) {
        if (event.target === addPeriodModal) {
            closeAddModalFunc();
        }
        if (event.target === editPeriodModal) {
            closeEditModalFunc();
        }
        if (event.target === deletePeriodModal) {
            closeDeleteModalFunc();
        }
    });
    
    // Validate date ranges
    const startDateInput = document.getElementById('start_date');
    const endDateInput = document.getElementById('end_date');
    
    if (endDateInput && startDateInput) {
        endDateInput.addEventListener('change', function() {
            if (startDateInput.value && endDateInput.value) {
                if (new Date(startDateInput.value) > new Date(endDateInput.value)) {
                    alert('Bitiş tarihi, başlangıç tarihinden sonra olmalıdır.');
                    endDateInput.value = '';
                }
            }
        });
        
        startDateInput.addEventListener('change', function() {
            if (startDateInput.value && endDateInput.value) {
                if (new Date(startDateInput.value) > new Date(endDateInput.value)) {
                    alert('Başlangıç tarihi, bitiş tarihinden önce olmalıdır.');
                    startDateInput.value = '';
                }
            }
        });
    }
    
    // Same validation for edit form
    const editStartDateInput = document.getElementById('edit_start_date');
    const editEndDateInput = document.getElementById('edit_end_date');
    
    if (editEndDateInput && editStartDateInput) {
        editEndDateInput.addEventListener('change', function() {
            if (editStartDateInput.value && editEndDateInput.value) {
                if (new Date(editStartDateInput.value) > new Date(editEndDateInput.value)) {
                    alert('Bitiş tarihi, başlangıç tarihinden sonra olmalıdır.');
                    editEndDateInput.value = '';
                }
            }
        });
        
        editStartDateInput.addEventListener('change', function() {
            if (editStartDateInput.value && editEndDateInput.value) {
                if (new Date(editStartDateInput.value) > new Date(editEndDateInput.value)) {
                    alert('Başlangıç tarihi, bitiş tarihinden önce olmalıdır.');
                    editStartDateInput.value = '';
                }
            }
        });
    }
    
    console.log('Payroll periods JavaScript initialized');
});
</script>

<?php include 'includes/footer.php'; ?>