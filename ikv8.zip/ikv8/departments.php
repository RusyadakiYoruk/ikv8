<?php
// Departments List Page
session_start();

// Load configuration
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';

// Set timezone
date_default_timezone_set(DEFAULT_TIMEZONE);

// Connect to database
$database = new Database();
$db = $database->connect();

// Check if user is logged in and has admin role
require_role(['admin']);

// Get user information
$user_id = $_SESSION['user_id'];

// Process department actions (add, edit, delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
        set_flash_message('department_error', 'Geçersiz form gönderimi. Lütfen tekrar deneyin.', 'danger');
    } else {
        try {
            // Begin transaction
            $db->beginTransaction();
            
            // Add Department
            if (isset($_POST['action']) && $_POST['action'] === 'add') {
                $stmt = $db->prepare("INSERT INTO departments (name, description, manager_id) VALUES (?, ?, ?)");
                $stmt->execute([
                    sanitize($_POST['name']),
                    !empty($_POST['description']) ? sanitize($_POST['description']) : null,
                    !empty($_POST['manager_id']) ? (int)$_POST['manager_id'] : null
                ]);
                
                $department_id = $db->lastInsertId();
                
                // Log activity
                $stmt = $db->prepare("INSERT INTO activity_logs (user_id, activity_type, description, ip_address) VALUES (?, ?, ?, ?)");
                $stmt->execute([
                    $user_id,
                    'department_add',
                    "Yeni departman eklendi: {$_POST['name']} (ID: {$department_id})",
                    $_SERVER['REMOTE_ADDR']
                ]);
                
                set_flash_message('department_success', "Departman başarıyla eklendi: {$_POST['name']}", 'success');
            }
            
            // Edit Department
            elseif (isset($_POST['action']) && $_POST['action'] === 'edit') {
                $stmt = $db->prepare("UPDATE departments SET name = ?, description = ?, manager_id = ? WHERE id = ?");
                $stmt->execute([
                    sanitize($_POST['name']),
                    !empty($_POST['description']) ? sanitize($_POST['description']) : null,
                    !empty($_POST['manager_id']) ? (int)$_POST['manager_id'] : null,
                    (int)$_POST['department_id']
                ]);
                
                // Log activity
                $stmt = $db->prepare("INSERT INTO activity_logs (user_id, activity_type, description, ip_address) VALUES (?, ?, ?, ?)");
                $stmt->execute([
                    $user_id,
                    'department_edit',
                    "Departman güncellendi: {$_POST['name']} (ID: {$_POST['department_id']})",
                    $_SERVER['REMOTE_ADDR']
                ]);
                
                set_flash_message('department_success', "Departman başarıyla güncellendi: {$_POST['name']}", 'success');
            }
            
            // Delete Department
            elseif (isset($_POST['action']) && $_POST['action'] === 'delete') {
                // Check if department has employees
                $stmt = $db->prepare("SELECT COUNT(*) FROM employees WHERE department_id = ?");
                $stmt->execute([(int)$_POST['department_id']]);
                $employee_count = $stmt->fetchColumn();
                
                if ($employee_count > 0) {
                    throw new Exception('Bu departmanda çalışanlar bulunduğu için silinemez.');
                }
                
                // Get department name for logging
                $stmt = $db->prepare("SELECT name FROM departments WHERE id = ?");
                $stmt->execute([(int)$_POST['department_id']]);
                $department_name = $stmt->fetchColumn();
                
                // Delete department
                $stmt = $db->prepare("DELETE FROM departments WHERE id = ?");
                $stmt->execute([(int)$_POST['department_id']]);
                
                // Log activity
                $stmt = $db->prepare("INSERT INTO activity_logs (user_id, activity_type, description, ip_address) VALUES (?, ?, ?, ?)");
                $stmt->execute([
                    $user_id,
                    'department_delete',
                    "Departman silindi: {$department_name} (ID: {$_POST['department_id']})",
                    $_SERVER['REMOTE_ADDR']
                ]);
                
                set_flash_message('department_success', "Departman başarıyla silindi: {$department_name}", 'success');
            }
            
            // Commit transaction
            $db->commit();
            
        } catch (Exception $e) {
            // Rollback transaction on error
            $db->rollBack();
            set_flash_message('department_error', $e->getMessage(), 'danger');
        }
    }
    
    // Redirect to prevent form resubmission
    redirect('departments.php');
    exit;
}

// Get departments with manager names and employee counts
$sql = "SELECT d.*,
               CONCAT(e.first_name, ' ', e.last_name) as manager_name,
               (SELECT COUNT(*) FROM employees WHERE department_id = d.id) as employee_count
        FROM departments d
        LEFT JOIN employees e ON d.manager_id = e.id
        ORDER BY d.name";

$stmt = $db->query($sql);
$departments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get managers for dropdown
$stmt = $db->query("
    SELECT e.id, e.first_name, e.last_name 
    FROM employees e 
    JOIN job_titles jt ON e.job_title_id = jt.id 
    WHERE jt.title LIKE '%manager%' OR jt.title LIKE '%director%' OR jt.title LIKE '%supervisor%' 
    ORDER BY e.first_name, e.last_name
");
$managers = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Include header
include 'includes/header.php';
?>

<div class="flex h-screen bg-gray-100">
    <!-- Sidebar -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- Main Content -->
    <div class="flex-1 overflow-auto ml-0 lg:ml-64 pt-16">
        <div class="py-6 px-8">
            <!-- Page Header -->
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold text-gray-800">Departmanlar</h1>
                <button type="button" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500" onclick="showAddDepartmentModal()">
                    <svg class="mr-2 -ml-1 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                    </svg>
                    Yeni Departman Ekle
                </button>
            </div>
            
            <!-- Flash Messages -->
            <?php if (isset($_SESSION['flash_messages']['department_success'])): ?>
                <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6" role="alert">
                    <p><?php echo $_SESSION['flash_messages']['department_success']['message']; ?></p>
                </div>
                <?php unset($_SESSION['flash_messages']['department_success']); ?>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['flash_messages']['department_error'])): ?>
                <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                    <p><?php echo $_SESSION['flash_messages']['department_error']['message']; ?></p>
                </div>
                <?php unset($_SESSION['flash_messages']['department_error']); ?>
            <?php endif; ?>
            
            <!-- Departments Table -->
            <div class="bg-white rounded-lg shadow overflow-hidden">
                <div class="min-w-full leading-normal">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Departman Adı</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Açıklama</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Yönetici</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Çalışan Sayısı</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">İşlemler</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($departments as $dept): ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($dept['name']); ?></div>
                                    </td>
                                    <td class="px-6 py-4">
                                        <div class="text-sm text-gray-900"><?php echo htmlspecialchars($dept['description'] ?? ''); ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-900"><?php echo htmlspecialchars($dept['manager_name'] ?? 'Belirtilmemiş'); ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-900"><?php echo $dept['employee_count']; ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <button type="button" class="text-indigo-600 hover:text-indigo-900 mr-3" 
                                                onclick="showEditDepartmentModal(<?php echo htmlspecialchars(json_encode($dept)); ?>)">
                                            <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                            </svg>
                                        </button>
                                        <?php if ($dept['employee_count'] == 0): ?>
                                            <button type="button" class="text-red-600 hover:text-red-900" 
                                                    onclick="showDeleteDepartmentModal(<?php echo $dept['id']; ?>, '<?php echo htmlspecialchars($dept['name']); ?>')">
                                                <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                                </svg>
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Department Modal -->
<div id="addDepartmentModal" class="fixed inset-0 z-50 overflow-y-auto hidden" aria-labelledby="modal-title" role="dialog" aria-modal="true">
    <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" aria-hidden="true"></div>
        <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
        <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
            <form method="POST" action="departments.php">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="add">
                
                <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                    <div class="sm:flex sm:items-start">
                        <div class="mt-3 text-center sm:mt-0 sm:text-left w-full">
                            <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                                Yeni Departman Ekle
                            </h3>
                            <div class="mt-4 space-y-4">
                                <div>
                                    <label for="name" class="block text-sm font-medium text-gray-700">Departman Adı <span class="text-red-500">*</span></label>
                                    <input type="text" name="name" id="name" required class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                <div>
                                    <label for="description" class="block text-sm font-medium text-gray-700">Açıklama</label>
                                    <textarea name="description" id="description" rows="3" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"></textarea>
                                </div>
                                <div>
                                    <label for="manager_id" class="block text-sm font-medium text-gray-700">Yönetici</label>
                                    <select name="manager_id" id="manager_id" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                        <option value="">Seçiniz</option>
                                        <?php foreach ($managers as $manager): ?>
                                            <option value="<?php echo $manager['id']; ?>"><?php echo htmlspecialchars($manager['first_name'] . ' ' . $manager['last_name']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                    <button type="submit" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm">
                        Ekle
                    </button>
                    <button type="button" class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm close-modal">
                        İptal
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Department Modal -->
<div id="editDepartmentModal" class="fixed inset-0 z-50 overflow-y-auto hidden" aria-labelledby="modal-title" role="dialog" aria-modal="true">
    <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" aria-hidden="true"></div>
        <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
        <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
            <form method="POST" action="departments.php">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="department_id" id="edit_department_id">
                
                <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                    <div class="sm:flex sm:items-start">
                        <div class="mt-3 text-center sm:mt-0 sm:text-left w-full">
                            <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                                Departman Düzenle
                            </h3>
                            <div class="mt-4 space-y-4">
                                <div>
                                    <label for="edit_name" class="block text-sm font-medium text-gray-700">Departman Adı <span class="text-red-500">*</span></label>
                                    <input type="text" name="name" id="edit_name" required class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                <div>
                                    <label for="edit_description" class="block text-sm font-medium text-gray-700">Açıklama</label>
                                    <textarea name="description" id="edit_description" rows="3" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"></textarea>
                                </div>
                                <div>
                                    <label for="edit_manager_id" class="block text-sm font-medium text-gray-700">Yönetici</label>
                                    <select name="manager_id" id="edit_manager_id" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                        <option value="">Seçiniz</option>
                                        <?php foreach ($managers as $manager): ?>
                                            <option value="<?php echo $manager['id']; ?>"><?php echo htmlspecialchars($manager['first_name'] . ' ' . $manager['last_name']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                    <button type="submit" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm">
                        Güncelle
                    </button>
                    <button type="button" class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm close-modal">
                        İptal
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Department Modal -->
<div id="deleteDepartmentModal" class="fixed inset-0 z-50 overflow-y-auto hidden" aria-labelledby="modal-title" role="dialog" aria-modal="true">
    <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" aria-hidden="true"></div>
        <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
        <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
            <form method="POST" action="departments.php">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="department_id" id="delete_department_id">
                
                <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                    <div class="sm:flex sm:items-start">
                        <div class="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-red-100 sm:mx-0 sm:h-10 sm:w-10">
                            <svg class="h-6 w-6 text-red-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                            </svg>
                        </div>
                        <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                            <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                                Departmanı Sil
                            </h3>
                            <div class="mt-2">
                                <p class="text-sm text-gray-500">
                                    <span id="delete_department_name"></span> departmanını silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                    <button type="submit" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-red-600 text-base font-medium text-white hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 sm:ml-3 sm:w-auto sm:text-sm">
                        Sil
                    </button>
                    <button type="button" class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm close-modal">
                        İptal
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- JavaScript for modals -->
<script>
    // Show Add Department Modal
    function showAddDepartmentModal() {
        document.getElementById('addDepartmentModal').classList.remove('hidden');
    }
    
    // Show Edit Department Modal
    function showEditDepartmentModal(department) {
        document.getElementById('edit_department_id').value = department.id;
        document.getElementById('edit_name').value = department.name;
        document.getElementById('edit_description').value = department.description || '';
        document.getElementById('edit_manager_id').value = department.manager_id || '';
        
        document.getElementById('editDepartmentModal').classList.remove('hidden');
    }
    
    // Show Delete Department Modal
    function showDeleteDepartmentModal(id, name) {
        document.getElementById('delete_department_id').value = id;
        document.getElementById('delete_department_name').textContent = name;
        
        document.getElementById('deleteDepartmentModal').classList.remove('hidden');
    }
    
    // Close Modals
    document.querySelectorAll('.close-modal').forEach(button => {
        button.addEventListener('click', function() {
            document.getElementById('addDepartmentModal').classList.add('hidden');
            document.getElementById('editDepartmentModal').classList.add('hidden');
            document.getElementById('deleteDepartmentModal').classList.add('hidden');
        });
    });
    
    // Close modals when clicking outside
    window.addEventListener('click', function(event) {
        if (event.target.classList.contains('fixed')) {
            event.target.classList.add('hidden');
        }
    });
</script>

<?php
// Include footer
include 'includes/footer.php';
?>