<?php
// Company Settings Page
session_start();

// Load configuration
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';

// Set timezone
date_default_timezone_set(DEFAULT_TIMEZONE);

// Connect to database
$database = new Database();
$db = $database->connect();

// Check if user is logged in and has admin role
require_role('admin');

// Get user information
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

// Get employee information if available
$employee = null;
$stmt = $db->prepare("SELECT * FROM employees WHERE user_id = :user_id LIMIT 1");
$stmt->execute(['user_id' => $user_id]);
$employee = $stmt->fetch(PDO::FETCH_ASSOC);

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
        set_flash_message('company_error', 'Geçersiz form gönderimi. Lütfen tekrar deneyin.', 'danger');
    } else {
        try {
            // Begin transaction
            $db->beginTransaction();
            
            // Handle logo upload if provided
            if (isset($_FILES['company_logo']) && $_FILES['company_logo']['error'] === UPLOAD_ERR_OK) {
                $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
                $max_size = 2 * 1024 * 1024; // 2MB
                
                // Validate file type and size
                if (!in_array($_FILES['company_logo']['type'], $allowed_types)) {
                    throw new Exception('Logo dosyası sadece JPEG, PNG veya GIF formatında olabilir.');
                }
                
                if ($_FILES['company_logo']['size'] > $max_size) {
                    throw new Exception('Logo dosyası 2MB\'dan büyük olamaz.');
                }
                
                // Create uploads directory if it doesn't exist
                $upload_dir = 'uploads/company/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                }
                
                // Generate unique filename
                $filename = 'logo_' . time() . '_' . uniqid() . '.' . pathinfo($_FILES['company_logo']['name'], PATHINFO_EXTENSION);
                $target_file = $upload_dir . $filename;
                
                // Move uploaded file
                if (move_uploaded_file($_FILES['company_logo']['tmp_name'], $target_file)) {
                    // Update company logo setting
                    $stmt = $db->prepare("SELECT COUNT(*) FROM settings WHERE setting_key = 'company_logo'");
                    $stmt->execute();
                    $exists = $stmt->fetchColumn() > 0;
                    
                    if ($exists) {
                        $stmt = $db->prepare("UPDATE settings SET setting_value = :value WHERE setting_key = 'company_logo'");
                    } else {
                        $stmt = $db->prepare("INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES ('company_logo', :value, 'company', 'Company Logo')");
                    }
                    
                    $stmt->execute(['value' => $target_file]);
                } else {
                    throw new Exception('Logo yüklenirken bir hata oluştu.');
                }
            }
            
            // Update company settings
            $company_settings = [
                'company_name',
                'company_legal_name',
                'company_address',
                'company_city',
                'company_state',
                'company_country',
                'company_postal_code',
                'company_phone',
                'company_email',
                'company_website',
                'company_tax_id',
                'company_registration_number',
                'company_industry',
                'company_founded_year',
                'company_description'
            ];
            
            foreach ($company_settings as $key) {
                if (isset($_POST[$key])) {
                    $value = sanitize($_POST[$key]);
                    
                    // Check if setting exists
                    $stmt = $db->prepare("SELECT COUNT(*) FROM settings WHERE setting_key = :key");
                    $stmt->execute(['key' => $key]);
                    $exists = $stmt->fetchColumn() > 0;
                    
                    if ($exists) {
                        // Update existing setting
                        $stmt = $db->prepare("UPDATE settings SET setting_value = :value WHERE setting_key = :key");
                    } else {
                        // Insert new setting
                        $stmt = $db->prepare("INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES (:key, :value, 'company', :description)");
                    }
                    
                    $params = [
                        'key' => $key,
                        'value' => $value
                    ];
                    
                    if (!$exists) {
                        $params['description'] = ucwords(str_replace('_', ' ', str_replace('company_', '', $key)));
                    }
                    
                    $stmt->execute($params);
                }
            }
            
            // Commit transaction
            $db->commit();
            
            // Log activity
            $stmt = $db->prepare("INSERT INTO activity_logs (user_id, activity_type, description, ip_address) VALUES (:user_id, 'company_update', :description, :ip_address)");
            $stmt->execute([
                'user_id' => $user_id,
                'description' => 'Şirket bilgileri güncellendi',
                'ip_address' => $_SERVER['REMOTE_ADDR']
            ]);
            
            set_flash_message('company_success', 'Şirket bilgileri başarıyla güncellendi.', 'success');
        } catch (Exception $e) {
            // Rollback transaction on error
            $db->rollBack();
            set_flash_message('company_error', 'Şirket bilgileri güncellenirken bir hata oluştu: ' . $e->getMessage(), 'danger');
        }
    }
    
    // Redirect to prevent form resubmission
    redirect('company_settings.php');
}

// Get company settings
$company_settings = [];
$stmt = $db->query("SELECT * FROM settings WHERE setting_group = 'company'");
$settings = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($settings as $setting) {
    $company_settings[$setting['setting_key']] = $setting['setting_value'];
}

// Include header
include 'includes/header.php';
?>

<div class="flex h-screen bg-gray-100">
    <!-- Sidebar -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- Main Content -->
    <div class="flex-1 overflow-auto ml-0 lg:ml-64 pt-16">
        <div class="py-6 px-8">
            <!-- Page Header -->
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold text-gray-800">Şirket Bilgileri</h1>
                <nav class="flex" aria-label="Breadcrumb">
                    <ol class="inline-flex items-center space-x-1 md:space-x-3">
                        <li class="inline-flex items-center">
                            <a href="index.php" class="text-gray-700 hover:text-gray-900 inline-flex items-center">
                                <svg class="w-5 h-5 mr-2.5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"></path>
                                </svg>
                                Dashboard
                            </a>
                        </li>
                        <li>
                            <div class="flex items-center">
                                <svg class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <a href="company_settings.php" class="ml-1 text-gray-700 hover:text-gray-900 md:ml-2">Şirket Bilgileri</a>
                            </div>
                        </li>
                    </ol>
                </nav>
            </div>
            
            <!-- Flash Messages -->
            <?php if (isset($_SESSION['flash_messages']['company_success'])): ?>
                <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6" role="alert">
                    <p><?php echo $_SESSION['flash_messages']['company_success']['message']; ?></p>
                </div>
                <?php unset($_SESSION['flash_messages']['company_success']); ?>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['flash_messages']['company_error'])): ?>
                <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                    <p><?php echo $_SESSION['flash_messages']['company_error']['message']; ?></p>
                </div>
                <?php unset($_SESSION['flash_messages']['company_error']); ?>
            <?php endif; ?>
            
            <!-- Company Settings Form -->
            <div class="bg-white rounded-lg shadow">
                <div class="border-b px-4 py-3">
                    <h3 class="text-lg font-semibold text-gray-700">Şirket Bilgileri</h3>
                </div>
                <div class="p-6">
                    <form method="POST" action="company_settings.php" enctype="multipart/form-data">
                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <!-- Company Logo -->
                            <div class="col-span-1 md:col-span-2">
                                <label class="block text-sm font-medium text-gray-700">Şirket Logosu</label>
                                <div class="mt-2 flex items-center">
                                    <?php if (isset($company_settings['company_logo']) && !empty($company_settings['company_logo'])): ?>
                                        <div class="mr-4">
                                            <img src="<?php echo $company_settings['company_logo']; ?>" alt="Company Logo" class="h-16 w-auto">
                                        </div>
                                    <?php endif; ?>
                                    <label for="company_logo" class="cursor-pointer bg-white py-2 px-3 border border-gray-300 rounded-md shadow-sm text-sm leading-4 font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                        <span>Logo Yükle</span>
                                        <input id="company_logo" name="company_logo" type="file" class="sr-only" accept="image/jpeg,image/png,image/gif">
                                    </label>
                                    <p class="ml-4 text-xs text-gray-500">PNG, JPG veya GIF. Maksimum 2MB.</p>
                                </div>
                            </div>
                            
                            <!-- Company Name -->
                            <div class="col-span-1">
                                <label for="company_name" class="block text-sm font-medium text-gray-700">Şirket Adı</label>
                                <input type="text" name="company_name" id="company_name" value="<?php echo isset($company_settings['company_name']) ? $company_settings['company_name'] : ''; ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                            </div>
                            
                            <!-- Company Legal Name -->
                            <div class="col-span-1">
                                <label for="company_legal_name" class="block text-sm font-medium text-gray-700">Şirket Yasal Adı</label>
                                <input type="text" name="company_legal_name" id="company_legal_name" value="<?php echo isset($company_settings['company_legal_name']) ? $company_settings['company_legal_name'] : ''; ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                            </div>
                            
                            <!-- Company Address -->
                            <div class="col-span-1 md:col-span-2">
                                <label for="company_address" class="block text-sm font-medium text-gray-700">Adres</label>
                                <textarea name="company_address" id="company_address" rows="3" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"><?php echo isset($company_settings['company_address']) ? $company_settings['company_address'] : ''; ?></textarea>
                            </div>
                            
                            <!-- Company City -->
                            <div class="col-span-1">
                                <label for="company_city" class="block text-sm font-medium text-gray-700">Şehir</label>
                                <input type="text" name="company_city" id="company_city" value="<?php echo isset($company_settings['company_city']) ? $company_settings['company_city'] : ''; ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                            </div>
                            
                            <!-- Company State/Province -->
                            <div class="col-span-1">
                                <label for="company_state" class="block text-sm font-medium text-gray-700">Eyalet/Bölge</label>
                                <input type="text" name="company_state" id="company_state" value="<?php echo isset($company_settings['company_state']) ? $company_settings['company_state'] : ''; ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                            </div>
                            
                            <!-- Company Country -->
                            <div class="col-span-1">
                                <label for="company_country" class="block text-sm font-medium text-gray-700">Ülke</label>
                                <input type="text" name="company_country" id="company_country" value="<?php echo isset($company_settings['company_country']) ? $company_settings['company_country'] : 'Russia'; ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                            </div>
                            
                            <!-- Company Postal Code -->
                            <div class="col-span-1">
                                <label for="company_postal_code" class="block text-sm font-medium text-gray-700">Posta Kodu</label>
                                <input type="text" name="company_postal_code" id="company_postal_code" value="<?php echo isset($company_settings['company_postal_code']) ? $company_settings['company_postal_code'] : ''; ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                            </div>
                            
                            <!-- Company Phone -->
                            <div class="col-span-1">
                                <label for="company_phone" class="block text-sm font-medium text-gray-700">Telefon</label>
                                <input type="tel" name="company_phone" id="company_phone" value="<?php echo isset($company_settings['company_phone']) ? $company_settings['company_phone'] : ''; ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                            </div>
                            
                            <!-- Company Email -->
                            <div class="col-span-1">
                                <label for="company_email" class="block text-sm font-medium text-gray-700">E-posta</label>
                                <input type="email" name="company_email" id="company_email" value="<?php echo isset($company_settings['company_email']) ? $company_settings['company_email'] : ''; ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                            </div>
                            
                            <!-- Company Website -->
                            <div class="col-span-1">
                                <label for="company_website" class="block text-sm font-medium text-gray-700">Web Sitesi</label>
                                <input type="url" name="company_website" id="company_website" value="<?php echo isset($company_settings['company_website']) ? $company_settings['company_website'] : ''; ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                            </div>
                            
                            <!-- Company Tax ID -->
                            <div class="col-span-1">
                                <label for="company_tax_id" class="block text-sm font-medium text-gray-700">Vergi Numarası</label>
                                <input type="text" name="company_tax_id" id="company_tax_id" value="<?php echo isset($company_settings['company_tax_id']) ? $company_settings['company_tax_id'] : ''; ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                            </div>
                            
                            <!-- Company Registration Number -->
                            <div class="col-span-1">
                                <label for="company_registration_number" class="block text-sm font-medium text-gray-700">Ticaret Sicil Numarası</label>
                                <input type="text" name="company_registration_number" id="company_registration_number" value="<?php echo isset($company_settings['company_registration_number']) ? $company_settings['company_registration_number'] : ''; ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                            </div>
                            
                            <!-- Company Industry -->
                            <div class="col-span-1">
                                <label for="company_industry" class="block text-sm font-medium text-gray-700">Sektör</label>
                                <input type="text" name="company_industry" id="company_industry" value="<?php echo isset($company_settings['company_industry']) ? $company_settings['company_industry'] : 'İnşaat'; ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                            </div>
                            
                            <!-- Company Founded Year -->
                            <div class="col-span-1">
                                <label for="company_founded_year" class="block text-sm font-medium text-gray-700">Kuruluş Yılı</label>
                                <input type="number" name="company_founded_year" id="company_founded_year" min="1900" max="<?php echo date('Y'); ?>" value="<?php echo isset($company_settings['company_founded_year']) ? $company_settings['company_founded_year'] : ''; ?>" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                            </div>
                            
                            <!-- Company Description -->
                            <div class="col-span-1 md:col-span-2">
                                <label for="company_description" class="block text-sm font-medium text-gray-700">Şirket Açıklaması</label>
                                <textarea name="company_description" id="company_description" rows="4" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"><?php echo isset($company_settings['company_description']) ? $company_settings['company_description'] : ''; ?></textarea>
                            </div>
                        </div>
                        
                        <div class="mt-6 flex justify-end">
                            <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                <svg class="mr-2 -ml-1 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                                </svg>
                                Şirket Bilgilerini Kaydet
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript for file upload preview -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const fileInput = document.getElementById('company_logo');
        
        fileInput.addEventListener('change', function() {
            const file = this.files[0];
            
            if (file) {
                // Check file type
                const fileType = file.type;
                if (fileType !== 'image/jpeg' && fileType !== 'image/png' && fileType !== 'image/gif') {
                    alert('Lütfen sadece JPEG, PNG veya GIF formatında dosya yükleyin.');
                    this.value = '';
                    return;
                }
                
                // Check file size (max 2MB)
                const maxSize = 2 * 1024 * 1024; // 2MB
                if (file.size > maxSize) {
                    alert('Dosya boyutu 2MB\'dan büyük olamaz.');
                    this.value = '';
                    return;
                }
                
                // Show file name
                const fileName = file.name;
                const fileSize = (file.size / 1024).toFixed(2) + ' KB';
                
                // Update UI to show selected file
                const fileLabel = this.closest('label').querySelector('span');
                fileLabel.textContent = fileName;
                
                // You could also add a preview of the image here if desired
            }
        });
    });
</script>

<?php
// Include footer
include 'includes/footer.php';
?>