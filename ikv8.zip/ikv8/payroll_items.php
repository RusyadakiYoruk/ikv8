<?php
// Payroll Items Management Page
session_start();

// Load configuration
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';

// Set timezone
date_default_timezone_set(DEFAULT_TIMEZONE);

// Connect to database
$database = new Database();
$db = $database->connect();

// Check if user is logged in and has admin or finance role
require_role(['admin', 'finance']);

// Get user information
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

// Initialize variables
$errors = [];
$success_message = '';
$item = [
    'name' => '',
    'code' => '',
    'type' => 'earning',
    'is_taxable' => 1,
    'is_fixed' => 0,
    'default_amount' => 0,
    'description' => '',
    'status' => 'active'
];

// Process form submission for adding/editing payroll item
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
        $errors['general'] = 'Geçersiz form gönderimi. Lütfen tekrar deneyin.';
    } else {
        $action = $_POST['action'];
        
        // Add new payroll item
        if ($action === 'add') {
            $item['name'] = sanitize($_POST['name'] ?? '');
            $item['code'] = sanitize($_POST['code'] ?? '');
            $item['type'] = sanitize($_POST['type'] ?? 'earning');
            $item['is_taxable'] = isset($_POST['is_taxable']) ? 1 : 0;
            $item['is_fixed'] = isset($_POST['is_fixed']) ? 1 : 0;
            $item['default_amount'] = (float)($_POST['default_amount'] ?? 0);
            $item['description'] = sanitize($_POST['description'] ?? '');
            $item['status'] = sanitize($_POST['status'] ?? 'active');
            
            // Validate required fields
            if (empty($item['name'])) {
                $errors['name'] = 'Kalem adı zorunludur.';
            }
            
            if (empty($item['code'])) {
                $errors['code'] = 'Kalem kodu zorunludur.';
            } else {
                // Check if code already exists
                $stmt = $db->prepare("SELECT COUNT(*) FROM payroll_items WHERE code = :code");
                $stmt->execute(['code' => $item['code']]);
                if ($stmt->fetchColumn() > 0) {
                    $errors['code'] = 'Bu kalem kodu zaten kullanılıyor.';
                }
            }
            
            // If no errors, insert payroll item
            if (empty($errors)) {
                try {
                    $stmt = $db->prepare("INSERT INTO payroll_items (
                        name, code, type, is_taxable, is_fixed, default_amount, 
                        description, status, created_by, created_at
                    ) VALUES (
                        :name, :code, :type, :is_taxable, :is_fixed, :default_amount, 
                        :description, :status, :created_by, NOW()
                    )");
                    
                    $stmt->execute([
                        'name' => $item['name'],
                        'code' => $item['code'],
                        'type' => $item['type'],
                        'is_taxable' => $item['is_taxable'],
                        'is_fixed' => $item['is_fixed'],
                        'default_amount' => $item['default_amount'],
                        'description' => $item['description'],
                        'status' => $item['status'],
                        'created_by' => $user_id
                    ]);
                    
                    $item_id = $db->lastInsertId();
                    
                    // Log the action
                    $stmt = $db->prepare("INSERT INTO activity_logs (user_id, activity_type, description, ip_address) VALUES (:user_id, 'payroll_item_add', :description, :ip_address)");
                    $stmt->execute([
                        'user_id' => $user_id,
                        'description' => "Yeni maaş kalemi eklendi: {$item['name']} (Kod: {$item['code']})",
                        'ip_address' => $_SERVER['REMOTE_ADDR']
                    ]);
                    
                    $success_message = "Maaş kalemi başarıyla eklendi: {$item['name']}";
                    
                    // Reset form
                    $item = [
                        'name' => '',
                        'code' => '',
                        'type' => 'earning',
                        'is_taxable' => 1,
                        'is_fixed' => 0,
                        'default_amount' => 0,
                        'description' => '',
                        'status' => 'active'
                    ];
                    
                    set_flash_message('payroll_item_success', $success_message, 'success');
                    redirect('payroll_items.php');
                    exit;
                    
                } catch (Exception $e) {
                    $errors['general'] = 'Maaş kalemi eklenirken bir hata oluştu: ' . $e->getMessage();
                    error_log('Maaş kalemi ekleme hatası: ' . $e->getMessage());
                }
            }
        }
        // Edit existing payroll item
        elseif ($action === 'edit' && isset($_POST['item_id'])) {
            $item_id = (int)$_POST['item_id'];
            $item['name'] = sanitize($_POST['name'] ?? '');
            $item['code'] = sanitize($_POST['code'] ?? '');
            $item['type'] = sanitize($_POST['type'] ?? 'earning');
            $item['is_taxable'] = isset($_POST['is_taxable']) ? 1 : 0;
            $item['is_fixed'] = isset($_POST['is_fixed']) ? 1 : 0;
            $item['default_amount'] = (float)($_POST['default_amount'] ?? 0);
            $item['description'] = sanitize($_POST['description'] ?? '');
            $item['status'] = sanitize($_POST['status'] ?? 'active');
            
            // Validate required fields
            if (empty($item['name'])) {
                $errors['name_edit'] = 'Kalem adı zorunludur.';
            }
            
            if (empty($item['code'])) {
                $errors['code_edit'] = 'Kalem kodu zorunludur.';
            } else {
                // Check if code already exists (excluding current item)
                $stmt = $db->prepare("SELECT COUNT(*) FROM payroll_items WHERE code = :code AND id != :item_id");
                $stmt->execute([
                    'code' => $item['code'],
                    'item_id' => $item_id
                ]);
                if ($stmt->fetchColumn() > 0) {
                    $errors['code_edit'] = 'Bu kalem kodu zaten kullanılıyor.';
                }
            }
            
            // If no errors, update payroll item
            if (empty($errors)) {
                try {
                    $stmt = $db->prepare("UPDATE payroll_items SET 
                        name = :name,
                        code = :code,
                        type = :type,
                        is_taxable = :is_taxable,
                        is_fixed = :is_fixed,
                        default_amount = :default_amount,
                        description = :description,
                        status = :status,
                        updated_by = :updated_by,
                        updated_at = NOW()
                    WHERE id = :item_id");
                    
                    $stmt->execute([
                        'name' => $item['name'],
                        'code' => $item['code'],
                        'type' => $item['type'],
                        'is_taxable' => $item['is_taxable'],
                        'is_fixed' => $item['is_fixed'],
                        'default_amount' => $item['default_amount'],
                        'description' => $item['description'],
                        'status' => $item['status'],
                        'updated_by' => $user_id,
                        'item_id' => $item_id
                    ]);
                    
                    // Log the action
                    $stmt = $db->prepare("INSERT INTO activity_logs (user_id, activity_type, description, ip_address) VALUES (:user_id, 'payroll_item_edit', :description, :ip_address)");
                    $stmt->execute([
                        'user_id' => $user_id,
                        'description' => "Maaş kalemi güncellendi: {$item['name']} (Kod: {$item['code']})",
                        'ip_address' => $_SERVER['REMOTE_ADDR']
                    ]);
                    
                    $success_message = "Maaş kalemi başarıyla güncellendi: {$item['name']}";
                    set_flash_message('payroll_item_success', $success_message, 'success');
                    redirect('payroll_items.php');
                    exit;
                    
                } catch (Exception $e) {
                    $errors['general_edit'] = 'Maaş kalemi güncellenirken bir hata oluştu: ' . $e->getMessage();
                    error_log('Maaş kalemi güncelleme hatası: ' . $e->getMessage());
                }
            }
        }
        // Delete payroll item
        elseif ($action === 'delete' && isset($_POST['item_id'])) {
            $item_id = (int)$_POST['item_id'];
            
            try {
                // Check if item is used in any payroll
                $stmt = $db->prepare("SELECT COUNT(*) FROM payroll_item_values WHERE item_id = :item_id");
                $stmt->execute(['item_id' => $item_id]);
                
                if ($stmt->fetchColumn() > 0) {
                    set_flash_message('payroll_item_error', 'Bu maaş kalemi bordrolarda kullanıldığı için silinemez.', 'danger');
                    redirect('payroll_items.php');
                    exit;
                }
                
                // Get item name for logging
                $stmt = $db->prepare("SELECT name, code FROM payroll_items WHERE id = :item_id");
                $stmt->execute(['item_id' => $item_id]);
                $item_info = $stmt->fetch(PDO::FETCH_ASSOC);
                
                // Delete the item
                $stmt = $db->prepare("DELETE FROM payroll_items WHERE id = :item_id");
                $stmt->execute(['item_id' => $item_id]);
                
                // Log the action
                $stmt = $db->prepare("INSERT INTO activity_logs (user_id, activity_type, description, ip_address) VALUES (:user_id, 'payroll_item_delete', :description, :ip_address)");
                $stmt->execute([
                    'user_id' => $user_id,
                    'description' => "Maaş kalemi silindi: {$item_info['name']} (Kod: {$item_info['code']})",
                    'ip_address' => $_SERVER['REMOTE_ADDR']
                ]);
                
                set_flash_message('payroll_item_success', "Maaş kalemi başarıyla silindi: {$item_info['name']}", 'success');
                redirect('payroll_items.php');
                exit;
                
            } catch (Exception $e) {
                set_flash_message('payroll_item_error', 'Maaş kalemi silinirken bir hata oluştu: ' . $e->getMessage(), 'danger');
                error_log('Maaş kalemi silme hatası: ' . $e->getMessage());
                redirect('payroll_items.php');
                exit;
            }
        }
    }
}

// Get payroll item for editing
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $item_id = (int)$_GET['edit'];
    $stmt = $db->prepare("SELECT * FROM payroll_items WHERE id = :item_id");
    $stmt->execute(['item_id' => $item_id]);
    $edit_item = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($edit_item) {
        $item = $edit_item;
    }
}

// Get all payroll items with pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 10;
$offset = ($page - 1) * $per_page;

// Get total count
$stmt = $db->query("SELECT COUNT(*) FROM payroll_items");
$total_items = $stmt->fetchColumn();
$total_pages = ceil($total_items / $per_page);

// Get items for current page
$sql = "SELECT * FROM payroll_items ORDER BY type, name LIMIT :offset, :per_page";
$stmt = $db->prepare($sql);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->bindValue(':per_page', $per_page, PDO::PARAM_INT);
$stmt->execute();
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Include header
include 'includes/header.php';
?>

<div class="flex h-screen bg-gray-100">
    <!-- Sidebar -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- Main Content -->
    <div class="flex-1 overflow-auto ml-0 lg:ml-64 pt-16">
        <div class="py-6 px-8">
            <!-- Page Header -->
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold text-gray-800">Maaş Kalemleri</h1>
                <nav class="flex" aria-label="Breadcrumb">
                    <ol class="inline-flex items-center space-x-1 md:space-x-3">
                        <li class="inline-flex items-center">
                            <a href="index.php" class="text-gray-700 hover:text-gray-900 inline-flex items-center">
                                <svg class="w-5 h-5 mr-2.5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"></path>
                                </svg>
                                Dashboard
                            </a>
                        </li>
                        <li>
                            <div class="flex items-center">
                                <svg class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span class="ml-1 text-gray-500 md:ml-2">Maaş Kalemleri</span>
                            </div>
                        </li>
                    </ol>
                </nav>
            </div>
            
            <!-- Flash Messages -->
            <?php if (isset($_SESSION['flash_messages']['payroll_item_success'])): ?>
                <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6" role="alert">
                    <p><?php echo $_SESSION['flash_messages']['payroll_item_success']['message']; ?></p>
                </div>
                <?php unset($_SESSION['flash_messages']['payroll_item_success']); ?>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['flash_messages']['payroll_item_error'])): ?>
                <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                    <p><?php echo $_SESSION['flash_messages']['payroll_item_error']['message']; ?></p>
                </div>
                <?php unset($_SESSION['flash_messages']['payroll_item_error']); ?>
            <?php endif; ?>
            
            <?php if (isset($errors['general'])): ?>
                <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                    <p><?php echo $errors['general']; ?></p>
                </div>
            <?php endif; ?>
            
            <!-- Add/Edit Payroll Item Form -->
            <div class="bg-white shadow-md rounded-lg overflow-hidden mb-6">
                <div class="px-6 py-4 border-b border-gray-200 bg-gray-50">
                    <h3 class="text-lg font-semibold text-gray-800">
                        <?php echo isset($_GET['edit']) ? 'Maaş Kalemi Düzenle' : 'Yeni Maaş Kalemi Ekle'; ?>
                    </h3>
                </div>
                <div class="p-6">
                    <form method="POST" action="payroll_items.php">
                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                        <input type="hidden" name="action" value="<?php echo isset($_GET['edit']) ? 'edit' : 'add'; ?>">
                        <?php if (isset($_GET['edit'])): ?>
                            <input type="hidden" name="item_id" value="<?php echo (int)$_GET['edit']; ?>">
                        <?php endif; ?>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label for="name" class="block text-sm font-medium text-gray-700">Kalem Adı <span class="text-red-500">*</span></label>
                                <input type="text" name="name" id="name" value="<?php echo htmlspecialchars($item['name']); ?>" required class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md <?php echo isset($errors['name']) ? 'border-red-300' : ''; ?>">
                                <?php if (isset($errors['name'])): ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo $errors['name']; ?></p>
                                <?php endif; ?>
                            </div>
                            
                            <div>
                                <label for="code" class="block text-sm font-medium text-gray-700">Kalem Kodu <span class="text-red-500">*</span></label>
                                <input type="text" name="code" id="code" value="<?php echo htmlspecialchars($item['code']); ?>" required class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md <?php echo isset($errors['code']) ? 'border-red-300' : ''; ?>">
                                <?php if (isset($errors['code'])): ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo $errors['code']; ?></p>
                                <?php endif; ?>
                            </div>
                            
                            <div>
                                <label for="type" class="block text-sm font-medium text-gray-700">Kalem Tipi</label>
                                <select name="type" id="type" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                    <option value="earning" <?php echo $item['type'] === 'earning' ? 'selected' : ''; ?>>Kazanç</option>
                                    <option value="deduction" <?php echo $item['type'] === 'deduction' ? 'selected' : ''; ?>>Kesinti</option>
                                </select>
                            </div>
                            
                            <div>
                                <label for="default_amount" class="block text-sm font-medium text-gray-700">Varsayılan Tutar</label>
                                <div class="mt-1 relative rounded-md shadow-sm">
                                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                        <span class="text-gray-500 sm:text-sm">₺</span>
                                    </div>
                                    <input type="text" name="default_amount" id="default_amount" value="<?php echo number_format($item['default_amount'], 2, '.', ''); ?>" class="focus:ring-blue-500 focus:border-blue-500 block w-full pl-7 pr-12 sm:text-sm border-gray-300 rounded-md">
                                </div>
                            </div>
                            
                            <div class="col-span-2">
                                <label for="description" class="block text-sm font-medium text-gray-700">Açıklama</label>
                                <textarea name="description" id="description" rows="3" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"><?php echo htmlspecialchars($item['description']); ?></textarea>
                            </div>
                            
                            <div>
                                <div class="flex items-start">
                                    <div class="flex items-center h-5">
                                        <input type="checkbox" name="is_taxable" id="is_taxable" <?php echo $item['is_taxable'] ? 'checked' : ''; ?> class="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300 rounded">
                                    </div>
                                    <div class="ml-3 text-sm">
                                        <label for="is_taxable" class="font-medium text-gray-700">Vergilendirilebilir</label>
                                        <p class="text-gray-500">Bu kalem vergi hesaplamasına dahil edilir.</p>
                                    </div>
                                </div>
                            </div>
                            
                            <div>
                                <div class="flex items-start">
                                    <div class="flex items-center h-5">
                                        <input type="checkbox" name="is_fixed" id="is_fixed" <?php echo $item['is_fixed'] ? 'checked' : ''; ?> class="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300 rounded">
                                    </div>
                                    <div class="ml-3 text-sm">
                                        <label for="is_fixed" class="font-medium text-gray-700">Sabit Tutar</label>
                                        <p class="text-gray-500">Bu kalem sabit bir tutardır, maaşa göre hesaplanmaz.</p>
                                    </div>
                                </div>
                            </div>
                            
                            <div>
                                <label for="status" class="block text-sm font-medium text-gray-700">Durum</label>
                                <select name="status" id="status" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                    <option value="active" <?php echo $item['status'] === 'active' ? 'selected' : ''; ?>>Aktif</option>
                                    <option value="inactive" <?php echo $item['status'] === 'inactive' ? 'selected' : ''; ?>>Pasif</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="mt-6 flex items-center justify-end">
                            <?php if (isset($_GET['edit'])): ?>
                                <a href="payroll_items.php" class="mr-3 inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                    İptal
                                </a>
                                <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                    Güncelle
                                </button>
                            <?php else: ?>
                                <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                    Kaydet
                                </button>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Payroll Items Table -->
            <div class="bg-white shadow-md rounded-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h3 class="text-lg font-semibold text-gray-800">Maaş Kalemleri Listesi</h3>
                </div>
                
                <?php if (count($items) > 0): ?>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Kalem Adı
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Kod
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Tip
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Varsayılan Tutar
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Vergilendirilebilir
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Sabit
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Durum
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        İşlemler
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php foreach ($items as $item_row): ?>
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($item_row['name']); ?></div>
                                            <?php if (!empty($item_row['description'])): ?>
                                                <div class="text-xs text-gray-500"><?php echo htmlspecialchars(substr($item_row['description'], 0, 50)) . (strlen($item_row['description']) > 50 ? '...' : ''); ?></div>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm text-gray-900"><?php echo htmlspecialchars($item_row['code']); ?></div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                                <?php echo $item_row['type'] === 'earning' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                                                <?php echo $item_row['type'] === 'earning' ? 'Kazanç' : 'Kesinti'; ?>
                                            </span>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            <?php echo number_format($item_row['default_amount'], 2, ',', '.'); ?> ₺
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">
                                        <?php if ($item_row['is_taxable']): ?>
                                                <svg class="h-5 w-5 text-green-500 mx-auto" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd" />
                                                </svg>
                                            <?php else: ?>
                                                <svg class="h-5 w-5 text-gray-400 mx-auto" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                                    <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                                                </svg>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">
                                            <?php if ($item_row['is_fixed']): ?>
                                                <svg class="h-5 w-5 text-green-500 mx-auto" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd" />
                                                </svg>
                                            <?php else: ?>
                                                <svg class="h-5 w-5 text-gray-400 mx-auto" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                                    <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                                                </svg>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-center">
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                                <?php echo $item_row['status'] === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'; ?>">
                                                <?php echo $item_row['status'] === 'active' ? 'Aktif' : 'Pasif'; ?>
                                            </span>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                            <div class="flex justify-end space-x-2">
                                                <a href="payroll_items.php?edit=<?php echo $item_row['id']; ?>" class="text-blue-600 hover:text-blue-900" title="Düzenle">
                                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"></path>
                                                    </svg>
                                                </a>
                                                <button type="button" class="text-red-600 hover:text-red-900 delete-item-btn" 
                                                        data-id="<?php echo $item_row['id']; ?>"
                                                        data-name="<?php echo htmlspecialchars($item_row['name']); ?>"
                                                        title="Sil">
                                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                                    </svg>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <div class="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200 sm:px-6">
                            <div class="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
                                <div>
                                    <p class="text-sm text-gray-700">
                                        <span class="font-medium"><?php echo ($offset + 1); ?></span> - 
                                        <span class="font-medium"><?php echo min($offset + $per_page, $total_items); ?></span> / 
                                        <span class="font-medium"><?php echo $total_items; ?></span> kayıt gösteriliyor
                                    </p>
                                </div>
                                <div>
                                    <nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                                        <?php if ($page > 1): ?>
                                            <a href="?page=<?php echo ($page - 1); ?>" class="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                                                <span class="sr-only">Önceki</span>
                                                <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                                    <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />
                                                </svg>
                                            </a>
                                        <?php endif; ?>
                                        
                                        <?php
                                        $start_page = max(1, $page - 2);
                                        $end_page = min($total_pages, $page + 2);
                                        
                                        for ($i = $start_page; $i <= $end_page; $i++):
                                        ?>
                                            <a href="?page=<?php echo $i; ?>" class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium <?php echo $i === $page ? 'text-blue-600 bg-blue-50' : 'text-gray-700 hover:bg-gray-50'; ?>">
                                                <?php echo $i; ?>
                                            </a>
                                        <?php endfor; ?>
                                        
                                        <?php if ($page < $total_pages): ?>
                                            <a href="?page=<?php echo ($page + 1); ?>" class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                                                <span class="sr-only">Sonraki</span>
                                                <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                                    <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" />
                                                </svg>
                                            </a>
                                        <?php endif; ?>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                <?php else: ?>
                    <div class="p-6 text-center">
                        <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                        </svg>
                        <h3 class="mt-2 text-sm font-medium text-gray-900">Maaş Kalemi Bulunamadı</h3>
                        <p class="mt-1 text-sm text-gray-500">Henüz hiç maaş kalemi oluşturulmamış.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Delete Item Modal -->
<div id="deleteItemModal" class="fixed z-10 inset-0 overflow-y-auto hidden">
    <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div class="fixed inset-0 transition-opacity" aria-hidden="true">
            <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
        </div>
        <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
        <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
            <form method="POST" action="payroll_items.php">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="item_id" id="delete_item_id">
                
                <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                    <div class="sm:flex sm:items-start">
                        <div class="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-red-100 sm:mx-0 sm:h-10 sm:w-10">
                            <svg class="h-6 w-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
                            </svg>
                        </div>
                        <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                            <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                                Maaş Kalemini Sil
                            </h3>
                            <div class="mt-2">
                                <p class="text-sm text-gray-500">
                                    <span id="delete_item_name"></span> kalemini silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <button type="submit" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-red-600 text-base font-medium text-white hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 sm:ml-3 sm:w-auto sm:text-sm">
                        Sil
                    </button>
                    <button type="button" id="closeDeleteModal" class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">
                        İptal
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Format currency input
        const defaultAmountInput = document.getElementById('default_amount');
        if (defaultAmountInput) {
            defaultAmountInput.addEventListener('blur', function(e) {
                const value = e.target.value.replace(/[^\d.]/g, '');
                if (value && !isNaN(parseFloat(value))) {
                    e.target.value = parseFloat(value).toFixed(2);
                } else {
                    e.target.value = '0.00';
                }
            });
        }
        
        // Delete Item Modal
        const deleteItemModal = document.getElementById('deleteItemModal');
        const deleteItemBtns = document.querySelectorAll('.delete-item-btn');
        const closeDeleteModal = document.getElementById('closeDeleteModal');
        const deleteItemId = document.getElementById('delete_item_id');
        const deleteItemName = document.getElementById('delete_item_name');
        
        function openDeleteModal(event) {
            const button = event.currentTarget;
            const id = button.getAttribute('data-id');
            const name = button.getAttribute('data-name');
            
            deleteItemId.value = id;
            deleteItemName.textContent = name;
            
            deleteItemModal.classList.remove('hidden');
        }
        
        function closeDeleteModalFunc() {
            deleteItemModal.classList.add('hidden');
        }
        
        deleteItemBtns.forEach(button => {
            button.addEventListener('click', openDeleteModal);
        });
        
        if (closeDeleteModal) {
            closeDeleteModal.addEventListener('click', closeDeleteModalFunc);
        }
        
        // Close modal when clicking outside
        window.addEventListener('click', function(event) {
            if (event.target === deleteItemModal) {
                closeDeleteModalFunc();
            }
        });
        
        // Auto-generate code from name
        const nameInput = document.getElementById('name');
        const codeInput = document.getElementById('code');
        
        if (nameInput && codeInput && codeInput.value === '') {
            nameInput.addEventListener('blur', function() {
                if (codeInput.value === '') {
                    // Convert name to uppercase code (remove spaces, special chars)
                    let code = nameInput.value.toUpperCase()
                        .replace(/[^A-Z0-9]/g, '')
                        .substring(0, 10);
                    
                    if (code) {
                        codeInput.value = code;
                    }
                }
            });
        }
    });
</script>

<?php include 'includes/footer.php'; ?>