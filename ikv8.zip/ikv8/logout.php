<?php
// Logout page
session_start();

// Load configuration
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';

// Delete remember me token if exists
if (isset($_COOKIE['remember_me_token'])) {
    $database = new Database();
    $db = $database->connect();
    
    $token = $_COOKIE['remember_me_token'];
    $stmt = $db->prepare("DELETE FROM remember_me_tokens WHERE token = :token");
    $stmt->execute(['token' => $token]);
    
    // Delete cookie
    setcookie('remember_me_token', '', time() - 3600, '/', '', false, true);
}

// Log out user
logout_user();

// Redirect to login page
redirect('login.php');