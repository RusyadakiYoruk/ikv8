<?php
// Export Employees to Excel
session_start();

// Load configuration and dependencies
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;

// Check if user is logged in and has admin or manager role
require_role(['admin', 'manager']);

// Get filters from URL parameters
$department_filter = isset($_GET['department']) ? (int)$_GET['department'] : 0;
$status_filter = isset($_GET['status']) ? sanitize($_GET['status']) : 'all';
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';

// Connect to database
$database = new Database();
$db = $database->connect();

// Build query conditions
$conditions = [];
$params = [];

if ($department_filter > 0) {
    $conditions[] = "e.department_id = :department";
    $params['department'] = $department_filter;
}

if ($status_filter === 'active') {
    $conditions[] = "(e.termination_date IS NULL OR e.termination_date > CURDATE())";
} elseif ($status_filter === 'terminated') {
    $conditions[] = "e.termination_date IS NOT NULL AND e.termination_date <= CURDATE()";
}

if (!empty($search)) {
    $conditions[] = "(e.first_name LIKE :search OR e.last_name LIKE :search OR e.phone LIKE :search)";
    $params['search'] = "%{$search}%";
}

$where_clause = !empty($conditions) ? "WHERE " . implode(" AND ", $conditions) : "";

// Get employees data
$sql = "SELECT 
            e.id,
            e.first_name,
            e.last_name,
            e.phone,
            u.email, -- e.email yerine u.email kullanıyoruz
            d.name as department_name,
            b.name as branch_name,
            jt.title as job_title,
            e.hire_date,
            e.termination_date,
            e.employment_type,
            e.salary_type,
            e.salary_amount,
            CONCAT(m.first_name, ' ', m.last_name) as manager_name
        FROM employees e
        LEFT JOIN users u ON e.user_id = u.id -- users tablosu ile join eklendi
        LEFT JOIN departments d ON e.department_id = d.id
        LEFT JOIN branches b ON e.branch_id = b.id
        LEFT JOIN job_titles jt ON e.job_title_id = jt.id
        LEFT JOIN employees m ON e.manager_id = m.id
        {$where_clause}
        ORDER BY e.id DESC";

$stmt = $db->prepare($sql);
foreach ($params as $key => $value) {
    $stmt->bindValue(':' . $key, $value);
}
$stmt->execute();
$employees = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Create new Spreadsheet object
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Set document properties
$spreadsheet->getProperties()
    ->setCreator('İK Yönetim Portalı')
    ->setLastModifiedBy('İK Yönetim Portalı')
    ->setTitle('Çalışan Listesi')
    ->setSubject('Çalışan Listesi')
    ->setDescription('İK Yönetim Portalı Çalışan Listesi');

// Add company logo
$drawing = new \PhpOffice\PhpSpreadsheet\Worksheet\Drawing();
$drawing->setName('Logo');
$drawing->setDescription('Logo');
$drawing->setPath('assets/img/logo.jpg'); // Logo yolunu kendi yapınıza göre ayarlayın
$drawing->setHeight(50);
$drawing->setCoordinates('A1');
$drawing->setWorksheet($sheet);

// Set header row
$sheet->setCellValue('A3', 'ID');
$sheet->setCellValue('B3', 'Ad');
$sheet->setCellValue('C3', 'Soyad');
$sheet->setCellValue('D3', 'Telefon');
$sheet->setCellValue('E3', 'E-posta');
$sheet->setCellValue('F3', 'Departman');
$sheet->setCellValue('G3', 'Şube');
$sheet->setCellValue('H3', 'Pozisyon');
$sheet->setCellValue('I3', 'İşe Giriş');
$sheet->setCellValue('J3', 'İşten Çıkış');
$sheet->setCellValue('K3', 'İstihdam Türü');
$sheet->setCellValue('L3', 'Maaş Türü');
$sheet->setCellValue('M3', 'Maaş');
$sheet->setCellValue('N3', 'Yönetici');

// Style the header row
$headerStyle = [
    'font' => [
        'bold' => true,
        'color' => ['rgb' => 'FFFFFF'],
    ],
    'fill' => [
        'fillType' => Fill::FILL_SOLID,
        'startColor' => ['rgb' => '4A90E2'],
    ],
    'alignment' => [
        'horizontal' => Alignment::HORIZONTAL_CENTER,
        'vertical' => Alignment::VERTICAL_CENTER,
    ],
    'borders' => [
        'allBorders' => [
            'borderStyle' => Border::BORDER_THIN,
            'color' => ['rgb' => '000000'],
        ],
    ],
];

$sheet->getStyle('A3:N3')->applyFromArray($headerStyle);
$sheet->getRowDimension(3)->setRowHeight(30);

// Add data rows
$row = 4;
foreach ($employees as $employee) {
    $sheet->setCellValue('A' . $row, $employee['id']);
    $sheet->setCellValue('B' . $row, $employee['first_name']);
    $sheet->setCellValue('C' . $row, $employee['last_name']);
    $sheet->setCellValue('D' . $row, $employee['phone']);
    $sheet->setCellValue('E' . $row, $employee['email']);
    $sheet->setCellValue('F' . $row, $employee['department_name']);
    $sheet->setCellValue('G' . $row, $employee['branch_name']);
    $sheet->setCellValue('H' . $row, $employee['job_title']);
    $sheet->setCellValue('I' . $row, date('d.m.Y', strtotime($employee['hire_date'])));
    $sheet->setCellValue('J' . $row, !empty($employee['termination_date']) ? date('d.m.Y', strtotime($employee['termination_date'])) : '-');
    
    // Convert employment type to Turkish
    $empType = '';
    switch ($employee['employment_type']) {
        case 'full-time':
            $empType = 'Tam Zamanlı';
            break;
        case 'part-time':
            $empType = 'Yarı Zamanlı';
            break;
        case 'contract':
            $empType = 'Sözleşmeli';
            break;
        case 'temporary':
            $empType = 'Geçici';
            break;
        default:
            $empType = $employee['employment_type'];
    }
    $sheet->setCellValue('K' . $row, $empType);
    
    // Convert salary type to Turkish
    $salType = $employee['salary_type'] === 'monthly' ? 'Aylık' : 'Saatlik';
    $sheet->setCellValue('L' . $row, $salType);
    
    $sheet->setCellValue('M' . $row, number_format($employee['salary_amount'], 2, ',', '.') . ' ₺');
    $sheet->setCellValue('N' . $row, $employee['manager_name'] ?? '-');
    
    $row++;
}

// Style data rows
$dataStyle = [
    'borders' => [
        'allBorders' => [
            'borderStyle' => Border::BORDER_THIN,
            'color' => ['rgb' => '000000'],
        ],
    ],
    'alignment' => [
        'vertical' => Alignment::VERTICAL_CENTER,
    ],
];

$sheet->getStyle('A4:N' . ($row - 1))->applyFromArray($dataStyle);

// Auto-size columns
foreach (range('A', 'N') as $column) {
    $sheet->getColumnDimension($column)->setAutoSize(true);
}

// Set title
$sheet->mergeCells('A1:N1');
$sheet->setCellValue('A1', 'ÇALIŞAN LİSTESİ');
$sheet->getStyle('A1')->getFont()->setSize(16)->setBold(true);
$sheet->getStyle('A1')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

// Set filters description
$filterDesc = [];
if ($department_filter > 0) {
    $stmt = $db->prepare("SELECT name FROM departments WHERE id = ?");
    $stmt->execute([$department_filter]);
    $deptName = $stmt->fetchColumn();
    $filterDesc[] = "Departman: " . $deptName;
}
if ($status_filter !== 'all') {
    $filterDesc[] = "Durum: " . ($status_filter === 'active' ? 'Aktif' : 'İşten Çıkmış');
}
if (!empty($search)) {
    $filterDesc[] = "Arama: " . $search;
}

if (!empty($filterDesc)) {
    $sheet->mergeCells('A2:N2');
    $sheet->setCellValue('A2', 'Filtreler: ' . implode(' | ', $filterDesc));
    $sheet->getStyle('A2')->getFont()->setItalic(true);
}

// Create Excel file
$writer = new Xlsx($spreadsheet);

// Set headers for download
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="calisanlar_' . date('Y-m-d_His') . '.xlsx"');
header('Cache-Control: max-age=0');

// Save file to PHP output
$writer->save('php://output');
exit;
?>