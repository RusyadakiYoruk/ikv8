<?php
// Çalışan tablosunu güncellemek için migration script
// Bu script, eksik sütunları kontrol eder ve ekler

// Konfigürasyon dosyalarını yükle
require_once '../config/config.php';
require_once '../config/database.php';

class EmployeeTableMigration {
    private $db;
    private $requiredColumns = [
        'first_name' => 'VARCHAR(100) NOT NULL',
        'last_name' => 'VARCHAR(100) NOT NULL',
        'middle_name' => 'VARCHAR(100) NULL',
        'birth_date' => 'DATE NULL',
        'gender' => 'ENUM("male", "female", "other") NULL',
        'nationality' => 'VARCHAR(100) NULL',
        'passport_number' => 'VARCHAR(50) NULL',
        'passport_expiry' => 'DATE NULL',
        'address' => 'TEXT NULL',
        'phone' => 'VARCHAR(50) NULL',
        'emergency_contact_name' => 'VARCHAR(200) NULL',
        'emergency_contact_phone' => 'VARCHAR(50) NULL',
        'hire_date' => 'DATE NOT NULL',
        'termination_date' => 'DATE NULL',
        'department_id' => 'INT NULL',
        'branch_id' => 'INT NULL',
        'job_title_id' => 'INT NULL',
        'manager_id' => 'INT NULL',
        'employment_type' => 'ENUM("full-time", "part-time", "contract", "temporary") DEFAULT "full-time"',
        'salary_type' => 'ENUM("hourly", "monthly") DEFAULT "monthly"',
        'salary_amount' => 'DECIMAL(15, 2) NULL',
        'bank_account' => 'VARCHAR(100) NULL',
        'tax_id' => 'VARCHAR(100) NULL',
        'social_security_number' => 'VARCHAR(100) NULL',
        'notes' => 'TEXT NULL'
    ];

    public function __construct() {
        $database = new Database();
        $this->db = $database->connect();
    }

    public function run() {
        try {
            echo "Çalışan tablosu güncelleme işlemi başlatılıyor...\n";
            
            // Tablo var mı kontrol et
            if (!$this->tableExists('employees')) {
                echo "Çalışan tablosu bulunamadı. Tablo oluşturuluyor...\n";
                $this->createEmployeesTable();
                echo "Çalışan tablosu başarıyla oluşturuldu.\n";
                return;
            }
            
            // Mevcut sütunları al
            $existingColumns = $this->getExistingColumns('employees');
            
            // Eksik sütunları kontrol et ve ekle
            foreach ($this->requiredColumns as $column => $definition) {
                if (!in_array($column, $existingColumns)) {
                    echo "Eksik sütun: {$column} - Ekleniyor...\n";
                    $this->addColumn('employees', $column, $definition);
                    echo "{$column} sütunu başarıyla eklendi.\n";
                } else {
                    echo "{$column} sütunu zaten mevcut.\n";
                }
            }
            
            // İlişkili tabloları kontrol et
            $this->checkRelatedTables();
            
            echo "Çalışan tablosu güncelleme işlemi tamamlandı.\n";
            
        } catch (Exception $e) {
            echo "Hata: " . $e->getMessage() . "\n";
        }
    }
    
    private function tableExists($table) {
        $stmt = $this->db->prepare("SHOW TABLES LIKE :table");
        $stmt->execute(['table' => $table]);
        return $stmt->rowCount() > 0;
    }
    
    private function getExistingColumns($table) {
        $stmt = $this->db->prepare("SHOW COLUMNS FROM {$table}");
        $stmt->execute();
        $columns = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $columns[] = $row['Field'];
        }
        return $columns;
    }
    
    private function addColumn($table, $column, $definition) {
        $sql = "ALTER TABLE {$table} ADD COLUMN {$column} {$definition}";
        $this->db->exec($sql);
    }
    
    private function createEmployeesTable() {
        $sql = "CREATE TABLE employees (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT UNIQUE,
            first_name VARCHAR(100) NOT NULL,
            last_name VARCHAR(100) NOT NULL,
            middle_name VARCHAR(100) NULL,
            birth_date DATE NULL,
            gender ENUM('male', 'female', 'other') NULL,
            nationality VARCHAR(100) NULL,
            passport_number VARCHAR(50) NULL,
            passport_expiry DATE NULL,
            address TEXT NULL,
            phone VARCHAR(50) NULL,
            emergency_contact_name VARCHAR(200) NULL,
            emergency_contact_phone VARCHAR(50) NULL,
            hire_date DATE NOT NULL,
            termination_date DATE NULL,
            department_id INT NULL,
            branch_id INT NULL,
            job_title_id INT NULL,
            manager_id INT NULL,
            employment_type ENUM('full-time', 'part-time', 'contract', 'temporary') DEFAULT 'full-time',
            salary_type ENUM('hourly', 'monthly') DEFAULT 'monthly',
            salary_amount DECIMAL(15, 2) NULL,
            bank_account VARCHAR(100) NULL,
            tax_id VARCHAR(100) NULL,
            social_security_number VARCHAR(100) NULL,
            notes TEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
            FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
            FOREIGN KEY (job_title_id) REFERENCES job_titles(id) ON DELETE SET NULL,
            FOREIGN KEY (manager_id) REFERENCES employees(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        $this->db->exec($sql);
    }
    
    private function checkRelatedTables() {
        // employee_meta tablosunu kontrol et
        if (!$this->tableExists('employee_meta')) {
            echo "employee_meta tablosu bulunamadı. Tablo oluşturuluyor...\n";
            $this->createEmployeeMetaTable();
            echo "employee_meta tablosu başarıyla oluşturuldu.\n";
        }
        
        // branches tablosunu kontrol et
        if (!$this->tableExists('branches')) {
            echo "branches tablosu bulunamadı. Tablo oluşturuluyor...\n";
            $this->createBranchesTable();
            echo "branches tablosu başarıyla oluşturuldu.\n";
        }
    }
    
    private function createEmployeeMetaTable() {
        $sql = "CREATE TABLE employee_meta (
            id INT AUTO_INCREMENT PRIMARY KEY,
            employee_id INT NOT NULL,
            meta_key VARCHAR(100) NOT NULL,
            meta_value TEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        $this->db->exec($sql);
    }
    
    private function createBranchesTable() {
        $sql = "CREATE TABLE branches (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            address TEXT NULL,
            city VARCHAR(100) NULL,
            country VARCHAR(100) DEFAULT 'Russia',
            phone VARCHAR(50) NULL,
            email VARCHAR(255) NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        $this->db->exec($sql);
        
        // Varsayılan şube ekle
        $sql = "INSERT INTO branches (name, city, country) VALUES ('Merkez Şube', 'Moskova', 'Russia')";
        $this->db->exec($sql);
    }
}

// Migration'ı çalıştır
$migration = new EmployeeTableMigration();
$migration->run();

echo "İşlem tamamlandı!\n";
?>