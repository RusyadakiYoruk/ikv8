<?php
// leave_approval.php
session_start();

// Load configuration
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Connect to database
$database = new Database();
$db = $database->connect();

// Get user role and employee info
$stmt = $db->prepare("
    SELECT u.role, e.id as employee_id, e.job_title_id, jt.title as job_title
    FROM users u
    LEFT JOIN employees e ON u.id = e.user_id
    LEFT JOIN job_titles jt ON e.job_title_id = jt.id
    WHERE u.id = ?
");
$stmt->execute([$_SESSION['user_id']]);
$user_info = $stmt->fetch(PDO::FETCH_ASSOC);

// Check if user is authorized to approve (admin or has "Şef" in job title)
$is_admin = $user_info['role'] === 'admin';
$is_chief = $user_info['job_title'] && (stripos($user_info['job_title'], 'şef') !== false || stripos($user_info['job_title'], 'sef') !== false);

if (!$is_admin && !$is_chief) {
    die("Bu sayfaya erişim yetkiniz bulunmamaktadır.");
}

// Process approval/rejection
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['request_id'])) {
    $request_id = (int)$_POST['request_id'];
    $action = $_POST['action'];
    $comment = $_POST['comment'] ?? '';
    
    try {
        // Begin transaction
        $db->beginTransaction();
        
        // Get request details
        $stmt = $db->prepare("
            SELECT lr.*, e.first_name, e.last_name, lt.name as leave_type, lt.is_paid
            FROM leave_requests lr
            JOIN employees e ON lr.employee_id = e.id
            JOIN leave_types lt ON lr.leave_type_id = lt.id
            WHERE lr.id = ?
        ");
        $stmt->execute([$request_id]);
        $request = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$request) {
            throw new Exception("İzin talebi bulunamadı.");
        }
        
        // Check if user is authorized to approve this request
        if (!$is_admin && $request['approver_type'] !== 'chief') {
            throw new Exception("Bu talebi onaylama yetkiniz bulunmamaktadır.");
        }
        
        if ($action === 'approve') {
            // Update request status
            $stmt = $db->prepare("
                UPDATE leave_requests 
                SET status = 'approved', 
                    approved_by = ?, 
                    approval_date = NOW(),
                    comments = ?
                WHERE id = ?
            ");
            $stmt->execute([$_SESSION['user_id'], $comment, $request_id]);
            
            // If paid leave, update employee leave balance
            if ($request['is_paid']) {
                // Check if balance record exists for this year
                $stmt = $db->prepare("
                    SELECT id, used_days 
                    FROM employee_leave_balances 
                    WHERE employee_id = ? AND leave_type_id = ? AND year = YEAR(CURRENT_DATE)
                ");
                $stmt->execute([$request['employee_id'], $request['leave_type_id']]);
                $balance = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($balance) {
                    // Update existing balance
                    $stmt = $db->prepare("
                        UPDATE employee_leave_balances 
                        SET used_days = used_days + ? 
                        WHERE id = ?
                    ");
                    $stmt->execute([$request['total_days'], $balance['id']]);
                } else {
                    // Get default days from leave type
                    $stmt = $db->prepare("SELECT default_days FROM leave_types WHERE id = ?");
                    $stmt->execute([$request['leave_type_id']]);
                    $default_days = $stmt->fetchColumn();
                    
                    // Create new balance record
                    $stmt = $db->prepare("
                        INSERT INTO employee_leave_balances (
                            employee_id, leave_type_id, year, total_days, used_days
                        ) VALUES (?, ?, YEAR(CURRENT_DATE), ?, ?)
                    ");
                    $stmt->execute([
                        $request['employee_id'], 
                        $request['leave_type_id'], 
                        $default_days, 
                        $request['total_days']
                    ]);
                }
            }
            
            // Send notification to employee
            $stmt = $db->prepare("
                INSERT INTO notifications (
                    user_id, type, title, message, related_id, is_read
                ) VALUES (
                    (SELECT user_id FROM employees WHERE id = ?),
                    'leave_approved',
                    'İzin Talebi Onaylandı',
                    ?,
                    ?,
                    0
                )
            ");
            $stmt->execute([
                $request['employee_id'],
                "İzin talebiniz onaylandı. Başlangıç: " . date('d.m.Y', strtotime($request['start_date'])) . ", Bitiş: " . date('d.m.Y', strtotime($request['end_date'])),
                $request_id
            ]);
            
            // Log activity
            $stmt = $db->prepare("
                INSERT INTO activity_logs (
                    user_id, activity_type, description, ip_address
                ) VALUES (?, 'leave_approved', ?, ?)
            ");
            $stmt->execute([
                $_SESSION['user_id'],
                "İzin talebi onaylandı (ID: $request_id, Çalışan: {$request['first_name']} {$request['last_name']})",
                $_SERVER['REMOTE_ADDR']
            ]);
            
            $message = "İzin talebi başarıyla onaylandı.";
        } elseif ($action === 'reject') {
            // Update request status
            $stmt = $db->prepare("
                UPDATE leave_requests 
                SET status = 'rejected', 
                    approved_by = ?, 
                    approval_date = NOW(),
                    rejection_reason = ?
                WHERE id = ?
            ");
            $stmt->execute([$_SESSION['user_id'], $comment, $request_id]);
            
            // Send notification to employee
            $stmt = $db->prepare("
                INSERT INTO notifications (
                    user_id, type, title, message, related_id, is_read
                ) VALUES (
                    (SELECT user_id FROM employees WHERE id = ?),
                    'leave_rejected',
                    'İzin Talebi Reddedildi',
                    ?,
                    ?,
                    0
                )
            ");
            $stmt->execute([
                $request['employee_id'],
                "İzin talebiniz reddedildi. Neden: " . ($comment ?: 'Belirtilmemiş'),
                $request_id
            ]);
            
            // Log activity
            $stmt = $db->prepare("
                INSERT INTO activity_logs (
                    user_id, activity_type, description, ip_address
                ) VALUES (?, 'leave_rejected', ?, ?)
            ");
            $stmt->execute([
                $_SESSION['user_id'],
                "İzin talebi reddedildi (ID: $request_id, Çalışan: {$request['first_name']} {$request['last_name']})",
                $_SERVER['REMOTE_ADDR']
            ]);
            
            $message = "İzin talebi reddedildi.";
        }
        
        // Commit transaction
        $db->commit();
        
        // Set success message
        set_flash_message('success', $message);
        
        // Redirect to prevent form resubmission
        header('Location: leave_approval.php');
        exit;
        
    } catch (Exception $e) {
        // Rollback transaction
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        
        // Set error message
        set_flash_message('error', $e->getMessage());
    }
}

// Get pending leave requests for approval
$sql = "
    SELECT 
        lr.id, 
        lr.employee_id,
        e.first_name,
        e.last_name,
        d.name as department_name,
        jt.title as job_title,
        lt.name as leave_type,
        lt.is_paid,
        lr.start_date,
        lr.end_date,
        lr.total_days,
        lr.reason,
        lr.contact_info,
        lr.created_at
    FROM leave_requests lr
    JOIN employees e ON lr.employee_id = e.id
    JOIN departments d ON e.department_id = d.id
    JOIN job_titles jt ON e.job_title_id = jt.id
    JOIN leave_types lt ON lr.leave_type_id = lt.id
    WHERE lr.status = 'pending'
";

// Filter by approver
if ($is_admin) {
    $sql .= " AND (lr.approver_type = 'admin' OR lr.approver_id = ?)";
    $params = [$_SESSION['user_id']];
} else {
    $sql .= " AND lr.approver_type = 'chief' AND lr.approver_id = ?";
    $params = [$_SESSION['user_id']];
}

$sql .= " ORDER BY lr.created_at DESC";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$pending_requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Include header
include 'includes/header.php';
?>

<div class="flex h-screen bg-gray-100">
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="flex-1 overflow-auto ml-0 lg:ml-64 pt-16">
        <div class="p-6">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-semibold text-gray-900">İzin Onay Sayfası</h1>
                <a href="leave_requests.php" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded inline-flex items-center">
                    <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                    </svg>
                    Tüm İzin Talepleri
                </a>
            </div>
            
            <?php if (isset($_SESSION['flash_messages'])): ?>
                <?php foreach ($_SESSION['flash_messages'] as $type => $message): ?>
                    <div class="mb-4 p-4 rounded <?= $type === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' ?>">
                        <?= $message['message'] ?>
                    </div>
                <?php endforeach; ?>
                <?php unset($_SESSION['flash_messages']); ?>
            <?php endif; ?>
            
            <?php if (empty($pending_requests)): ?>
                <div class="bg-white shadow-md rounded-lg p-6 text-center">
                    <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                    </svg>
                    <h3 class="mt-2 text-sm font-medium text-gray-900">Onay Bekleyen İzin Talebi Yok</h3>
                    <p class="mt-1 text-sm text-gray-500">Şu anda onayınızı bekleyen herhangi bir izin talebi bulunmamaktadır.</p>
                </div>
            <?php else: ?>
                <div class="bg-white shadow-md rounded-lg overflow-hidden">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Çalışan</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Departman</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">İzin Türü</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tarih Aralığı</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Gün</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Talep Tarihi</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">İşlemler</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($pending_requests as $request): ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm font-medium text-gray-900">
                                            <?= htmlspecialchars($request['first_name'] . ' ' . $request['last_name']) ?>
                                        </div>
                                        <div class="text-sm text-gray-500">
                                            <?= htmlspecialchars($request['job_title']) ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-900">
                                            <?= htmlspecialchars($request['department_name']) ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-900">
                                            <?= htmlspecialchars($request['leave_type']) ?>
                                            <?= $request['is_paid'] ? ' (Ücretli)' : ' (Ücretsiz)' ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-900">
                                            <?= date('d.m.Y', strtotime($request['start_date'])) ?> - 
                                            <?= date('d.m.Y', strtotime($request['end_date'])) ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-900">
                                            <?= $request['total_days'] ?> gün
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-900">
                                            <?= date('d.m.Y H:i', strtotime($request['created_at'])) ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <button onclick="showRequestDetails(<?= htmlspecialchars(json_encode($request)) ?>)" 
                                                class="text-blue-600 hover:text-blue-900 mr-3">
                                            Detay
                                        </button>
                                        <button onclick="showApproveModal(<?= $request['id'] ?>)" 
                                                class="text-green-600 hover:text-green-900 mr-3">
                                            Onayla
                                        </button>
                                        <button onclick="showRejectModal(<?= $request['id'] ?>)" 
                                                class="text-red-600 hover:text-red-900">
                                            Reddet
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Request Details Modal -->
<div id="detailsModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">İzin Talebi Detayları</h3>
            <div id="requestDetails" class="space-y-3">
                <!-- JavaScript ile doldurulacak -->
            </div>
            <div class="mt-5 flex justify-end">
                <button onclick="closeDetailsModal()" 
                        class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded">
                    Kapat
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Approve Modal -->
<div id="approveModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">İzin Talebini Onayla</h3>
            <form id="approveForm" method="POST">
                <input type="hidden" name="action" value="approve">
                <input type="hidden" name="request_id" id="approve_request_id">
                
                <div class="mb-4">
                    <label for="approve_comment" class="block text-sm font-medium text-gray-700 mb-1">Açıklama</label>
                    <textarea id="approve_comment" name="comment" rows="3" 
                              class="shadow-sm focus:ring-blue-500 focus:border-blue-500 mt-1 block w-full sm:text-sm border border-gray-300 rounded-md"
                              placeholder="Varsa eklemek istediğiniz not..."></textarea>
                </div>
                
                <div class="flex justify-end">
                    <button type="button" onclick="closeApproveModal()" 
                            class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded mr-2">
                        İptal
                    </button>
                    <button type="submit" 
                            class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                        Onayla
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Reject Modal -->
<div id="rejectModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">İzin Talebini Reddet</h3>
            <form id="rejectForm" method="POST">
                <input type="hidden" name="action" value="reject">
                <input type="hidden" name="request_id" id="reject_request_id">
                
                <div class="mb-4">
                    <label for="reject_comment" class="block text-sm font-medium text-gray-700 mb-1">Red Nedeni <span class="text-red-500">*</span></label>
                    <textarea id="reject_comment" name="comment" rows="3" required
                              class="shadow-sm focus:ring-blue-500 focus:border-blue-500 mt-1 block w-full sm:text-sm border border-gray-300 rounded-md"
                              placeholder="Red nedenini açıklayın..."></textarea>
                </div>
                
                <div class="flex justify-end">
                    <button type="button" onclick="closeRejectModal()" 
                            class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded mr-2">
                        İptal
                    </button>
                    <button type="submit" 
                            class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                        Reddet
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function showRequestDetails(request) {
    const detailsDiv = document.getElementById('requestDetails');
    detailsDiv.innerHTML = `
        <p><strong>Çalışan:</strong> ${request.first_name} ${request.last_name}</p>
        <p><strong>Departman:</strong> ${request.department_name}</p>
        <p><strong>Unvan:</strong> ${request.job_title}</p>
        <p><strong>İzin Türü:</strong> ${request.leave_type} ${request.is_paid ? '(Ücretli)' : '(Ücretsiz)'}</p>
        <p><strong>Başlangıç:</strong> ${formatDate(request.start_date)}</p>
        <p><strong>Bitiş:</strong> ${formatDate(request.end_date)}</p>
        <p><strong>Toplam Gün:</strong> ${request.total_days} gün</p>
        ${request.reason ? `<p><strong>İzin Nedeni:</strong> ${request.reason}</p>` : ''}
        ${request.contact_info ? `<p><strong>İletişim Bilgisi:</strong> ${request.contact_info}</p>` : ''}
        <p><strong>Talep Tarihi:</strong> ${formatDateTime(request.created_at)}</p>
    `;
    document.getElementById('detailsModal').classList.remove('hidden');
}

function closeDetailsModal() {
    document.getElementById('detailsModal').classList.add('hidden');
}

function showApproveModal(requestId) {
    document.getElementById('approve_request_id').value = requestId;
    document.getElementById('approveModal').classList.remove('hidden');
}

function closeApproveModal() {
    document.getElementById('approveModal').classList.add('hidden');
}

function showRejectModal(requestId) {
    document.getElementById('reject_request_id').value = requestId;
    document.getElementById('rejectModal').classList.remove('hidden');
}

function closeRejectModal() {
    document.getElementById('rejectModal').classList.add('hidden');
}

function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('tr-TR');
}

function formatDateTime(dateString) {
    return new Date(dateString).toLocaleString('tr-TR');
}

// Form validations
document.getElementById('rejectForm').addEventListener('submit', function(e) {
    const comment = document.getElementById('reject_comment').value.trim();
    if (!comment) {
        e.preventDefault();
        alert('Lütfen red nedenini belirtin.');
    }
});
</script>

<?php include 'includes/footer.php'; ?>