<?php
// process_leave.php
session_start();
require_once 'config/config.php';
require_once 'config/database.php';

if (!isset($_SESSION['user_id']) || !isset($_POST['action']) || !isset($_POST['request_id'])) {
    die(json_encode(['success' => false, 'message' => 'Unauthorized']));
}

$database = new Database();
$db = $database->connect();

try {
    $db->beginTransaction();

    $request_id = $_POST['request_id'];
    $action = $_POST['action'];
    $comment = $_POST['comment'] ?? '';

    // İzin talebini kontrol et
    $stmt = $db->prepare("SELECT * FROM leave_requests WHERE id = ? AND status = 'pending'");
    $stmt->execute([$request_id]);
    $request = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$request) {
        throw new Exception('İzin talebi bulunamadı veya işlem yapılamaz.');
    }

    if ($action === 'approve') {
        $stmt = $db->prepare("
            UPDATE leave_requests 
            SET status = 'approved', 
                approved_by = ?, 
                approval_date = NOW(),
                comments = ?
            WHERE id = ?
        ");
        $stmt->execute([$_SESSION['user_id'], $comment, $request_id]);
    } 
    elseif ($action === 'reject') {
        if (empty($comment)) {
            throw new Exception('Red nedeni belirtilmelidir.');
        }
        
        $stmt = $db->prepare("
            UPDATE leave_requests 
            SET status = 'rejected', 
                approved_by = ?, 
                approval_date = NOW(),
                rejection_reason = ?
            WHERE id = ?
        ");
        $stmt->execute([$_SESSION['user_id'], $comment, $request_id]);
    }

    // İşlem logunu kaydet
    $stmt = $db->prepare("
        INSERT INTO activity_logs (user_id, activity_type, description, ip_address)
        VALUES (?, ?, ?, ?)
    ");
    $stmt->execute([
        $_SESSION['user_id'],
        $action === 'approve' ? 'leave_approved' : 'leave_rejected',
        "İzin talebi " . ($action === 'approve' ? 'onaylandı' : 'reddedildi') . " (ID: $request_id)",
        $_SERVER['REMOTE_ADDR']
    ]);

    $db->commit();
    echo json_encode(['success' => true]);

} catch (Exception $e) {
    $db->rollBack();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}