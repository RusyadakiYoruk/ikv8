<?php
// get_leave_details.php
session_start();
require_once 'config/config.php';
require_once 'config/database.php';

if (!isset($_SESSION['user_id']) || !isset($_GET['request_id'])) {
    die(json_encode(['error' => 'Unauthorized']));
}

$database = new Database();
$db = $database->connect();

$stmt = $db->prepare("
    SELECT 
        lr.*,
        CONCAT(e.first_name, ' ', e.last_name) as employee_name,
        d.name as department_name,
        jt.title as job_title,
        lt.name as leave_type,
        lt.is_paid
    FROM leave_requests lr
    JOIN employees e ON lr.employee_id = e.id
    JOIN departments d ON e.department_id = d.id
    JOIN job_titles jt ON e.job_title_id = jt.id
    JOIN leave_types lt ON lr.leave_type_id = lt.id
    WHERE lr.id = ?
");

$stmt->execute([$_GET['request_id']]);
$request = $stmt->fetch(PDO::FETCH_ASSOC);

if ($request) {
    // Tarihleri formatla
    $request['start_date'] = date('d.m.Y', strtotime($request['start_date']));
    $request['end_date'] = date('d.m.Y', strtotime($request['end_date']));
    $request['created_at'] = date('d.m.Y H:i', strtotime($request['created_at']));
    
    echo json_encode($request);
} else {
    echo json_encode(['error' => 'Request not found']);
}