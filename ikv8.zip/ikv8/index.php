<?php
// Main entry point for the application
session_start();

// Load configuration
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';

// Set timezone
date_default_timezone_set(DEFAULT_TIMEZONE);

// Connect to database
$database = new Database();
$db = $database->connect();

// Check if user is logged in
if (!is_logged_in()) {
    redirect('login.php');
}

// Get user role and information
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

// Get employee information if available
$employee = null;
$stmt = $db->prepare("SELECT * FROM employees WHERE user_id = :user_id LIMIT 1");
$stmt->execute(['user_id' => $user_id]);
$employee = $stmt->fetch(PDO::FETCH_ASSOC);

// Include header
include 'includes/header.php';
?>

<div class="flex h-screen bg-gray-100">
    <!-- Sidebar -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- Main Content -->
    <div class="flex-1 overflow-auto ml-0 lg:ml-64 pt-16">
        <div class="py-6 px-8">
            <!-- Welcome Banner -->
            <div class="bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg shadow-lg p-6 mb-6 text-white">
                <div class="flex items-center justify-between">
                    <div>
                        <h1 class="text-2xl font-bold">Hoş Geldiniz, <?php echo $employee ? $employee['first_name'] . ' ' . $employee['last_name'] : $_SESSION['user_email']; ?></h1>
                        <p class="mt-1 text-blue-100">İK Yönetim Portalı'na hoş geldiniz. Bugün <?php echo date('d.m.Y'); ?></p>
                    </div>
                    <div class="hidden md:block">
                        <i class="fas fa-chart-line text-5xl text-blue-200 opacity-75"></i>
                    </div>
                </div>
            </div>
            
            <?php if ($user_role === 'admin' || $user_role === 'manager'): ?>
            <!-- Admin & Manager Dashboard -->
            <div class="mb-6">
                <h2 class="text-xl font-semibold text-gray-800 mb-4">Genel Bakış</h2>
                
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <!-- Total Employees Card -->
                    <div class="bg-white rounded-lg shadow p-5 border-l-4 border-blue-500">
                        <div class="flex justify-between">
                            <div>
                                <div class="text-gray-500 text-sm">Toplam Çalışan</div>
                                <div class="text-2xl font-bold text-gray-800">
                                    <?php
                                    $stmt = $db->query("SELECT COUNT(*) as count FROM employees WHERE termination_date IS NULL");
                                    $result = $stmt->fetch(PDO::FETCH_ASSOC);
                                    echo $result['count'];
                                    ?>
                                </div>
                                <div class="text-xs text-green-500 mt-1">
                                    <i class="fas fa-arrow-up"></i> Son ayda %3 artış
                                </div>
                            </div>
                            <div class="rounded-full bg-blue-100 p-3">
                                <i class="fas fa-users text-blue-500"></i>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Pending Leave Requests Card -->
                    <div class="bg-white rounded-lg shadow p-5 border-l-4 border-yellow-500">
                        <div class="flex justify-between">
                            <div>
                                <div class="text-gray-500 text-sm">Bekleyen İzin Talepleri</div>
                                <div class="text-2xl font-bold text-gray-800">
                                    <?php
                                    $stmt = $db->query("SELECT COUNT(*) as count FROM leave_requests WHERE status = 'pending'");
                                    $result = $stmt->fetch(PDO::FETCH_ASSOC);
                                    echo $result['count'];
                                    ?>
                                </div>
                                <div class="text-xs text-yellow-500 mt-1">
                                    <i class="fas fa-clock"></i> Onay bekliyor
                                </div>
                            </div>
                            <div class="rounded-full bg-yellow-100 p-3">
                                <i class="fas fa-calendar-alt text-yellow-500"></i>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Pending Expenses Card -->
                    <div class="bg-white rounded-lg shadow p-5 border-l-4 border-green-500">
                        <div class="flex justify-between">
                            <div>
                                <div class="text-gray-500 text-sm">Bekleyen Harcamalar</div>
                                <div class="text-2xl font-bold text-gray-800">
                                    <?php
                                    $stmt = $db->query("SELECT COUNT(*) as count FROM expenses WHERE status = 'pending'");
                                    $result = $stmt->fetch(PDO::FETCH_ASSOC);
                                    echo $result['count'];
                                    ?>
                                </div>
                                <div class="text-xs text-green-500 mt-1">
                                    <i class="fas fa-money-bill"></i> 
                                    <?php
                                    $stmt = $db->query("SELECT SUM(amount) as total FROM expenses WHERE status = 'pending'");
                                    $result = $stmt->fetch(PDO::FETCH_ASSOC);
                                    echo number_format($result['total'] ?? 0, 2) . ' ₺';
                                    ?>
                                </div>
                            </div>
                            <div class="rounded-full bg-green-100 p-3">
                                <i class="fas fa-receipt text-green-500"></i>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Today's Events Card -->
                    <div class="bg-white rounded-lg shadow p-5 border-l-4 border-purple-500">
                        <div class="flex justify-between">
                            <div>
                                <div class="text-gray-500 text-sm">Bugünkü Etkinlikler</div>
                                <div class="text-2xl font-bold text-gray-800">
                        
                                </div>
                                <div class="text-xs text-purple-500 mt-1">
                                    <i class="fas fa-calendar-day"></i> Bugün
                                </div>
                            </div>
                            <div class="rounded-full bg-purple-100 p-3">
                                <i class="fas fa-calendar-check text-purple-500"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Department Statistics -->
            <div class="mb-6">
                <h2 class="text-xl font-semibold text-gray-800 mb-4">Departman İstatistikleri</h2>
                
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- Department Employee Count -->
                    <div class="bg-white rounded-lg shadow p-5">
                        <h3 class="text-lg font-semibold text-gray-700 mb-4">Departmanlara Göre Çalışan Dağılımı</h3>
                        <div class="h-64">
                            <canvas id="departmentChart"></canvas>
                        </div>
                    </div>
                    
                    <!-- Leave Distribution -->
                    <div class="bg-white rounded-lg shadow p-5">
                        <h3 class="text-lg font-semibold text-gray-700 mb-4">İzin Dağılımı (Son 30 Gün)</h3>
                        <div class="h-64">
                            <canvas id="leaveChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Recent Activities -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                <!-- Recent Leave Requests -->
                <div class="bg-white rounded-lg shadow">
                    <div class="border-b px-5 py-3 flex justify-between items-center">
                        <h3 class="text-lg font-semibold text-gray-700">Son İzin Talepleri</h3>
                        <a href="leave_requests.php" class="text-blue-500 hover:text-blue-700 text-sm">Tümünü Gör</a>
                    </div>
                    <div class="p-5">
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead>
                                    <tr>
                                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Çalışan</th>
                                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">İzin Türü</th>
                                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tarih</th>
                                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Durum</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-200">
                                    <?php
                                    $stmt = $db->query("SELECT lr.*, e.first_name, e.last_name, lt.name as leave_type
                                                       FROM leave_requests lr
                                                       JOIN employees e ON lr.employee_id = e.id
                                                       JOIN leave_types lt ON lr.leave_type_id = lt.id
                                                       ORDER BY lr.created_at DESC LIMIT 5");
                                    $leave_requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                    
                                    if (count($leave_requests) > 0) {
                                        foreach ($leave_requests as $request) {
                                            $status_class = '';
                                            $status_text = '';
                                            
                                            switch ($request['status']) {
                                                case 'approved':
                                                    $status_class = 'bg-green-100 text-green-800';
                                                    $status_text = 'Onaylandı';
                                                    break;
                                                case 'rejected':
                                                    $status_class = 'bg-red-100 text-red-800';
                                                    $status_text = 'Reddedildi';
                                                    break;
                                                case 'pending':
                                                    $status_class = 'bg-yellow-100 text-yellow-800';
                                                    $status_text = 'Beklemede';
                                                    break;
                                                default:
                                                    $status_class = 'bg-gray-100 text-gray-800';
                                                    $status_text = ucfirst($request['status']);
                                            }
                                            
                                            echo "<tr>
                                                    <td class='px-4 py-3 whitespace-nowrap'>{$request['first_name']} {$request['last_name']}</td>
                                                    <td class='px-4 py-3 whitespace-nowrap'>{$request['leave_type']}</td>
                                                    <td class='px-4 py-3 whitespace-nowrap'>" . date('d.m.Y', strtotime($request['start_date'])) . "</td>
                                                    <td class='px-4 py-3 whitespace-nowrap'>
                                                        <span class='px-2 inline-flex text-xs leading-5 font-semibold rounded-full {$status_class}'>
                                                            {$status_text}
                                                        </span>
                                                    </td>
                                                  </tr>";
                                        }
                                    } else {
                                        echo "<tr><td colspan='4' class='px-4 py-3 text-center text-gray-500'>Henüz izin talebi bulunmamaktadır.</td></tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <!-- Today's Events -->
                <div class="bg-white rounded-lg shadow">
                    <div class="border-b px-5 py-3 flex justify-between items-center">
                        <h3 class="text-lg font-semibold text-gray-700">Bugünkü Etkinlikler</h3>
                        <a href="calendar.php" class="text-blue-500 hover:text-blue-700 text-sm">Takvimi Gör</a>
                    </div>
                    <div class="p-5">
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead>
                                    <tr>
                                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Etkinlik</th>
                                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Saat</th>
                                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Konum</th>
                                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tür</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-200">
                                  
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if ($user_role === 'employee' && $employee): ?>
            <!-- Employee Dashboard -->
            <div class="mb-6">
                <h2 class="text-xl font-semibold text-gray-800 mb-4">Kişisel Bilgilerim</h2>
                
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <!-- Leave Balance Card -->
                    <div class="bg-white rounded-lg shadow p-5 border-l-4 border-blue-500">
                        <div class="flex justify-between">
                            <div>
                                <div class="text-gray-500 text-sm">Kalan İzin</div>
                                <div class="text-2xl font-bold text-gray-800">
                                    <?php
                                    $stmt = $db->prepare("SELECT remaining_days FROM employee_leave_balances 
                                                         WHERE employee_id = :employee_id AND leave_type_id = 1 LIMIT 1");
                                    $stmt->execute(['employee_id' => $employee['id']]);
                                    $leave_balance = $stmt->fetch(PDO::FETCH_ASSOC);
                                    echo $leave_balance ? $leave_balance['remaining_days'] : '0';
                                    ?> gün
                                </div>
                                <div class="text-xs text-blue-500 mt-1">
                                    <i class="fas fa-calendar-alt"></i> Yıllık izin
                                </div>
                            </div>
                            <div class="rounded-full bg-blue-100 p-3">
                                <i class="fas fa-umbrella-beach text-blue-500"></i>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Pending Requests Card -->
                    <div class="bg-white rounded-lg shadow p-5 border-l-4 border-yellow-500">
                        <div class="flex justify-between">
                            <div>
                                <div class="text-gray-500 text-sm">Bekleyen Taleplerim</div>
                                <div class="text-2xl font-bold text-gray-800">
                                    <?php
                                    $stmt = $db->prepare("SELECT COUNT(*) as count FROM leave_requests 
                                                         WHERE employee_id = :employee_id AND status = 'pending'");
                                    $stmt->execute(['employee_id' => $employee['id']]);
                                    $result = $stmt->fetch(PDO::FETCH_ASSOC);
                                    echo $result['count'];
                                    ?>
                                </div>
                                <div class="text-xs text-yellow-500 mt-1">
                                    <i class="fas fa-clock"></i> Onay bekliyor
                                </div>
                            </div>
                            <div class="rounded-full bg-yellow-100 p-3">
                                <i class="fas fa-hourglass-half text-yellow-500"></i>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Upcoming Events Card -->
                    <div class="bg-white rounded-lg shadow p-5 border-l-4 border-green-500">
                        <div class="flex justify-between">
                            <div>
                                <div class="text-gray-500 text-sm">Yaklaşan Etkinlikler</div>
                                <div class="text-2xl font-bold text-gray-800">
                                    <?php
                                    $today = date('Y-m-d');
                                    $next_week = date('Y-m-d', strtotime('+7 days'));
                                    $stmt = $db->prepare("SELECT COUNT(*) as count FROM calendar_events 
                                                         WHERE DATE(start_datetime) BETWEEN :today AND :next_week");
                                    $stmt->execute([
                                        'today' => $today,
                                        'next_week' => $next_week
                                    ]);
                                    $result = $stmt->fetch(PDO::FETCH_ASSOC);
                                    echo $result['count'];
                                    ?>
                                </div>
                                <div class="text-xs text-green-500 mt-1">
                                    <i class="fas fa-calendar-week"></i> Önümüzdeki 7 gün
                                </div>
                            </div>
                            <div class="rounded-full bg-green-100 p-3">
                                <i class="fas fa-calendar-check text-green-500"></i>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Expense Status Card -->
                    <div class="bg-white rounded-lg shadow p-5 border-l-4 border-purple-500">
                        <div class="flex justify-between">
                            <div>
                                <div class="text-gray-500 text-sm">Harcama Durumu</div>
                                <div class="text-2xl font-bold text-gray-800">
                                    <?php
                                    $stmt = $db->prepare("SELECT SUM(amount) as total FROM expenses 
                                                         WHERE employee_id = :employee_id AND status = 'approved'");
                                    $stmt->execute(['employee_id' => $employee['id']]);
                                    $result = $stmt->fetch(PDO::FETCH_ASSOC);
                                    echo number_format($result['total'] ?? 0, 2) . ' ₺';
                                    ?>
                                </div>
                                <div class="text-xs text-purple-500 mt-1">
                                    <i class="fas fa-check-circle"></i> Onaylanan harcamalar
                                </div>
                            </div>
                            <div class="rounded-full bg-purple-100 p-3">
                                <i class="fas fa-receipt text-purple-500"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Recent Activities & Quick Actions -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                <!-- My Recent Leave Requests -->
                <div class="bg-white rounded-lg shadow">
                    <div class="border-b px-5 py-3 flex justify-between items-center">
                        <h3 class="text-lg font-semibold text-gray-700">Son İzin Taleplerim</h3>
                        <a href="my_leaves.php" class="text-blue-500 hover:text-blue-700 text-sm">Tümünü Gör</a>
                    </div>
                    <div class="p-5">
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead>
                                    <tr>
                                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">İzin Türü</th>
                                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Başlangıç</th>
                                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Bitiş</th>
                                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Durum</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-200">
                                    <?php
                                    $stmt = $db->prepare("SELECT lr.*, lt.name as leave_type
                                                         FROM leave_requests lr
                                                         JOIN leave_types lt ON lr.leave_type_id = lt.id
                                                         WHERE lr.employee_id = :employee_id
                                                         ORDER BY lr.created_at DESC LIMIT 5");
                                    $stmt->execute(['employee_id' => $employee['id']]);
                                    $leave_requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                    
                                    if (count($leave_requests) > 0) {
                                        foreach ($leave_requests as $request) {
                                            $status_class = '';
                                            $status_text = '';
                                            
                                            switch ($request['status']) {
                                                case 'approved':
                                                    $status_class = 'bg-green-100 text-green-800';
                                                    $status_text = 'Onaylandı';
                                                    break;
                                                case 'rejected':
                                                    $status_class = 'bg-red-100 text-red-800';
                                                    $status_text = 'Reddedildi';
                                                    break;
                                                case 'pending':
                                                    $status_class = 'bg-yellow-100 text-yellow-800';
                                                    $status_text = 'Beklemede';
                                                    break;
                                                default:
                                                    $status_class = 'bg-gray-100 text-gray-800';
                                                    $status_text = ucfirst($request['status']);
                                            }
                                            
                                            echo "<tr>
                                                    <td class='px-4 py-3 whitespace-nowrap'>{$request['leave_type']}</td>
                                                    <td class='px-4 py-3 whitespace-nowrap'>" . date('d.m.Y', strtotime($request['start_date'])) . "</td>
                                                    <td class='px-4 py-3 whitespace-nowrap'>" . date('d.m.Y', strtotime($request['end_date'])) . "</td>
                                                    <td class='px-4 py-3 whitespace-nowrap'>
                                                        <span class='px-2 inline-flex text-xs leading-5 font-semibold rounded-full {$status_class}'>
                                                            {$status_text}
                                                        </span>
                                                    </td>
                                                  </tr>";
                                        }
                                    } else {
                                        echo "<tr><td colspan='4' class='px-4 py-3 text-center text-gray-500'>Henüz izin talebiniz bulunmamaktadır.</td></tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <!-- Quick Actions -->
                <div class="bg-white rounded-lg shadow">
                    <div class="border-b px-5 py-3">
                        <h3 class="text-lg font-semibold text-gray-700">Hızlı İşlemler</h3>
                    </div>
                    <div class="p-5">
                        <div class="grid grid-cols-2 gap-4">
                            <a href="request_leave.php" class="flex flex-col items-center justify-center p-4 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
                                <i class="fas fa-calendar-plus text-blue-500 text-2xl mb-2"></i>
                                <span class="text-sm font-medium text-blue-700">İzin Talep Et</span>
                            </a>
                            
                            <a href="submit_expense.php" class="flex flex-col items-center justify-center p-4 bg-green-50 rounded-lg hover:bg-green-100 transition-colors">
                                <i class="fas fa-file-invoice-dollar text-green-500 text-2xl mb-2"></i>
                                <span class="text-sm font-medium text-green-700">Harcama Gir</span>
                            </a>
                            
                            <a href="my_profile.php" class="flex flex-col items-center justify-center p-4 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors">
                                <i class="fas fa-user-edit text-purple-500 text-2xl mb-2"></i>
                                <span class="text-sm font-medium text-purple-700">Profilimi Düzenle</span>
                            </a>

                            <a href="my_documents.php" class="flex flex-col items-center justify-center p-4 bg-yellow-50 rounded-lg hover:bg-yellow-100 transition-colors">
                                <i class="fas fa-folder-open text-yellow-500 text-2xl mb-2"></i>
                                <span class="text-sm font-medium text-yellow-700">Belgelerim</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Upcoming Events & Announcements -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <!-- Upcoming Events -->
                <div class="bg-white rounded-lg shadow">
                    <div class="border-b px-5 py-3 flex justify-between items-center">
                        <h3 class="text-lg font-semibold text-gray-700">Yaklaşan Etkinlikler</h3>
                        <a href="calendar.php" class="text-blue-500 hover:text-blue-700 text-sm">Takvimi Gör</a>
                    </div>
                    <div class="p-5">
                        <div class="space-y-4">
                            <?php
                            $today = date('Y-m-d');
                            $next_week = date('Y-m-d', strtotime('+7 days'));
                            $stmt = $db->prepare("SELECT * FROM calendar_events 
                                                 WHERE DATE(start_datetime) BETWEEN :today AND :next_week
                                                 ORDER BY start_datetime ASC LIMIT 3");
                            $stmt->execute([
                                'today' => $today,
                                'next_week' => $next_week
                            ]);
                            $events = $stmt->fetchAll(PDO::FETCH_ASSOC);
                            
                            if (count($events) > 0) {
                                foreach ($events as $event) {
                                    $event_date = date('d M', strtotime($event['start_datetime']));
                                    $event_time = date('H:i', strtotime($event['start_datetime']));
                                    
                                    echo "<div class='flex items-start'>
                                            <div class='flex-shrink-0 bg-blue-100 rounded-md p-2 text-center w-14'>
                                                <span class='block text-sm font-semibold text-blue-800'>{$event_date}</span>
                                                <span class='block text-xs text-blue-600'>{$event_time}</span>
                                            </div>
                                            <div class='ml-4'>
                                                <h4 class='text-sm font-medium text-gray-900'>{$event['title']}</h4>
                                                <p class='text-xs text-gray-500'>{$event['location']}</p>
                                            </div>
                                          </div>";
                                }
                            } else {
                                echo "<p class='text-center text-gray-500'>Önümüzdeki 7 gün içinde planlanmış etkinlik bulunmamaktadır.</p>";
                            }
                            ?>
                        </div>
                    </div>
                </div>
                
                <!-- Announcements -->
                <div class="bg-white rounded-lg shadow">
                    <div class="border-b px-5 py-3 flex justify-between items-center">
                        <h3 class="text-lg font-semibold text-gray-700">Duyurular</h3>
                        <a href="announcements.php" class="text-blue-500 hover:text-blue-700 text-sm">Tümünü Gör</a>
                    </div>
                    <div class="p-5">
                        <div class="space-y-4">
                            <?php
                            $stmt = $db->query("SELECT * FROM announcements 
                                               WHERE (expiry_date IS NULL OR expiry_date >= CURDATE())
                                               ORDER BY created_at DESC LIMIT 3");
                            $announcements = $stmt->fetchAll(PDO::FETCH_ASSOC);
                            
                            if (count($announcements) > 0) {
                                foreach ($announcements as $announcement) {
                                    $announcement_date = date('d.m.Y', strtotime($announcement['created_at']));
                                    
                                    echo "<div class='border-l-4 border-blue-500 pl-4'>
                                            <h4 class='text-sm font-medium text-gray-900'>{$announcement['title']}</h4>
                                            <p class='text-xs text-gray-500 mt-1'>" . substr($announcement['content'], 0, 100) . (strlen($announcement['content']) > 100 ? '...' : '') . "</p>
                                            <p class='text-xs text-gray-400 mt-1'>{$announcement_date}</p>
                                          </div>";
                                }
                            } else {
                                echo "<p class='text-center text-gray-500'>Aktif duyuru bulunmamaktadır.</p>";
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Chart.js Library -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        <?php if ($user_role === 'admin' || $user_role === 'manager'): ?>
        // Department Chart
        const departmentCtx = document.getElementById('departmentChart').getContext('2d');
        
        // Get department data from database
        <?php
        $stmt = $db->query("SELECT d.name, COUNT(e.id) as count 
                           FROM departments d
                           LEFT JOIN employees e ON d.id = e.department_id AND e.termination_date IS NULL
                           GROUP BY d.id
                           ORDER BY count DESC");
        $dept_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $dept_labels = [];
        $dept_counts = [];
        
        foreach ($dept_data as $dept) {
            $dept_labels[] = $dept['name'];
            $dept_counts[] = $dept['count'];
        }
        ?>
        
        new Chart(departmentCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($dept_labels); ?>,
                datasets: [{
                    label: 'Çalışan Sayısı',
                    data: <?php echo json_encode($dept_counts); ?>,
                    backgroundColor: 'rgba(59, 130, 246, 0.6)',
                    borderColor: 'rgba(59, 130, 246, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0
                        }
                    }
                }
            }
        });
        
        // Leave Chart
        const leaveCtx = document.getElementById('leaveChart').getContext('2d');
        
        // Get leave data from database
        <?php
        $thirty_days_ago = date('Y-m-d', strtotime('-30 days'));
        $stmt = $db->prepare("SELECT lt.name, COUNT(lr.id) as count 
                             FROM leave_types lt
                             LEFT JOIN leave_requests lr ON lt.id = lr.leave_type_id 
                                 AND lr.start_date >= :thirty_days_ago
                             GROUP BY lt.id
                             ORDER BY count DESC");
        $stmt->execute(['thirty_days_ago' => $thirty_days_ago]);
        $leave_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $leave_labels = [];
        $leave_counts = [];
        $leave_colors = ['rgba(59, 130, 246, 0.6)', 'rgba(16, 185, 129, 0.6)', 'rgba(245, 158, 11, 0.6)', 'rgba(239, 68, 68, 0.6)', 'rgba(139, 92, 246, 0.6)'];
        
        foreach ($leave_data as $index => $leave) {
            $leave_labels[] = $leave['name'];
            $leave_counts[] = $leave['count'];
        }
        ?>
        
        new Chart(leaveCtx, {
            type: 'pie',
            data: {
                labels: <?php echo json_encode($leave_labels); ?>,
                datasets: [{
                    data: <?php echo json_encode($leave_counts); ?>,
                    backgroundColor: <?php echo json_encode(array_slice($leave_colors, 0, count($leave_labels))); ?>,
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right'
                    }
                }
            }
        });
        <?php endif; ?>
    });
</script>

<?php include 'includes/footer.php'; ?>