<?php
// Payroll Generation Page
session_start();

// Load configuration
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';

// Set timezone
date_default_timezone_set(DEFAULT_TIMEZONE);

// Connect to database
$database = new Database();
$db = $database->connect();

// Check if user is logged in and has admin or finance role
require_role(['admin', 'finance']);

// Get user information
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

// Initialize variables
$errors = [];
$success_message = '';
$period = null;
$employees = [];
$payrolls = [];
$total_stats = [
    'total_employees' => 0,
    'total_gross' => 0,
    'total_net' => 0,
    'total_tax' => 0,
    'total_insurance' => 0
];

// Check if period ID is provided
if (!isset($_GET['period_id']) || !is_numeric($_GET['period_id'])) {
    set_flash_message('payroll_error', 'Geçersiz bordro dönemi ID\'si.', 'danger');
    redirect('payroll_periods.php');
    exit;
}

$period_id = (int)$_GET['period_id'];

// Get period details
$stmt = $db->prepare("SELECT * FROM payroll_periods WHERE id = :period_id");
$stmt->execute(['period_id' => $period_id]);
$period = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$period) {
    set_flash_message('payroll_error', 'Bordro dönemi bulunamadı.', 'danger');
    redirect('payroll_periods.php');
    exit;
}

// Process form submission for generating payrolls
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
        $errors['general'] = 'Geçersiz form gönderimi. Lütfen tekrar deneyin.';
    } else {
        $action = $_POST['action'];
        
        // Generate payrolls for all employees
        if ($action === 'generate_all') {
            try {
                // Begin transaction
                $db->beginTransaction();
                
                // Get all active employees
                $stmt = $db->prepare("SELECT * FROM employees WHERE termination_date IS NULL OR termination_date > :period_end");
                $stmt->execute(['period_end' => $period['end_date']]);
                $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                $generated_count = 0;
                $updated_count = 0;
                
                foreach ($employees as $employee) {
                    // Check if payroll already exists for this employee and period
                    $stmt = $db->prepare("SELECT id FROM payrolls WHERE employee_id = :employee_id AND period_id = :period_id");
                    $stmt->execute([
                        'employee_id' => $employee['id'],
                        'period_id' => $period_id
                    ]);
                    
                    $existing_payroll = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    // Calculate salary based on employment type and salary type
                    $base_salary = $employee['salary_amount'] ?? 0;
                    $work_days = calculate_work_days($period['start_date'], $period['end_date'], $employee['hire_date'], $employee['termination_date']);
                    
                    // Adjust salary for partial months (new hires or terminations)
                    if ($work_days < get_total_workdays_in_period($period['start_date'], $period['end_date'])) {
                        $base_salary = calculate_prorated_salary($base_salary, $work_days, $period['start_date'], $period['end_date']);
                    }
                    
                    // Calculate tax and insurance deductions
                    $tax_rate = 0.15; // 15% tax rate (simplified)
                    $insurance_rate = 0.14; // 14% insurance rate (simplified)
                    
                    $tax_amount = $base_salary * $tax_rate;
                    $insurance_amount = $base_salary * $insurance_rate;
                    
                    // Calculate gross and net salary
                    $gross_salary = $base_salary;
                    $net_salary = $gross_salary - $tax_amount - $insurance_amount;
                    
                    if ($existing_payroll) {
                        // Update existing payroll
                        $stmt = $db->prepare("UPDATE payrolls SET 
                            base_salary = :base_salary,
                            gross_salary = :gross_salary,
                            net_salary = :net_salary,
                            tax_amount = :tax_amount,
                            insurance_amount = :insurance_amount,
                            work_days = :work_days,
                            updated_by = :updated_by,
                            updated_at = NOW()
                        WHERE id = :payroll_id");
                        
                        $stmt->execute([
                            'base_salary' => $base_salary,
                            'gross_salary' => $gross_salary,
                            'net_salary' => $net_salary,
                            'tax_amount' => $tax_amount,
                            'insurance_amount' => $insurance_amount,
                            'work_days' => $work_days,
                            'updated_by' => $user_id,
                            'payroll_id' => $existing_payroll['id']
                        ]);
                        
                        $updated_count++;
                    } else {
                        // Insert new payroll
                        $stmt = $db->prepare("INSERT INTO payrolls (
                            employee_id, period_id, base_salary, gross_salary, net_salary, 
                            tax_amount, insurance_amount, work_days, payment_status, 
                            created_by, created_at
                        ) VALUES (
                            :employee_id, :period_id, :base_salary, :gross_salary, :net_salary,
                            :tax_amount, :insurance_amount, :work_days, 'pending',
                            :created_by, NOW()
                        )");
                        
                        $stmt->execute([
                            'employee_id' => $employee['id'],
                            'period_id' => $period_id,
                            'base_salary' => $base_salary,
                            'gross_salary' => $gross_salary,
                            'net_salary' => $net_salary,
                            'tax_amount' => $tax_amount,
                            'insurance_amount' => $insurance_amount,
                            'work_days' => $work_days,
                            'created_by' => $user_id
                        ]);
                        
                        $generated_count++;
                    }
                }
                
                // Update period status
                $stmt = $db->prepare("UPDATE payroll_periods SET status = 'processing', updated_by = :user_id, updated_at = NOW() WHERE id = :period_id");
                $stmt->execute([
                    'user_id' => $user_id,
                    'period_id' => $period_id
                ]);
                
                // Log the action
                $stmt = $db->prepare("INSERT INTO activity_logs (user_id, activity_type, description, ip_address) VALUES (:user_id, 'payroll_generate', :description, :ip_address)");
                $stmt->execute([
                    'user_id' => $user_id,
                    'description' => "Bordro oluşturuldu: {$period['period_name']} - {$generated_count} yeni, {$updated_count} güncellendi",
                    'ip_address' => $_SERVER['REMOTE_ADDR']
                ]);
                
                // Commit transaction
                $db->commit();
                
                $success_message = "{$generated_count} yeni bordro oluşturuldu, {$updated_count} bordro güncellendi.";
                set_flash_message('payroll_success', $success_message, 'success');
                redirect("generate_payroll.php?period_id={$period_id}");
                exit;
                
            } catch (Exception $e) {
                // Rollback transaction on error
                $db->rollBack();
                $errors['general'] = 'Bordro oluşturulurken bir hata oluştu: ' . $e->getMessage();
                error_log('Bordro oluşturma hatası: ' . $e->getMessage());
            }
        }
        // Update individual payroll
        elseif ($action === 'update_payroll' && isset($_POST['payroll_id'])) {
            $payroll_id = (int)$_POST['payroll_id'];
            $base_salary = (float)$_POST['base_salary'];
            $allowances = (float)($_POST['allowances'] ?? 0);
            $deductions = (float)($_POST['deductions'] ?? 0);
            $tax_amount = (float)($_POST['tax_amount'] ?? 0);
            $insurance_amount = (float)($_POST['insurance_amount'] ?? 0);
            $work_days = (int)($_POST['work_days'] ?? 0);
            $notes = sanitize($_POST['notes'] ?? '');
            
            // Calculate gross and net salary
            $gross_salary = $base_salary + $allowances;
            $net_salary = $gross_salary - $deductions - $tax_amount - $insurance_amount;
            
            try {
                $stmt = $db->prepare("UPDATE payrolls SET 
                    base_salary = :base_salary,
                    gross_salary = :gross_salary,
                    net_salary = :net_salary,
                    tax_amount = :tax_amount,
                    insurance_amount = :insurance_amount,
                    allowances = :allowances,
                    deductions = :deductions,
                    work_days = :work_days,
                    notes = :notes,
                    updated_by = :updated_by,
                    updated_at = NOW()
                WHERE id = :payroll_id");
                
                $stmt->execute([
                    'base_salary' => $base_salary,
                    'gross_salary' => $gross_salary,
                    'net_salary' => $net_salary,
                    'tax_amount' => $tax_amount,
                    'insurance_amount' => $insurance_amount,
                    'allowances' => $allowances,
                    'deductions' => $deductions,
                    'work_days' => $work_days,
                    'notes' => $notes,
                    'updated_by' => $user_id,
                    'payroll_id' => $payroll_id
                ]);
                
                $success_message = "Bordro başarıyla güncellendi.";
                set_flash_message('payroll_success', $success_message, 'success');
                redirect("generate_payroll.php?period_id={$period_id}");
                exit;
                
            } catch (Exception $e) {
                $errors['general'] = 'Bordro güncellenirken bir hata oluştu: ' . $e->getMessage();
                error_log('Bordro güncelleme hatası: ' . $e->getMessage());
            }
        }
        // Finalize payrolls
        elseif ($action === 'finalize') {
            try {
                // Begin transaction
                $db->beginTransaction();
                
                // Update all payrolls for this period to 'paid' status
                $stmt = $db->prepare("UPDATE payrolls SET 
                    payment_status = 'paid',
                    payment_date = :payment_date,
                    updated_by = :user_id,
                    updated_at = NOW()
                WHERE period_id = :period_id");
                
                $stmt->execute([
                    'payment_date' => $period['payment_date'],
                    'user_id' => $user_id,
                    'period_id' => $period_id
                ]);
                
                // Update period status to 'completed'
                $stmt = $db->prepare("UPDATE payroll_periods SET 
                    status = 'completed',
                    updated_by = :user_id,
                    updated_at = NOW()
                WHERE id = :period_id");
                
                $stmt->execute([
                    'user_id' => $user_id,
                    'period_id' => $period_id
                ]);
                
                // Log the action
                $stmt = $db->prepare("INSERT INTO activity_logs (user_id, activity_type, description, ip_address) VALUES (:user_id, 'payroll_finalize', :description, :ip_address)");
                $stmt->execute([
                    'user_id' => $user_id,
                    'description' => "Bordro dönemi tamamlandı: {$period['period_name']}",
                    'ip_address' => $_SERVER['REMOTE_ADDR']
                ]);
                
                // Commit transaction
                $db->commit();
                
                $success_message = "Bordro dönemi başarıyla tamamlandı ve ödemeler işaretlendi.";
                set_flash_message('payroll_success', $success_message, 'success');
                redirect("generate_payroll.php?period_id={$period_id}");
                exit;
                
            } catch (Exception $e) {
                // Rollback transaction on error
                $db->rollBack();
                $errors['general'] = 'Bordro dönemi tamamlanırken bir hata oluştu: ' . $e->getMessage();
                error_log('Bordro dönemi tamamlama hatası: ' . $e->getMessage());
            }
        }
    }
}

// Get all employees with their payroll data for this period
$sql = "SELECT e.*, 
        d.name AS department_name,
        jt.title AS job_title,
        pr.id AS payroll_id,
        pr.base_salary,
        pr.gross_salary,
        pr.net_salary,
        pr.tax_amount,
        pr.insurance_amount,
        pr.allowances,
        pr.deductions,
        pr.work_days,
        pr.payment_status,
        pr.payment_date,
        pr.notes
        FROM employees e
        LEFT JOIN departments d ON e.department_id = d.id
        LEFT JOIN job_titles jt ON e.job_title_id = jt.id
        LEFT JOIN payrolls pr ON e.id = pr.employee_id AND pr.period_id = :period_id
        WHERE e.termination_date IS NULL OR e.termination_date > :period_start
        ORDER BY e.last_name, e.first_name";

$stmt = $db->prepare($sql);
$stmt->execute([
    'period_id' => $period_id,
    'period_start' => $period['start_date']
]);
$employees = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate total statistics
foreach ($employees as $employee) {
    if ($employee['payroll_id']) {
        $total_stats['total_employees']++;
        $total_stats['total_gross'] += $employee['gross_salary'];
        $total_stats['total_net'] += $employee['net_salary'];
        $total_stats['total_tax'] += $employee['tax_amount'];
        $total_stats['total_insurance'] += $employee['insurance_amount'];
    }
}

// Helper functions for payroll calculations
function calculate_work_days($period_start, $period_end, $hire_date, $termination_date) {
    // Convert dates to timestamps
    $period_start_ts = strtotime($period_start);
    $period_end_ts = strtotime($period_end);
    $hire_date_ts = strtotime($hire_date);
    $termination_date_ts = $termination_date ? strtotime($termination_date) : PHP_INT_MAX;
    
    // Determine effective start and end dates
    $effective_start_ts = max($period_start_ts, $hire_date_ts);
    $effective_end_ts = min($period_end_ts, $termination_date_ts);
    
    // If employee wasn't employed during this period, return 0
    if ($effective_start_ts > $effective_end_ts) {
        return 0;
    }
    
    // Count working days (Monday to Friday)
    $work_days = 0;
    $current_ts = $effective_start_ts;
    
    while ($current_ts <= $effective_end_ts) {
        $day_of_week = date('N', $current_ts);
        if ($day_of_week <= 5) { // 1 (Monday) to 5 (Friday)
            $work_days++;
        }
        $current_ts = strtotime('+1 day', $current_ts);
    }
    
    return $work_days;
}

function get_total_workdays_in_period($period_start, $period_end) {
    // Count total working days in the period (Monday to Friday)
    $work_days = 0;
    $current_ts = strtotime($period_start);
    $period_end_ts = strtotime($period_end);
    
    while ($current_ts <= $period_end_ts) {
        $day_of_week = date('N', $current_ts);
        if ($day_of_week <= 5) { // 1 (Monday) to 5 (Friday)
            $work_days++;
        }
        $current_ts = strtotime('+1 day', $current_ts);
    }
    
    return $work_days;
}

function calculate_prorated_salary($base_salary, $work_days, $period_start, $period_end) {
    $total_work_days = get_total_workdays_in_period($period_start, $period_end);
    if ($total_work_days == 0) return 0;
    
    return ($base_salary / $total_work_days) * $work_days;
}

// Include header
include 'includes/header.php';
?>

<div class="flex h-screen bg-gray-100">
    <!-- Sidebar -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- Main Content -->
    <div class="flex-1 overflow-auto ml-0 lg:ml-64 pt-16">
        <div class="py-6 px-8">
            <!-- Page Header -->
            <div class="flex justify-between items-center mb-6">
                <div>
                    <h1 class="text-2xl font-bold text-gray-800">Bordro Oluştur</h1>
                    <p class="text-sm text-gray-600">Dönem: <?php echo htmlspecialchars($period['period_name']); ?> (<?php echo date('d.m.Y', strtotime($period['start_date'])); ?> - <?php echo date('d.m.Y', strtotime($period['end_date'])); ?>)</p>
                </div>
                <nav class="flex" aria-label="Breadcrumb">
                    <ol class="inline-flex items-center space-x-1 md:space-x-3">
                        <li class="inline-flex items-center">
                            <a href="index.php" class="text-gray-700 hover:text-gray-900 inline-flex items-center">
                                <svg class="w-5 h-5 mr-2.5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"></path>
                                </svg>
                                Dashboard
                            </a>
                        </li>
                        <li>
                            <div class="flex items-center">
                                <svg class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <a href="payroll_periods.php" class="ml-1 text-gray-700 hover:text-gray-900 md:ml-2">Bordro Dönemleri</a>
                            </div>
                        </li>
                        <li>
                            <div class="flex items-center">
                                <svg class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span class="ml-1 text-gray-500 md:ml-2">Bordro Oluştur</span>
                            </div>
                        </li>
                    </ol>
                </nav>
            </div>
            
            <!-- Flash Messages -->
            <?php if (isset($_SESSION['flash_messages']['payroll_success'])): ?>
                <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6" role="alert">
                    <p><?php echo $_SESSION['flash_messages']['payroll_success']['message']; ?></p>
                </div>
                <?php unset($_SESSION['flash_messages']['payroll_success']); ?>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['flash_messages']['payroll_error'])): ?>
                <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                    <p><?php echo $_SESSION['flash_messages']['payroll_error']['message']; ?></p>
                </div>
                <?php unset($_SESSION['flash_messages']['payroll_error']); ?>
            <?php endif; ?>
            
            <?php if (isset($errors['general'])): ?>
                <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                    <p><?php echo $errors['general']; ?></p>
                </div>
            <?php endif; ?>
            
            <!-- Period Status Card -->
            <div class="bg-white shadow-md rounded-lg overflow-hidden mb-6">
                <div class="px-6 py-4 border-b border-gray-200 bg-gray-50 flex justify-between items-center">
                    <div>
                        <h3 class="text-lg font-semibold text-gray-800">Dönem Durumu</h3>
                        <p class="text-sm text-gray-600">Ödeme Tarihi: <?php echo date('d.m.Y', strtotime($period['payment_date'])); ?></p>
                    </div>
                    <div>
                        <span class="px-3 py-1 inline-flex text-sm leading-5 font-semibold rounded-full 
                            <?php 
                            switch ($period['status']) {
                                case 'pending':
                                    echo 'bg-yellow-100 text-yellow-800';
                                    break;
                                case 'processing':
                                    echo 'bg-blue-100 text-blue-800';
                                    break;
                                case 'completed':
                                    echo 'bg-green-100 text-green-800';
                                    break;
                                case 'cancelled':
                                    echo 'bg-red-100 text-red-800';
                                    break;
                                default:
                                    echo 'bg-gray-100 text-gray-800';
                            }
                            ?>">
                            <?php 
                            switch ($period['status']) {
                                case 'pending':
                                    echo 'Beklemede';
                                    break;
                                case 'processing':
                                    echo 'İşleniyor';
                                    break;
                                case 'completed':
                                    echo 'Tamamlandı';
                                    break;
                                case 'cancelled':
                                    echo 'İptal Edildi';
                                    break;
                                default:
                                    echo $period['status'];
                            }
                            ?>
                        </span>
                    </div>
                </div>
                <div class="p-6">
                    <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div class="bg-blue-50 p-4 rounded-lg">
                            <p class="text-sm text-blue-600 font-medium">Toplam Çalışan</p>
                            <p class="text-2xl font-bold text-blue-800"><?php echo $total_stats['total_employees']; ?></p>
                        </div>
                        <div class="bg-green-50 p-4 rounded-lg">
                            <p class="text-sm text-green-600 font-medium">Toplam Brüt</p>
                            <p class="text-2xl font-bold text-green-800"><?php echo number_format($total_stats['total_gross'], 2, ',', '.'); ?> ₺</p>
                        </div>
                        <div class="bg-indigo-50 p-4 rounded-lg">
                            <p class="text-sm text-indigo-600 font-medium">Toplam Net</p>
                            <p class="text-2xl font-bold text-indigo-800"><?php echo number_format($total_stats['total_net'], 2, ',', '.'); ?> ₺</p>
                        </div>
                        <div class="bg-red-50 p-4 rounded-lg">
                            <p class="text-sm text-red-600 font-medium">Toplam Kesintiler</p>
                            <p class="text-2xl font-bold text-red-800"><?php echo number_format($total_stats['total_tax'] + $total_stats['total_insurance'], 2, ',', '.'); ?> ₺</p>
                        </div>
                    </div>
                    <div class="mt-6 flex space-x-4">
                        <?php if ($period['status'] !== 'completed'): ?>
                            <form method="POST" action="generate_payroll.php?period_id=<?php echo $period_id; ?>">
                                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                <input type="hidden" name="action" value="generate_all">
                                <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
                                    </svg>
                                    Bordroları Oluştur/Güncelle
                                </button>
                            </form>
                            
                            <?php if ($total_stats['total_employees'] > 0 && $period['status'] === 'processing'): ?>
                                <form method="POST" action="generate_payroll.php?period_id=<?php echo $period_id; ?>" onsubmit="return confirm('Bordro dönemini tamamlamak istediğinizden emin misiniz? Bu işlem geri alınamaz.');">
                                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                    <input type="hidden" name="action" value="finalize">
                                    <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                                        </svg>
                                        Dönemi Tamamla
                                    </button>
                                </form>
                            <?php endif; ?>
                        <?php endif; ?>
                        
                        <a href="export_payroll.php?period_id=<?php echo $period_id; ?>" class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                            </svg>
                            Excel'e Aktar
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Employees Payroll Table -->
            <div class="bg-white shadow-md rounded-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h3 class="text-lg font-semibold text-gray-800">Çalışan Bordroları</h3>
                </div>
                
                <?php if (count($employees) > 0): ?>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Çalışan
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Departman
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Pozisyon
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Çalışma Günü
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Brüt Maaş
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Vergi
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        SGK
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Net Maaş
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Durum
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        İşlemler
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php foreach ($employees as $employee): ?>
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="flex items-center">
                                                <div class="flex-shrink-0 h-10 w-10 bg-gray-200 rounded-full flex items-center justify-center">
                                                    <span class="text-gray-500 font-medium"><?php echo substr($employee['first_name'], 0, 1) . substr($employee['last_name'], 0, 1); ?></span>
                                                </div>
                                                <div class="ml-4">
                                                    <div class="text-sm font-medium text-gray-900">
                                                        <?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?>
                                                    </div>
                                                    <div class="text-sm text-gray-500">
                                                        <?php echo htmlspecialchars($employee['email'] ?? ''); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm text-gray-900"><?php echo htmlspecialchars($employee['department_name'] ?? '-'); ?></div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm text-gray-900"><?php echo htmlspecialchars($employee['job_title'] ?? '-'); ?></div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-500">
                                            <?php echo $employee['work_days'] ?? '-'; ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-900">
                                            <?php echo isset($employee['gross_salary']) ? number_format($employee['gross_salary'], 2, ',', '.') . ' ₺' : '-'; ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-900">
                                            <?php echo isset($employee['tax_amount']) ? number_format($employee['tax_amount'], 2, ',', '.') . ' ₺' : '-'; ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-900">
                                            <?php echo isset($employee['insurance_amount']) ? number_format($employee['insurance_amount'], 2, ',', '.') . ' ₺' : '-'; ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-900 font-medium">
                                            <?php echo isset($employee['net_salary']) ? number_format($employee['net_salary'], 2, ',', '.') . ' ₺' : '-'; ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-center">
                                            <?php if (isset($employee['payment_status'])): ?>
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                                    <?php 
                                                    switch ($employee['payment_status']) {
                                                        case 'pending':
                                                            echo 'bg-yellow-100 text-yellow-800';
                                                            break;
                                                        case 'paid':
                                                            echo 'bg-green-100 text-green-800';
                                                            break;
                                                        case 'cancelled':
                                                            echo 'bg-red-100 text-red-800';
                                                            break;
                                                        default:
                                                            echo 'bg-gray-100 text-gray-800';
                                                    }
                                                    ?>">
                                                    <?php 
                                                    switch ($employee['payment_status']) {
                                                        case 'pending':
                                                            echo 'Beklemede';
                                                            break;
                                                        case 'paid':
                                                            echo 'Ödendi';
                                                            break;
                                                        case 'cancelled':
                                                            echo 'İptal Edildi';
                                                            break;
                                                        default:
                                                            echo $employee['payment_status'];
                                                    }
                                                    ?>
                                                </span>
                                            <?php else: ?>
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                                                    Oluşturulmadı
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                            <?php if (isset($employee['payroll_id']) && $period['status'] !== 'completed'): ?>
                                                <button type="button" class="text-indigo-600 hover:text-indigo-900 edit-payroll-btn" 
                                                        data-id="<?php echo $employee['payroll_id']; ?>"
                                                        data-employee="<?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?>"
                                                        data-base="<?php echo $employee['base_salary']; ?>"
                                                        data-allowances="<?php echo $employee['allowances'] ?? 0; ?>"
                                                        data-deductions="<?php echo $employee['deductions'] ?? 0; ?>"
                                                        data-tax="<?php echo $employee['tax_amount']; ?>"
                                                        data-insurance="<?php echo $employee['insurance_amount']; ?>"
                                                        data-workdays="<?php echo $employee['work_days']; ?>"
                                                        data-notes="<?php echo htmlspecialchars($employee['notes'] ?? ''); ?>">
                                                    <svg class="w-5 h-5 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"></path>
                                                    </svg>
                                                    Düzenle
                                                </button>
                                            <?php elseif (!isset($employee['payroll_id'])): ?>
                                                <span class="text-gray-400">Bordro Yok</span>
                                            <?php else: ?>
                                                <a href="view_payslip.php?id=<?php echo $employee['payroll_id']; ?>" class="text-blue-600 hover:text-blue-900">
                                                    <svg class="w-5 h-5 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>
                                                    </svg>
                                                    Görüntüle
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="p-6 text-center">
                        <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path>
                        </svg>
                        <h3 class="mt-2 text-sm font-medium text-gray-900">Çalışan Bulunamadı</h3>
                        <p class="mt-1 text-sm text-gray-500">Bu dönemde aktif çalışan bulunmamaktadır.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Edit Payroll Modal -->
<div id="editPayrollModal" class="fixed z-10 inset-0 overflow-y-auto hidden">
    <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div class="fixed inset-0 transition-opacity" aria-hidden="true">
            <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
        </div>
        <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
        <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
            <form method="POST" action="generate_payroll.php?period_id=<?php echo $period_id; ?>">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="update_payroll">
                <input type="hidden" name="payroll_id" id="edit_payroll_id">
                
                <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                    <div class="sm:flex sm:items-start">
                        <div class="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-blue-100 sm:mx-0 sm:h-10 sm:w-10">
                            <svg class="h-6 w-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                        </div>
                        <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                            <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                                Bordro Düzenle
                            </h3>
                            <p class="text-sm text-gray-500" id="edit_employee_name"></p>
                            <div class="mt-4 space-y-4">
                                <div class="grid grid-cols-2 gap-4">
                                    <div>
                                        <label for="edit_base_salary" class="block text-sm font-medium text-gray-700">Temel Maaş</label>
                                        <div class="mt-1 relative rounded-md shadow-sm">
                                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                                <span class="text-gray-500 sm:text-sm">₺</span>
                                            </div>
                                            <input type="text" name="base_salary" id="edit_base_salary" class="focus:ring-blue-500 focus:border-blue-500 block w-full pl-7 pr-12 sm:text-sm border-gray-300 rounded-md" placeholder="0.00">
                                        </div>
                                    </div>
                                    <div>
                                        <label for="edit_work_days" class="block text-sm font-medium text-gray-700">Çalışma Günü</label>
                                        <input type="number" name="work_days" id="edit_work_days" min="0" max="31" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                    </div>
                                </div>
                                
                                <div class="grid grid-cols-2 gap-4">
                                    <div>
                                        <label for="edit_allowances" class="block text-sm font-medium text-gray-700">Ek Ödemeler</label>
                                        <div class="mt-1 relative rounded-md shadow-sm">
                                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                                <span class="text-gray-500 sm:text-sm">₺</span>
                                            </div>
                                            <input type="text" name="allowances" id="edit_allowances" class="focus:ring-blue-500 focus:border-blue-500 block w-full pl-7 pr-12 sm:text-sm border-gray-300 rounded-md" placeholder="0.00">
                                        </div>
                                    </div>
                                    <div>
                                        <label for="edit_deductions" class="block text-sm font-medium text-gray-700">Kesintiler</label>
                                        <div class="mt-1 relative rounded-md shadow-sm">
                                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                                <span class="text-gray-500 sm:text-sm">₺</span>
                                            </div>
                                            <input type="text" name="deductions" id="edit_deductions" class="focus:ring-blue-500 focus:border-blue-500 block w-full pl-7 pr-12 sm:text-sm border-gray-300 rounded-md" placeholder="0.00">
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="grid grid-cols-2 gap-4">
                                    <div>
                                        <label for="edit_tax_amount" class="block text-sm font-medium text-gray-700">Vergi</label>
                                        <div class="mt-1 relative rounded-md shadow-sm">
                                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                                <span class="text-gray-500 sm:text-sm">₺</span>
                                            </div>
                                            <input type="text" name="tax_amount" id="edit_tax_amount" class="focus:ring-blue-500 focus:border-blue-500 block w-full pl-7 pr-12 sm:text-sm border-gray-300 rounded-md" placeholder="0.00">
                                        </div>
                                    </div>
                                    <div>
                                        <label for="edit_insurance_amount" class="block text-sm font-medium text-gray-700">SGK</label>
                                        <div class="mt-1 relative rounded-md shadow-sm">
                                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                                <span class="text-gray-500 sm:text-sm">₺</span>
                                            </div>
                                            <input type="text" name="insurance_amount" id="edit_insurance_amount" class="focus:ring-blue-500 focus:border-blue-500 block w-full pl-7 pr-12 sm:text-sm border-gray-300 rounded-md" placeholder="0.00">
                                        </div>
                                    </div>
                                </div>
                                
                                <div>
                                    <label for="edit_notes" class="block text-sm font-medium text-gray-700">Notlar</label>
                                    <textarea name="notes" id="edit_notes" rows="3" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"></textarea>
                                </div>
                                
                                <div class="bg-gray-50 p-4 rounded-md">
                                    <div class="flex justify-between items-center">
                                        <span class="text-sm font-medium text-gray-700">Brüt Maaş:</span>
                                        <span class="text-sm font-medium text-gray-900" id="calculated_gross">₺0.00</span>
                                    </div>
                                    <div class="flex justify-between items-center mt-2">
                                        <span class="text-sm font-medium text-gray-700">Toplam Kesintiler:</span>
                                        <span class="text-sm font-medium text-gray-900" id="calculated_deductions">₺0.00</span>
                                    </div>
                                    <div class="flex justify-between items-center mt-2 border-t pt-2">
                                        <span class="text-sm font-medium text-gray-700">Net Maaş:</span>
                                        <span class="text-sm font-bold text-gray-900" id="calculated_net">₺0.00</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                    <button type="submit" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm">
                        Kaydet
                    </button>
                    <button type="button" id="closeEditPayrollModal" class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">
                        İptal
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Edit Payroll Modal
        const editPayrollModal = document.getElementById('editPayrollModal');
        const editPayrollBtns = document.querySelectorAll('.edit-payroll-btn');
        const closeEditPayrollModal = document.getElementById('closeEditPayrollModal');
        
        // Form fields
        const editPayrollId = document.getElementById('edit_payroll_id');
        const editEmployeeName = document.getElementById('edit_employee_name');
        const editBaseSalary = document.getElementById('edit_base_salary');
        const editWorkDays = document.getElementById('edit_work_days');
        const editAllowances = document.getElementById('edit_allowances');
        const editDeductions = document.getElementById('edit_deductions');
        const editTaxAmount = document.getElementById('edit_tax_amount');
        const editInsuranceAmount = document.getElementById('edit_insurance_amount');
        const editNotes = document.getElementById('edit_notes');
        
        // Calculated fields
        const calculatedGross = document.getElementById('calculated_gross');
        const calculatedDeductions = document.getElementById('calculated_deductions');
        const calculatedNet = document.getElementById('calculated_net');
        
        function openEditPayrollModal(event) {
            const button = event.currentTarget;
            const id = button.getAttribute('data-id');
            const employee = button.getAttribute('data-employee');
            const base = parseFloat(button.getAttribute('data-base'));
            const allowances = parseFloat(button.getAttribute('data-allowances'));
            const deductions = parseFloat(button.getAttribute('data-deductions'));
            const tax = parseFloat(button.getAttribute('data-tax'));
            const insurance = parseFloat(button.getAttribute('data-insurance'));
            const workdays = parseInt(button.getAttribute('data-workdays'));
            const notes = button.getAttribute('data-notes');
            
            editPayrollId.value = id;
            editEmployeeName.textContent = employee;
            editBaseSalary.value = base.toFixed(2);
            editWorkDays.value = workdays;
            editAllowances.value = allowances.toFixed(2);
            editDeductions.value = deductions.toFixed(2);
            editTaxAmount.value = tax.toFixed(2);
            editInsuranceAmount.value = insurance.toFixed(2);
            editNotes.value = notes;
            
            updateCalculations();
            
            editPayrollModal.classList.remove('hidden');
        }
        
        function closeEditPayrollModalFunc() {
            editPayrollModal.classList.add('hidden');
        }
        
        function updateCalculations() {
            const base = parseFloat(editBaseSalary.value) || 0;
            const allowances = parseFloat(editAllowances.value) || 0;
            const deductions = parseFloat(editDeductions.value) || 0;
            const tax = parseFloat(editTaxAmount.value) || 0;
            const insurance = parseFloat(editInsuranceAmount.value) || 0;
            
            const gross = base + allowances;
            const totalDeductions = deductions + tax + insurance;
            const net = gross - totalDeductions;
            
            calculatedGross.textContent = '₺' + gross.toFixed(2);
            calculatedDeductions.textContent = '₺' + totalDeductions.toFixed(2);
            calculatedNet.textContent = '₺' + net.toFixed(2);
        }
        
        // Add event listeners
        editPayrollBtns.forEach(button => {
            button.addEventListener('click', openEditPayrollModal);
        });
        
        if (closeEditPayrollModal) {
            closeEditPayrollModal.addEventListener('click', closeEditPayrollModalFunc);
        }
        
        // Update calculations when input values change
        editBaseSalary.addEventListener('input', updateCalculations);
        editAllowances.addEventListener('input', updateCalculations);
        editDeductions.addEventListener('input', updateCalculations);
        editTaxAmount.addEventListener('input', updateCalculations);
        editInsuranceAmount.addEventListener('input', updateCalculations);
        
        // Format currency inputs
        const currencyInputs = [editBaseSalary, editAllowances, editDeductions, editTaxAmount, editInsuranceAmount];
        
        currencyInputs.forEach(input => {
            input.addEventListener('blur', function(e) {
                const value = e.target.value.replace(/[^\d.]/g, '');
                if (value && !isNaN(parseFloat(value))) {
                    e.target.value = parseFloat(value).toFixed(2);
                } else {
                    e.target.value = '0.00';
                }
                updateCalculations();
            });
        });
        
        // Close modal when clicking outside
        window.addEventListener('click', function(event) {
            if (event.target === editPayrollModal) {
                closeEditPayrollModalFunc();
            }
        });
    });
</script>

<?php include 'includes/footer.php'; ?>