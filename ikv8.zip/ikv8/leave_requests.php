<?php
session_start();
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';

// Yetki kontrolü
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$database = new Database();
$db = $database->connect();

// Kullanıcı ve rol bilgisini al
$stmt = $db->prepare("
    SELECT u.*, e.id as employee_id, e.department_id, e.job_title_id, jt.title as job_title
    FROM users u
    LEFT JOIN employees e ON u.id = e.user_id
    LEFT JOIN job_titles jt ON e.job_title_id = jt.id
    WHERE u.id = ?
");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Yetki kontrolü
$is_admin = $user['role'] === 'admin';
$is_manager = $user['role'] === 'manager';
$is_chief = strpos(strtolower($user['job_title']), 'şef') !== false || 
            strpos(strtolower($user['job_title']), 'sef') !== false;

// Yetkisiz erişimi engelle
if (!$is_admin && !$is_manager && !$is_chief) {
    header('Location: index.php');
    exit;
}

// Aktif sekme kontrolü
$active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'pending';

// SQL sorgularını hazırla
$base_sql = "
    SELECT 
        lr.*,
        e.first_name,
        e.last_name,
        d.name as department_name,
        jt.title as job_title,
        lt.name as leave_type,
        lt.is_paid,
        CONCAT(ae.first_name, ' ', ae.last_name) as approved_by_name
    FROM leave_requests lr
    JOIN employees e ON lr.employee_id = e.id
    JOIN departments d ON e.department_id = d.id
    JOIN job_titles jt ON e.job_title_id = jt.id
    JOIN leave_types lt ON lr.leave_type_id = lt.id
    LEFT JOIN employees ae ON lr.approved_by = ae.id
    WHERE 1=1
";

$params = [];

// Yetki seviyesine göre filtreleme
if (!$is_admin) {
    if ($is_chief) {
        $base_sql .= " AND e.department_id = ?";
        $params[] = $user['department_id'];
    }
}

// Bekleyen izinler sorgusu
$pending_sql = $base_sql . " AND lr.status = 'pending' ORDER BY lr.created_at DESC";
$pending_params = $params;

// Onaylanmış izinler sorgusu
$approved_sql = $base_sql . " AND lr.status = 'approved' ORDER BY lr.start_date DESC";
$approved_params = $params;

// Sorguları çalıştır
$stmt = $db->prepare($pending_sql);
$stmt->execute($pending_params);
$pending_requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $db->prepare($approved_sql);
$stmt->execute($approved_params);
$approved_requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

include 'includes/header.php';
?>

<div class="flex h-screen bg-gray-100">
    <?php include 'includes/sidebar.php'; ?>

    <div class="flex-1 overflow-auto ml-0 lg:ml-64 pt-16">
        <div class="p-6">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-semibold text-gray-900">İzin Talepleri Yönetimi</h1>
            </div>

            <!-- Sekmeler -->
            <div class="mb-6">
                <nav class="flex space-x-4" aria-label="Tabs">
                    <a href="?tab=pending" 
                       class="<?= $active_tab === 'pending' ? 'bg-blue-100 text-blue-700' : 'text-gray-500 hover:text-gray-700' ?> px-3 py-2 font-medium text-sm rounded-md">
                        Bekleyen İzinler
                        <?php if(count($pending_requests) > 0): ?>
                            <span class="ml-2 bg-blue-200 text-blue-800 py-0.5 px-2 rounded-full text-xs">
                                <?= count($pending_requests) ?>
                            </span>
                        <?php endif; ?>
                    </a>
                    <a href="?tab=approved" 
                       class="<?= $active_tab === 'approved' ? 'bg-green-100 text-green-700' : 'text-gray-500 hover:text-gray-700' ?> px-3 py-2 font-medium text-sm rounded-md">
                        Onaylanmış İzinler
                    </a>
                </nav>
            </div>

            <!-- Tablo -->
            <div class="bg-white shadow-md rounded-lg overflow-hidden">
                <table id="leaveRequestsTable" class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Çalışan</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Departman</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">İzin Türü</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tarih Aralığı</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Gün</th>
                            <?php if($active_tab === 'approved'): ?>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Onaylayan</th>
                            <?php endif; ?>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">İşlemler</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php 
                        $requests = $active_tab === 'pending' ? $pending_requests : $approved_requests;
                        foreach ($requests as $request): 
                        ?>
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm font-medium text-gray-900">
                                        <?= htmlspecialchars($request['first_name'] . ' ' . $request['last_name']) ?>
                                    </div>
                                    <div class="text-sm text-gray-500">
                                        <?= htmlspecialchars($request['job_title']) ?>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900">
                                        <?= htmlspecialchars($request['department_name']) ?>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900">
                                        <?= htmlspecialchars($request['leave_type']) ?>
                                        <span class="text-xs <?= $request['is_paid'] ? 'text-green-600' : 'text-red-600' ?>">
                                            <?= $request['is_paid'] ? '(Ücretli)' : '(Ücretsiz)' ?>
                                        </span>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900">
                                        <?= date('d.m.Y', strtotime($request['start_date'])) ?> - 
                                        <?= date('d.m.Y', strtotime($request['end_date'])) ?>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900">
                                        <?= $request['total_days'] ?> gün
                                    </div>
                                </td>
                                <?php if($active_tab === 'approved'): ?>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-900">
                                            <?= htmlspecialchars($request['approved_by_name']) ?>
                                        </div>
                                        <div class="text-xs text-gray-500">
                                            <?= date('d.m.Y H:i', strtotime($request['approval_date'])) ?>
                                        </div>
                                    </td>
                                <?php endif; ?>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                    <button type="button" 
                                            onclick="showRequestDetails('<?= $request['id'] ?>')" 
                                            class="text-blue-600 hover:text-blue-900 mr-3">
                                        Detay
                                    </button>
                                    <?php if($active_tab === 'pending'): ?>
                                        <button type="button"
                                                onclick="showApproveModal(<?= $request['id'] ?>)" 
                                                class="text-green-600 hover:text-green-900 mr-3">
                                            Onayla
                                        </button>
                                        <button type="button"
                                                onclick="showRejectModal(<?= $request['id'] ?>)" 
                                                class="text-red-600 hover:text-red-900">
                                            Reddet
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($requests)): ?>
                            <tr>
                                <td colspan="<?= $active_tab === 'approved' ? '7' : '6' ?>" class="px-6 py-4 text-center text-gray-500">
                                    <?= $active_tab === 'pending' ? 'Bekleyen izin talebi bulunmamaktadır.' : 'Onaylanmış izin bulunmamaktadır.' ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal yapıları aynı kalacak -->

<script>
$(document).ready(function() {
    $('#leaveRequestsTable').DataTable({
        language: {
            url: '//cdn.datatables.net/plug-ins/1.10.24/i18n/Turkish.json'
        },
        order: [[0, 'desc']],
        pageLength: 25,
        dom: 'Bfrtip',
        buttons: [
            {
                extend: 'excel',
                text: 'Excel',
                title: '<?= $active_tab === "pending" ? "Bekleyen İzin Talepleri" : "Onaylanmış İzinler" ?>',
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                extend: 'pdf',
                text: 'PDF',
                title: '<?= $active_tab === "pending" ? "Bekleyen İzin Talepleri" : "Onaylanmış İzinler" ?>',
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                extend: 'print',
                text: 'Yazdır',
                title: '<?= $active_tab === "pending" ? "Bekleyen İzin Talepleri" : "Onaylanmış İzinler" ?>',
                exportOptions: {
                    columns: ':visible'
                }
            }
        ]
    });
});

// Diğer JavaScript fonksiyonları aynı kalacak
</script>
<!-- Detay Modalı -->
<div id="detailsModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">İzin Talebi Detayları</h3>
            <div id="requestDetails" class="space-y-3">
                <!-- JavaScript ile doldurulacak -->
            </div>
            <div class="mt-5 flex justify-end">
                <button onclick="closeDetailsModal()" 
                        class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded">
                    Kapat
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Onaylama Modalı -->
<div id="approveModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">İzin Talebini Onayla</h3>
            <form id="approveForm" method="POST" action="process_leave.php">
                <input type="hidden" name="action" value="approve">
                <input type="hidden" name="request_id" id="approve_request_id">
                
                <div class="mb-4">
                    <label for="approve_comment" class="block text-sm font-medium text-gray-700 mb-1">Açıklama</label>
                    <textarea id="approve_comment" name="comment" rows="3" 
                              class="shadow-sm focus:ring-blue-500 focus:border-blue-500 mt-1 block w-full sm:text-sm border border-gray-300 rounded-md"
                              placeholder="Varsa eklemek istediğiniz not..."></textarea>
                </div>
                
                <div class="flex justify-end">
                    <button type="button" onclick="closeApproveModal()" 
                            class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded mr-2">
                        İptal
                    </button>
                    <button type="submit" 
                            class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                        Onayla
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Reddetme Modalı -->
<div id="rejectModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">İzin Talebini Reddet</h3>
            <form id="rejectForm" method="POST" action="process_leave.php">
                <input type="hidden" name="action" value="reject">
                <input type="hidden" name="request_id" id="reject_request_id">
                
                <div class="mb-4">
                    <label for="reject_comment" class="block text-sm font-medium text-gray-700 mb-1">Red Nedeni <span class="text-red-500">*</span></label>
                    <textarea id="reject_comment" name="comment" rows="3" required
                              class="shadow-sm focus:ring-blue-500 focus:border-blue-500 mt-1 block w-full sm:text-sm border border-gray-300 rounded-md"
                              placeholder="Red nedenini açıklayın..."></textarea>
                </div>
                
                <div class="flex justify-end">
                    <button type="button" onclick="closeRejectModal()" 
                            class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded mr-2">
                        İptal
                    </button>
                    <button type="submit" 
                            class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                        Reddet
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function showRequestDetails(requestId) {
    // AJAX ile izin detaylarını getir
    $.ajax({
        url: 'get_leave_details.php',
        type: 'GET',
        data: { request_id: requestId },
        success: function(response) {
            const data = JSON.parse(response);
            const detailsDiv = document.getElementById('requestDetails');
            
            detailsDiv.innerHTML = `
                <div class="space-y-2">
                    <div class="border-b pb-2">
                        <p class="text-sm"><span class="font-semibold">Çalışan:</span> ${data.employee_name}</p>
                        <p class="text-sm"><span class="font-semibold">Departman:</span> ${data.department_name}</p>
                        <p class="text-sm"><span class="font-semibold">Unvan:</span> ${data.job_title}</p>
                    </div>
                    
                    <div class="border-b pb-2">
                        <p class="text-sm"><span class="font-semibold">İzin Türü:</span> ${data.leave_type} ${data.is_paid ? '(Ücretli)' : '(Ücretsiz)'}</p>
                        <p class="text-sm"><span class="font-semibold">Başlangıç:</span> ${data.start_date}</p>
                        <p class="text-sm"><span class="font-semibold">Bitiş:</span> ${data.end_date}</p>
                        <p class="text-sm"><span class="font-semibold">Toplam Gün:</span> ${data.total_days} gün</p>
                    </div>
                    
                    ${data.reason ? `
                        <div class="border-b pb-2">
                            <p class="text-sm"><span class="font-semibold">İzin Nedeni:</span> ${data.reason}</p>
                        </div>
                    ` : ''}
                    
                    ${data.contact_info ? `
                        <div class="border-b pb-2">
                            <p class="text-sm"><span class="font-semibold">İletişim Bilgisi:</span> ${data.contact_info}</p>
                        </div>
                    ` : ''}
                    
                    <div class="pb-2">
                        <p class="text-sm"><span class="font-semibold">Talep Tarihi:</span> ${data.created_at}</p>
                    </div>
                </div>
            `;
            
            document.getElementById('detailsModal').classList.remove('hidden');
        },
        error: function(xhr, status, error) {
            alert('Detaylar yüklenirken bir hata oluştu.');
        }
    });
}

function closeDetailsModal() {
    document.getElementById('detailsModal').classList.add('hidden');
}

function showApproveModal(requestId) {
    document.getElementById('approve_request_id').value = requestId;
    document.getElementById('approveModal').classList.remove('hidden');
}

function closeApproveModal() {
    document.getElementById('approveModal').classList.add('hidden');
}

function showRejectModal(requestId) {
    document.getElementById('reject_request_id').value = requestId;
    document.getElementById('rejectModal').classList.remove('hidden');
}

function closeRejectModal() {
    document.getElementById('rejectModal').classList.add('hidden');
}

// Form işlemleri
$(document).ready(function() {
    // Onaylama formu
    $('#approveForm').on('submit', function(e) {
        e.preventDefault();
        $.ajax({
            url: $(this).attr('action'),
            type: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                const data = JSON.parse(response);
                if (data.success) {
                    alert('İzin talebi onaylandı.');
                    window.location.reload();
                } else {
                    alert(data.message || 'Bir hata oluştu.');
                }
            },
            error: function() {
                alert('İşlem sırasında bir hata oluştu.');
            }
        });
    });

    // Reddetme formu
    $('#rejectForm').on('submit', function(e) {
        e.preventDefault();
        if (!$('#reject_comment').val().trim()) {
            alert('Lütfen red nedenini belirtin.');
            return;
        }
        $.ajax({
            url: $(this).attr('action'),
            type: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                const data = JSON.parse(response);
                if (data.success) {
                    alert('İzin talebi reddedildi.');
                    window.location.reload();
                } else {
                    alert(data.message || 'Bir hata oluştu.');
                }
            },
            error: function() {
                alert('İşlem sırasında bir hata oluştu.');
            }
        });
    });
});
</script>
<?php include 'includes/footer.php'; ?>