<?php
// includes/header.php


// Database bağlantısı
require_once 'config/database.php';
$database = new Database();
$db = $database->connect(); // Önce connect() metodunu çağırmalıyız

// Kullanıcı bilgilerini al
if (isset($_SESSION['user_id'])) {
    $stmt = $db->prepare("
        SELECT u.*, e.first_name, e.last_name, e.id as employee_id 
        FROM users u 
        LEFT JOIN employees e ON u.id = e.user_id 
        WHERE u.id = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
}


// Get company settings
function get_company_setting($key, $default = '') {
    global $db;
    
    try {
        $stmt = $db->prepare("SELECT setting_value FROM settings WHERE setting_key = :key LIMIT 1");
        $stmt->execute(['key' => $key]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($result) {
            return $result['setting_value'];
        }
    } catch (PDOException $e) {
        error_log("Error getting company setting: " . $e->getMessage());
    }
    
    return $default;
}

// Get company logo and name
$company_logo = get_company_setting('company_logo', 'assets/img/logo.png');
$company_name = get_company_setting('company_name', 'İK Yönetim Portalı');
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $company_name; ?></title>
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="<?php echo BASE_URL; ?>/assets/img/favicon.png">
    <!-- header.php içine eklenecek -->
    <!-- DataTables CSS -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/dataTables.tailwind.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.tailwind.min.css">

    <!-- DataTables JS -->
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/dataTables.tailwind.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.9/js/responsive.tailwind.min.js"></script>

    <!-- FullCalendar CSS -->
    <link href='https://cdn.jsdelivr.net/npm/@fullcalendar/core@6.1.10/main.min.css' rel='stylesheet' />
    <link href='https://cdn.jsdelivr.net/npm/@fullcalendar/daygrid@6.1.10/main.min.css' rel='stylesheet' />
    <link href='https://cdn.jsdelivr.net/npm/@fullcalendar/timegrid@6.1.10/main.min.css' rel='stylesheet' />
    <link href='https://cdn.jsdelivr.net/npm/@fullcalendar/list@6.1.10/main.min.css' rel='stylesheet' />
    <link href='https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.css' rel='stylesheet' />

    <!-- DataTables Buttons CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.2/css/buttons.dataTables.min.css">
    
    <!-- FullCalendar JS -->
    <script src='https://cdn.jsdelivr.net/npm/@fullcalendar/core@6.1.10/main.min.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/@fullcalendar/daygrid@6.1.10/main.min.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/@fullcalendar/timegrid@6.1.10/main.min.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/@fullcalendar/list@6.1.10/main.min.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/@fullcalendar/interaction@6.1.10/main.min.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/locales-all.js'></script>

    <!-- DataTables Buttons JS -->
    <script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.print.min.js"></script>
    

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: {
                            50: '#f0f9ff',
                            100: '#e0f2fe',
                            200: '#bae6fd',
                            300: '#7dd3fc',
                            400: '#38bdf8',
                            500: '#0ea5e9',
                            600: '#0284c7',
                            700: '#0369a1',
                            800: '#075985',
                            900: '#0c4a6e',
                        },
                    }
                }
            }
        }
    </script>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom styles -->
    <style>
        /* Scrollbar styles */
        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
        ::-webkit-scrollbar-thumb {
            background: #c1c1c1;
            border-radius: 3px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: #a8a8a8;
        }
        
        /* Sidebar active link */
        .sidebar-active {
            background-color: rgba(59, 130, 246, 0.1);
            color: #3b82f6;
            border-left: 3px solid #3b82f6;
        }
        
        /* Dropdown animation */
        .dropdown-animation {
            transition: all 0.3s ease-in-out;
        }
        
        /* Main content padding for sidebar */
        @media (min-width: 1024px) {
            .lg-sidebar-padding {
                padding-left: 16rem; /* 256px */
            }
        }
    </style>
    <style>
        /* DataTables özelleştirmeleri */
        .dataTables_wrapper .dataTables_length select,
        .dataTables_wrapper .dataTables_filter input {
            padding: 0.5rem;
            border-radius: 0.375rem;
            border: 1px solid #d1d5db;
        }
        
        .dataTables_wrapper .dataTables_length select:focus,
        .dataTables_wrapper .dataTables_filter input:focus {
            outline: none;
            border-color: #3b82f6;
            ring: 2px;
            ring-color: #93c5fd;
        }
        
        /* Modal arka plan */
        .modal-backdrop {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 50;
        }
        
        /* Tablo responsive düzenlemeler */
        @media (max-width: 640px) {
            .responsive-table {
                display: block;
                width: 100%;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
            }
        }
        
        /* Form elemanları için genel stiller */
        .form-input {
            width: 100%;
            padding: 0.5rem;
            border-radius: 0.375rem;
            border: 1px solid #d1d5db;
        }
        
        .form-input:focus {
            outline: none;
            border-color: #3b82f6;
            ring: 2px;
            ring-color: #93c5fd;
        }
        
        /* Button stilleri */
        .btn {
            padding: 0.5rem 1rem;
            border-radius: 0.375rem;
            font-weight: 500;
            cursor: pointer;
            transition: background-color 0.2s;
        }
        
        .btn-primary {
            background-color: #3b82f6;
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #2563eb;
        }
        
        .btn-secondary {
            background-color: #6b7280;
            color: white;
        }
        
        .btn-secondary:hover {
            background-color: #4b5563;
        }
        
        /* Status badge stilleri */
        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
        }
        
        .status-pending {
            background-color: #fef3c7;
            color: #92400e;
        }
        
        .status-approved {
            background-color: #d1fae5;
            color: #065f46;
        }
        
        .status-rejected {
            background-color: #fee2e2;
            color: #991b1b;
        }
        
        .status-cancelled {
            background-color: #f3f4f6;
            color: #1f2937;
        }
    </style>
</head>
<body class="bg-gray-100">
    <!-- Top navigation -->
    <nav class="bg-white border-b border-gray-200 fixed z-30 w-full">
        <div class="px-3 py-3 lg:px-5 lg:pl-3">
            <div class="flex items-center justify-between">
                <!-- Left side -->
                <div class="flex items-center justify-start">
                    <!-- Mobile menu button -->
                    <button id="toggleSidebarMobile" aria-expanded="true" aria-controls="sidebar" class="lg:hidden mr-2 text-gray-600 hover:text-gray-900 cursor-pointer p-2 hover:bg-gray-100 focus:bg-gray-100 focus:ring-2 focus:ring-gray-100 rounded">
                        <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clip-rule="evenodd"></path>
                        </svg>
                    </button>
                    
                    <!-- Logo -->
                    <a href="index.php" class="text-xl font-bold flex items-center lg:ml-2.5">
                        <?php if (!empty($company_logo) && file_exists($company_logo)): ?>
                            <img src="<?php echo $company_logo; ?>" class="h-8 mr-2" alt="<?php echo $company_name; ?> Logo">
                        <?php else: ?>
                            <img src="<?php echo BASE_URL; ?>/assets/img/logo.png" class="h-8 mr-2" alt="Logo">
                        <?php endif; ?>
                        <span class="self-center whitespace-nowrap"><?php echo $company_name; ?></span>
                    </a>
                </div>
                
                <!-- Right side -->
                <div class="flex items-center">
                    <!-- Search -->
                    <div class="hidden md:flex items-center mr-4">
                        <div class="relative w-64">
                            <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                                <svg class="w-5 h-5 text-gray-500" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clip-rule="evenodd"></path>
                                </svg>
                            </div>
                            <input type="text" id="search" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 p-2" placeholder="Ara...">
                        </div>
                    </div>
                    
                    <!-- Notifications -->
                    <div class="flex items-center mr-4">
                        <!-- header.php içinde, kullanıcı menüsünden önce -->
                        <?php if (isset($_SESSION['user_id'])): ?>
                            <?php $unread_count = get_unread_notification_count($_SESSION['user_id']); ?>
                            <div class="relative mr-4">
                                <button id="notificationButton" class="relative p-1 text-gray-400 hover:text-gray-500 focus:outline-none">
                                    <svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path>
                                    </svg>
                                    <?php if ($unread_count > 0): ?>
                                        <span class="absolute top-0 right-0 block h-4 w-4 rounded-full bg-red-500 text-white text-xs text-center">
                                            <?= $unread_count ?>
                                        </span>
                                    <?php endif; ?>
                                </button>
                                
                                <!-- Bildirimler Dropdown -->
                                <div id="notificationsDropdown" class="hidden absolute right-0 mt-2 w-80 bg-white rounded-md shadow-lg overflow-hidden z-50">
                                    <div class="py-2">
                                        <?php
                                        $notifications = get_user_notifications($_SESSION['user_id'], 5);
                                        if (empty($notifications)): ?>
                                            <div class="px-4 py-2 text-sm text-gray-500">
                                                Bildirim bulunmuyor
                                            </div>
                                        <?php else: ?>
                                            <?php foreach ($notifications as $notification): ?>
                                                <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 <?= !$notification['is_read'] ? 'bg-blue-50' : '' ?>"
                                                onclick="markNotificationAsRead(<?= $notification['id'] ?>)">
                                                    <p class="font-medium"><?= htmlspecialchars($notification['title']) ?></p>
                                                    <p class="text-xs text-gray-500"><?= htmlspecialchars($notification['message']) ?></p>
                                                    <p class="text-xs text-gray-400 mt-1">
                                                        <?= date('d.m.Y H:i', strtotime($notification['created_at'])) ?>
                                                    </p>
                                                </a>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </div>
                                    <?php if (!empty($notifications)): ?>
                                        <div class="border-t border-gray-100">
                                            <a href="notifications.php" class="block text-center py-2 text-sm text-blue-600 hover:text-blue-500">
                                                Tüm Bildirimleri Gör
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endif; ?>

                        <script>
                        // Bildirim dropdown kontrolü
                        document.getElementById('notificationButton')?.addEventListener('click', function(e) {
                            e.stopPropagation();
                            document.getElementById('notificationsDropdown').classList.toggle('hidden');
                        });

                        // Sayfa herhangi bir yerine tıklandığında dropdown'ı kapat
                        document.addEventListener('click', function(e) {
                            if (!e.target.closest('#notificationsDropdown')) {
                                document.getElementById('notificationsDropdown')?.classList.add('hidden');
                            }
                        });

                        // Bildirimi okundu olarak işaretle
                        function markNotificationAsRead(notificationId) {
                            fetch('mark_notification_read.php', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/x-www-form-urlencoded',
                                },
                                body: 'notification_id=' + notificationId
                            })
                            .then(response => response.json())
                            .then(data => {
                                if (data.success) {
                                    // Bildirimi görsel olarak okundu olarak işaretle
                                    const element = event.currentTarget;
                                    element.classList.remove('bg-blue-50');
                                    
                                    // Okunmamış bildirim sayısını güncelle
                                    const countElement = document.querySelector('#notificationButton .absolute');
                                    if (countElement) {
                                        const currentCount = parseInt(countElement.textContent);
                                        if (currentCount > 1) {
                                            countElement.textContent = currentCount - 1;
                                        } else {
                                            countElement.remove();
                                        }
                                    }
                                }
                            });
                        }
                        </script>
                    </div>
                    
                    <!-- User Menu -->
                <?php if (isset($_SESSION['user_id'])): ?>
                    <div class="flex items-center">
                        <div class="ml-3 relative">
                            <div class="flex items-center">
                                <button type="button" class="user-menu-button bg-white rounded-full flex text-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500" id="user-menu-button" aria-expanded="false" aria-haspopup="true">
                                    <span class="sr-only">Open user menu</span>
                                    <div class="h-8 w-8 rounded-full bg-blue-500 flex items-center justify-center text-white">
                                        <?php 
                                        if (isset($user['first_name']) && isset($user['last_name'])) {
                                            echo substr($user['first_name'], 0, 1) . substr($user['last_name'], 0, 1);
                                        } else {
                                            echo substr($user['email'], 0, 2);
                                        }
                                        ?>
                                    </div>
                                </button>
                            </div>

                            <!-- Dropdown menu -->
                            <div class="user-menu hidden origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg py-1 bg-white ring-1 ring-black ring-opacity-5 focus:outline-none" role="menu" aria-orientation="vertical" aria-labelledby="user-menu-button" tabindex="-1">
                                <?php if (isset($user['employee_id'])): ?>
                                    <a href="my_profile.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100" role="menuitem">Profilim</a>
                                <?php endif; ?>
                                <a href="change_password.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100" role="menuitem">Şifre Değiştir</a>
                                <a href="logout.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100" role="menuitem">Çıkış Yap</a>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </nav>