<?php
// Unauthorized access page
session_start();

// Load configuration
require_once 'config/config.php';
require_once 'config/functions.php';

// Set page title
$page_title = 'Yetkisiz Erişim';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yetkisiz Erişim - İK Yönetim Portalı</title>
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex items-center justify-center">
        <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-md text-center">
            <div class="text-red-500 mb-4">
                <i class="fas fa-exclamation-circle text-6xl"></i>
            </div>
            
            <h1 class="text-2xl font-bold text-gray-800 mb-4">Yetkisiz Erişim</h1>
            
            <p class="text-gray-600 mb-6">Bu sayfaya erişim yetkiniz bulunmamaktadır. Lütfen yöneticinizle iletişime geçin veya ana sayfaya dönün.</p>
            
            <?php if (isset($_SESSION['flash_messages']['auth_error'])): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                    <span class="block sm:inline"><?php echo $_SESSION['flash_messages']['auth_error']['message']; ?></span>
                </div>
                <?php unset($_SESSION['flash_messages']['auth_error']); ?>
            <?php endif; ?>
            
            <div class="flex justify-center space-x-4">
                <a href="index.php" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                    Ana Sayfaya Dön
                </a>
                <?php if (!is_logged_in()): ?>
                <a href="login.php" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                    Giriş Yap
                </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>