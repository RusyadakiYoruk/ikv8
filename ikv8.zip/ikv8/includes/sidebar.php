<?php
// includes/sidebar.php

// Get employee information if not already set
if (!isset($employee) && isset($_SESSION['user_id'])) {
    try {
        $stmt = $db->prepare("SELECT e.* FROM employees e 
                             JOIN users u ON e.user_id = u.id 
                             WHERE u.id = :user_id LIMIT 1");
        $stmt->execute(['user_id' => $_SESSION['user_id']]);
        $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        $employee = null;
    }
}

// Get user role if not already set
$user_role = $_SESSION['user_role'] ?? 'employee';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
?>

<!-- Sidebar -->
<aside id="sidebar" class="fixed z-20 h-full top-0 left-0 pt-16 flex lg:flex flex-shrink-0 flex-col w-64 transition-width duration-300 lg:block hidden" aria-label="Sidebar">
    <div class="relative flex-1 flex flex-col min-h-0 border-r border-gray-200 bg-white pt-0">
        <div class="flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
            <div class="flex-1 px-3 bg-white divide-y space-y-1">
                <!-- User info -->
                <div class="space-y-2 pb-4">
                    <div class="flex items-center">
                        <img class="h-10 w-10 rounded-full" src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['user_email']); ?>&background=random" alt="User avatar">
                        <div class="ml-3">
                            <p class="text-sm font-medium text-gray-900"><?php echo $employee ? $employee['first_name'] . ' ' . $employee['last_name'] : $_SESSION['user_email']; ?></p>
                            <p class="text-xs font-medium text-gray-500"><?php echo ucfirst($_SESSION['user_role']); ?></p>
                        </div>
                    </div>
                </div>
                
                <!-- Navigation -->
                <ul class="space-y-2 pt-4">
                    <!-- Dashboard -->
                    <li>
                        <a href="index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 hover:bg-gray-100 group">
                            <i class="fas fa-tachometer-alt w-6 h-6 text-gray-500 group-hover:text-gray-900 transition duration-75"></i>
                            <span class="ml-3">Dashboard</span>
                        </a>
                    </li>
                    
                    <!-- Employees Module -->
                    <li>
                        <button type="button" class="text-base text-gray-900 font-normal rounded-lg flex items-center p-2 hover:bg-gray-100 w-full group" aria-controls="dropdown-employees" data-collapse-toggle="dropdown-employees">
                            <i class="fas fa-users w-6 h-6 text-gray-500 group-hover:text-gray-900 transition duration-75"></i>
                            <span class="ml-3 flex-1 text-left whitespace-nowrap">Çalışanlar</span>
                            <i class="fas fa-chevron-down w-6 h-6 text-gray-500 group-hover:text-gray-900 transition duration-75"></i>
                        </button>
                        <ul id="dropdown-employees" class="hidden py-2 space-y-2">
                            <li>
                                <a href="employees.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'employees.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    Tüm Çalışanlar
                                </a>
                            </li>
                            <?php if ($user_role === 'admin' || $user_role === 'manager'): ?>
                            <li>
                                <a href="add_employee.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'add_employee.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    Çalışan Ekle
                                </a>
                            </li>
                            <li>
                                <a href="departments.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'departments.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    Departmanlar
                                </a>
                            </li>
                            <li>
                                <a href="job_titles.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'job_titles.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    Unvanlar
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    
                    <!-- Leave Module -->
                    <li>
                        <button type="button" class="text-base text-gray-900 font-normal rounded-lg flex items-center p-2 hover:bg-gray-100 w-full group" aria-controls="dropdown-leave" data-collapse-toggle="dropdown-leave">
                            <i class="fas fa-calendar-alt w-6 h-6 text-gray-500 group-hover:text-gray-900 transition duration-75"></i>
                            <span class="ml-3 flex-1 text-left whitespace-nowrap">İzinler</span>
                            <i class="fas fa-chevron-down w-6 h-6 text-gray-500 group-hover:text-gray-900 transition duration-75"></i>
                        </button>
                        <ul id="dropdown-leave" class="hidden py-2 space-y-2">
                            <li>
                                <a href="leave_request.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'leave_request.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    İzin Talebi Oluştur
                                </a>
                            </li>
                            <li>
                                <a href="my_leave_requests.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'my_leave_requests.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    İzin Taleplerim
                                </a>
                            </li>
                            <?php if ($user_role === 'admin' || $user_role === 'manager'): ?>
                            <li>
                                <a href="leave_requests.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'leave_requests.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    Tüm İzin Talepleri
                                </a>
                            </li>
                            <li>
                                <a href="leave_types.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'leave_types.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    İzin Türleri
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    
                    <!-- Calendar Module -->
                    <li>
                        <a href="calendar.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'calendar.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 hover:bg-gray-100 group">
                            <i class="fas fa-calendar-week w-6 h-6 text-gray-500 group-hover:text-gray-900 transition duration-75"></i>
                            <span class="ml-3">Takvim</span>
                        </a>
                    </li>
                    
                    <!-- Expenses Module -->
                    <li>
                        <button type="button" class="text-base text-gray-900 font-normal rounded-lg flex items-center p-2 hover:bg-gray-100 w-full group" aria-controls="dropdown-expenses" data-collapse-toggle="dropdown-expenses">
                            <i class="fas fa-receipt w-6 h-6 text-gray-500 group-hover:text-gray-900 transition duration-75"></i>
                            <span class="ml-3 flex-1 text-left whitespace-nowrap">Harcamalar</span>
                            <i class="fas fa-chevron-down w-6 h-6 text-gray-500 group-hover:text-gray-900 transition duration-75"></i>
                        </button>
                        <ul id="dropdown-expenses" class="hidden py-2 space-y-2">
                            <li>
                                <a href="add_expense.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'add_expense.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    Harcama Ekle
                                </a>
                            </li>
                            <li>
                                <a href="my_expenses.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'my_expenses.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    Harcamalarım
                                </a>
                            </li>
                            <?php if ($user_role === 'admin' || $user_role === 'manager'): ?>
                            <li>
                                <a href="expenses.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'expenses.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    Tüm Harcamalar
                                </a>
                            </li>
                            <li>
                                <a href="expense_categories.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'expense_categories.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    Harcama Kategorileri
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    
                    <!-- Payroll Module -->
                    <?php if ($user_role === 'admin' || $user_role === 'manager'): ?>
                    <li>
                        <button type="button" class="text-base text-gray-900 font-normal rounded-lg flex items-center p-2 hover:bg-gray-100 w-full group" aria-controls="dropdown-payroll" data-collapse-toggle="dropdown-payroll">
                            <i class="fas fa-money-check-alt w-6 h-6 text-gray-500 group-hover:text-gray-900 transition duration-75"></i>
                            <span class="ml-3 flex-1 text-left whitespace-nowrap">Bordro</span>
                            <i class="fas fa-chevron-down w-6 h-6 text-gray-500 group-hover:text-gray-900 transition duration-75"></i>
                        </button>
                        <ul id="dropdown-payroll" class="hidden py-2 space-y-2">
                            <li>
                                <a href="payroll_periods.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'payroll_periods.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    Maaş Dönemleri
                                </a>
                            </li>
                            <li>
                                <a href="payroll_items.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'payroll_items.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    Maaş Kalemleri
                                </a>
                            </li>
                            <li>
                                <a href="payroll_process.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'payroll_process.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    Maaş Hesaplama
                                </a>
                            </li>
                            <li>
                                <a href="payroll_reports.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'payroll_reports.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    Bordro Raporları
                                </a>
                            </li>
                        </ul>
                    </li>
                    <?php endif; ?>
                    
                    <!-- Performance Module -->
                    <li>
                        <button type="button" class="text-base text-gray-900 font-normal rounded-lg flex items-center p-2 hover:bg-gray-100 w-full group" aria-controls="dropdown-performance" data-collapse-toggle="dropdown-performance">
                            <i class="fas fa-chart-line w-6 h-6 text-gray-500 group-hover:text-gray-900 transition duration-75"></i>
                            <span class="ml-3 flex-1 text-left whitespace-nowrap">Performans</span>
                            <i class="fas fa-chevron-down w-6 h-6 text-gray-500 group-hover:text-gray-900 transition duration-75"></i>
                        </button>
                        <ul id="dropdown-performance" class="hidden py-2 space-y-2">
                            <li>
                                <a href="my_performance.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'my_performance.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    Performansım
                                </a>
                            </li>
                            <?php if ($user_role === 'admin' || $user_role === 'manager'): ?>
                                <li>
                                <a href="performance_reviews.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'performance_reviews.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    Performans Değerlendirmeleri
                                </a>
                            </li>
                            <li>
                                <a href="performance_criteria.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'performance_criteria.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    Performans Kriterleri
                                </a>
                            </li>
                            <li>
                                <a href="performance_periods.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'performance_periods.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    Değerlendirme Dönemleri
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    
                   
                    <!-- Reports Module -->
                    <?php if ($user_role === 'admin' || $user_role === 'manager'): ?>
                    <li>
                        <button type="button" class="text-base text-gray-900 font-normal rounded-lg flex items-center p-2 hover:bg-gray-100 w-full group" aria-controls="dropdown-reports" data-collapse-toggle="dropdown-reports">
                            <i class="fas fa-file-alt w-6 h-6 text-gray-500 group-hover:text-gray-900 transition duration-75"></i>
                            <span class="ml-3 flex-1 text-left whitespace-nowrap">Raporlar</span>
                            <i class="fas fa-chevron-down w-6 h-6 text-gray-500 group-hover:text-gray-900 transition duration-75"></i>
                        </button>
                        <ul id="dropdown-reports" class="hidden py-2 space-y-2">
                            <li>
                                <a href="employee_reports.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'employee_reports.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    Çalışan Raporları
                                </a>
                            </li>
                            <li>
                                <a href="leave_reports.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'leave_reports.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    İzin Raporları
                                </a>
                            </li>
                            <li>
                                <a href="expense_reports.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'expense_reports.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    Harcama Raporları
                                </a>
                            </li>
                            <li>
                                <a href="attendance_reports.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'attendance_reports.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    Devam Raporları
                                </a>
                            </li>
                            <li>
                                <a href="performance_reports.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'performance_reports.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    Performans Raporları
                                </a>
                            </li>
                        </ul>
                    </li>
                    <?php endif; ?>
                    
                    <!-- Settings Module -->
                    <?php if ($user_role === 'admin'): ?>
                    <li>
                        <button type="button" class="text-base text-gray-900 font-normal rounded-lg flex items-center p-2 hover:bg-gray-100 w-full group" aria-controls="dropdown-settings" data-collapse-toggle="dropdown-settings">
                            <i class="fas fa-cog w-6 h-6 text-gray-500 group-hover:text-gray-900 transition duration-75"></i>
                            <span class="ml-3 flex-1 text-left whitespace-nowrap">Ayarlar</span>
                            <i class="fas fa-chevron-down w-6 h-6 text-gray-500 group-hover:text-gray-900 transition duration-75"></i>
                        </button>
                        <ul id="dropdown-settings" class="hidden py-2 space-y-2">
                            <li>
                                <a href="general_settings.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'general_settings.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    Genel Ayarlar
                                </a>
                            </li>
                            <li>
                                <a href="company_settings.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'company_settings.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    Şirket Bilgileri
                                </a>
                            </li>
                            <li>
                                <a href="user_management.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'user_management.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    Kullanıcı Yönetimi
                                </a>
                            </li>
                            <li>
                                <a href="system_logs.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'system_logs.php' ? 'sidebar-active' : ''; ?> text-base text-gray-900 font-normal rounded-lg flex items-center p-2 pl-11 hover:bg-gray-100 group">
                                    Sistem Logları
                                </a>
                            </li>
                        </ul>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</aside>

<!-- Mobile sidebar backdrop -->
<div class="bg-gray-900 opacity-50 hidden fixed inset-0 z-10" id="sidebarBackdrop"></div>

<!-- JavaScript for sidebar functionality -->
<script>
    // Toggle mobile sidebar
    document.getElementById('toggleSidebarMobile').addEventListener('click', function() {
        const sidebar = document.getElementById('sidebar');
        const backdrop = document.getElementById('sidebarBackdrop');
        
        sidebar.classList.toggle('hidden');
        backdrop.classList.toggle('hidden');
    });
    
    // Close mobile sidebar when clicking outside
    document.getElementById('sidebarBackdrop').addEventListener('click', function() {
        const sidebar = document.getElementById('sidebar');
        const backdrop = document.getElementById('sidebarBackdrop');
        
        sidebar.classList.add('hidden');
        backdrop.classList.add('hidden');
    });
    
    // Toggle dropdown menus
    const dropdownToggles = document.querySelectorAll('[data-collapse-toggle]');
    
    dropdownToggles.forEach(toggle => {
        toggle.addEventListener('click', function() {
            const targetId = this.getAttribute('data-collapse-toggle');
            const targetElement = document.getElementById(targetId);
            const chevronIcon = this.querySelector('.fa-chevron-down');
            
            targetElement.classList.toggle('hidden');
            if (chevronIcon) {
                chevronIcon.classList.toggle('rotate-180');
            }
        });
    });
</script>