<?php
// get_managers.php
session_start();

// Load configuration
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';

// Check if user is logged in and has appropriate role
require_role(['admin', 'manager']);

// Connect to database
$database = new Database();
$db = $database->connect();

// Get parameters
$department_id = isset($_POST['department_id']) ? (int)$_POST['department_id'] : 0;
$employee_id = isset($_POST['employee_id']) ? (int)$_POST['employee_id'] : 0;

if ($department_id > 0) {
    // Get potential managers for the department
    $stmt = $db->prepare("
        SELECT DISTINCT e.id, e.first_name, e.last_name, jt.title as job_title
        FROM employees e
        JOIN job_titles jt ON e.job_title_id = jt.id
        WHERE e.department_id = :department_id 
        AND e.id != :employee_id
        AND e.termination_date IS NULL
        AND (
            LOWER(jt.title) LIKE '%müdür%'
            OR LOWER(jt.title) LIKE '%şef%'
            OR LOWER(jt.title) LIKE '%mühendis%'
            OR LOWER(jt.title) LIKE '%forman%'
            OR LOWER(jt.title) LIKE '%memur%'
        )
        ORDER BY 
            CASE 
                WHEN LOWER(jt.title) LIKE '%müdür%' THEN 1
                WHEN LOWER(jt.title) LIKE '%şef%' THEN 2
                WHEN LOWER(jt.title) LIKE '%mühendis%' THEN 3
                WHEN LOWER(jt.title) LIKE '%forman%' THEN 4
                WHEN LOWER(jt.title) LIKE '%memur%' THEN 5
                ELSE 6
            END,
            e.first_name, 
            e.last_name
    ");

    $stmt->execute([
        'department_id' => $department_id,
        'employee_id' => $employee_id
    ]);
    
    $managers = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    $managers = [];
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($managers);